# GW250114 HRF master progress bundle v68

**Scope:** black-hole / GW250114 horizon-response methods only.  
**Status:** no detection or discovery claim.

## Included milestones

- **v65:** control-calibrated, GR-carrier-conditioned branch likelihood.
- **v66:** finite-control confidence audit.
- **v67:** sign-locked `D=0` branch threshold; clean synthetic controls pass the confidence gate.
- **v68:** branch-coordinate `tau*t_DW` identifiability gate and direct-wave model firewall.

## Main change in v68

The current transfer depends on the product `tau*t_DW`. Therefore a fixed-`t_DW` sign result is conditional, not a standalone physical branch measurement. Real evidence must marginalize over the full `t_DW` posterior and over competing direct-wave/carrier models.

At the old fixed working coordinate, `ln(4)` differs from the native 9-sample branch by only 0.434597% in scale. Under the project diagnostic `t_DW=2/kappa` evaluated at the public NRSur7dq4 median remnant mass/spin, the coordinate gap shrinks to 0.051015% (1.1215 microseconds, 0.00459 native sample).

The direct-wave interpretation is also under active scientific dispute as of July 2026. v68 therefore freezes three model lanes—Kerr-linked direct wave, free/evolving non-QNM transient, and standard GR IMR/QNM carrier—and requires any HRF residual to survive all three.

## Start here

1. Read `HRF_V68_BRANCH_COORDINATE_AND_DIRECTWAVE_FIREWALL/GW250114_V68_ONE_PAGE_ADMISSION_CERTIFICATE.md`.
2. Read the full v68 report and product-gauge proof.
3. Use the fetch script or upload the official files listed in `GW250114_V68_official_input_manifest.csv`.
4. Run the input probe, then propagate the official posterior into draw-level `t_DW` distributions before touching the on-source branch score.

## Current verdict

`LOCKED_TDW_AND_DIRECTWAVE_MODEL_MARGINALIZATION_REQUIRED`
