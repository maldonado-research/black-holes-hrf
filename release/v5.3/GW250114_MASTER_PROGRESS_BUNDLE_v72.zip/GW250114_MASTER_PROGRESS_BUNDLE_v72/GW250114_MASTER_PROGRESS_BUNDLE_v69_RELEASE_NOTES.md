# Master bundle v69 release notes

v69 adds a mathematically exact admission-control result to the v65-v68 chain. It proves that the current single-delay transfer cannot separate the branch coordinate from the direct-wave timescale at any SNR, proves that product-only catalog stacking retains one null direction, and quantifies how far the fixed-timescale branch test is from event-scale power.

It also classifies candidate repairs into genuine observable completions and non-repairs. More detectors, more bins, resampling, and pure multiples of the same delay improve detection/systematics control but do not increase physical parameter rank. A fixed branch-amplitude law can complete the rank only when its absolute normalization is independently calibrated; a free multiplicative normalization restores the exact gauge.

The bundle remains a methods package. Real `ln(4)`, `g=4`, area-quantization, and quantum-horizon interpretations are locked.
