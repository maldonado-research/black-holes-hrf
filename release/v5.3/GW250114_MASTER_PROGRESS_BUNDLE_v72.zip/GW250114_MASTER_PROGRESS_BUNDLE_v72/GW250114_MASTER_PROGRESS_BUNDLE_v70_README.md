# GW250114 master progress bundle v70

**Date:** 2026-07-11  
**Status:** methods/admission-control program; no detection or discovery claim.

## Included chain

- **v65:** carrier-conditioned detection and matched branch-control calibration with source-hygiene gate.
- **v66:** finite-control confidence audit.
- **v67:** sign-locked conditional branch boundary `D=0`.
- **v68:** branch-coordinate and direct-wave model firewall.
- **v69:** exact single-delay nonidentifiability, catalog null-direction theorem, realistic-SNR power audit, amplitude-normalization gauge, and observable-completion rule.
- **v70:** fail-closed official-input execution, four-waveform Kerr-linked posterior propagation, released evolving-decay cache audit, exact independent-anchor benchmarks, covariance-complete extension, and corrected release-code firewall.

## Current decision

v70 resolves the v69 binary-intake blocker: all nine frozen official products pass identity, integrity, and schema validation. The released products do not, however, supply an admissible standalone nonproduct anchor for the HRF branch coordinate.

The official remnant-derived timescales are same-event posterior-width diagnostics, not independent measurement errors. Every waveform family is broader than the declared independent-Gaussian benchmark, but the covariance-complete joint branch precision remains unevaluated because the required product–anchor covariance is not released. The direct-wave cache is network-only and constrains an evolving effective rate whose conversion to horizon `kappa` retains a free trajectory nuisance.

```text
OFFICIAL_BINARY_INTAKE_PASS
SINGLE_DELAY_STRUCTURAL_IDENTIFICATION_EXACT_FAIL
KERR_LINKED_STANDALONE_ANCHOR_FAIL
CONDITIONAL_RANK_CANDIDATE_NOT_ADMITTED
JOINT_RATIO_PRECISION_NOT_EVALUATED
PHYSICAL_INTERPRETATION_LOCKED
```

## Read first

1. `HRF_V70_OFFICIAL_ANCHOR_EVOLVING_DECAY_AND_INDEPENDENT_BENCHMARK/GW250114_V70_ONE_PAGE_CERTIFICATE.md`
2. `HRF_V70_OFFICIAL_ANCHOR_EVOLVING_DECAY_AND_INDEPENDENT_BENCHMARK/GW250114_V70_OFFICIAL_ANCHOR_EVOLVING_DECAY_AND_INDEPENDENT_BENCHMARK.md`
3. `HRF_V70_OFFICIAL_ANCHOR_EVOLVING_DECAY_AND_INDEPENDENT_BENCHMARK/GW250114_V70_THEOREM_AND_PROOF.md`
4. `HRF_V70_OFFICIAL_ANCHOR_EVOLVING_DECAY_AND_INDEPENDENT_BENCHMARK/GW250114_V70_gate_status.csv`
5. `HRF_V70_OFFICIAL_ANCHOR_EVOLVING_DECAY_AND_INDEPENDENT_BENCHMARK/GW250114_V70_NEXT_TASK.md`
6. `GW250114_MASTER_PROGRESS_v65_v70_STATUS.csv`

## Next legitimate step

Build either one covariance-complete joint likelihood or a detector-separated 16-kHz cross-fit with detector-specific remnant, QNM, direct-wave, calibration, and HRF nuisances. Evaluate the effective branch information or discrete-branch Mahalanobis separation before running a real PSD-weighted HRF branch likelihood.

The raw Nature pipeline was not rerun in v70; its validated posterior and cached likelihood products were audited directly. Overlapping start-time grids must not be multiplied as independent evidence, and the released network posterior must not leak into a held-out detector cross-fit.

## Publication decision

Do not publish a new Zenodo version from v70 alone. A next public milestone should contain a preregistered covariance-complete joint/cross-fitted result or a documented negative result from that workflow.
