# Master bundle v70 release notes

v70 advances the v65–v69 chain from a blocked official-input task to a reproducible official-product negative gate.

The standalone v70 package:

- validates the Nature companion ZIP, four LVK posterior HDF5 files, and H1/L1 GWOSC strain at 4 kHz and 16 kHz with fail-closed identity, size, checksum, and schema checks;
- transforms all four official remnant posteriors through the project diagnostic `t_K=2/kappa` map while retaining draw-level mass–spin covariance;
- reads and normalizes all seven released direct-wave grids directly from the validated ZIP, separating exploratory `-9M/-8M` windows from the supported `-7M..-3M` regime;
- proves the covariance-complete multi-event observable-completion and Gaussian product-plus-anchor formulas;
- labels the sub-percent anchor targets as exact independent-Gaussian benchmarks rather than a universal same-event power ceiling;
- audits the released robustness-code likelihood mixing, apparent posterior double-weighting, lack of a released seed, and unvetted flattened amplitude/time chain;
- repairs v69 terminology around geometric-mean Bayes factors and distinguishes the exact 512-bin base-carrier point-template mismatch from the approximate moment-Gaussian sign-power calculation.

All 12 numerical self-tests pass. Two independent strict replays produced the same 16 generated outputs bit-for-bit. The official binaries are excluded from the bundle; their frozen identities and validation results are recorded in the package.

The conclusion remains deliberately negative: the exact single-delay scale gauge persists, the released candidates are not admitted as standalone branch anchors, the required joint covariance has not been evaluated, and real `ln(4)`, `g=4`, area-quantization, microstate, or quantum-horizon interpretations remain locked.
