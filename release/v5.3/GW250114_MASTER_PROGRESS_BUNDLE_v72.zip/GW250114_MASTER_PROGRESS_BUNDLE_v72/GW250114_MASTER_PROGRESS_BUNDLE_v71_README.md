# GW250114 master progress bundle v71

**Date:** 2026-07-11  
**Status:** methods/admission-control program; no detection or discovery claim.

## Included chain

- **v65:** carrier-conditioned detection and matched branch-control calibration with source-hygiene gate.
- **v66:** finite-control confidence audit.
- **v67:** sign-locked conditional branch boundary `D=0`.
- **v68:** branch-coordinate and direct-wave model firewall.
- **v69:** exact single-delay nonidentifiability, catalog null direction, finite-SNR power audit, amplitude-normalization gauge, and observable-completion rule.
- **v70:** fail-closed official-input execution, project-timescale propagation from four official remnant-posterior families, released evolving-rate cache audit, and covariance-complete product–anchor model.
- **v71:** first-order nuisance-quotient information theorem, global nuisance-image alias gate, likelihood-only covariance-rescue envelope, catalog floor/bias theorem, released cached-sample relative log-probability decomposition, direct-importance support audit, and nonregular no-extra-HRF firewall.

## Current decision

v71 shows that unknown covariance is not a generic escape from v70’s standalone-width failure. Rescue requires a narrowly matched product/anchor error scale and near-singular positive correlation. In the current synthetic carrier context, the event-scale product error lies far outside that band.

At the released chain samples, the H1/L1 SNR columns reproduce the relative network log probability essentially exactly up to a constant; this is not a reconstructed detector likelihood surface or absolute normalization. The chain fails the v71 walker-as-chain convergence-admission screen—an admission diagnostic, not by itself proof of nonconvergence—and direct-importance weights are dominated by one or a few walkers. All eight formal H1/L1 targets across the four LVK network posteriors also fail direct-importance support; their nonadditive stored likelihood fields prevent treating those weights as semantically admitted detector-only posteriors. Raw detector-specific inference is required.

```text
NUISANCE_QUOTIENT_COMPLETION_NOT_ESTABLISHED
CURRENT_SURROGATE_COVARIANCE_RESCUE_INFEASIBLE_AT_EVENT_SNR
DIRECTWAVE_CACHED_SAMPLE_RELATIVE_LOGPROB_DECOMPOSITION_PASS
RELEASED_WALKER_AS_CHAIN_RHAT_ADMISSION_FAIL
NETWORK_TO_SINGLE_DETECTOR_DIRECT_IMPORTANCE_SUPPORT_FAIL
CBC_NETWORK_POSTERIOR_DIRECT_IMPORTANCE_TARGET_NOT_ADMITTED
NONREGULAR_NULL_NOT_CALIBRATED
GENERATIVE_WAVEFORM_CONTRACT_INCOMPLETE
PHYSICAL_INTERPRETATION_LOCKED
```

## Read first

1. `HRF_V71_NUISANCE_QUOTIENT_COVARIANCE_AND_DECONDITIONING_GATE/GW250114_V71_ONE_PAGE_CERTIFICATE.md`
2. `HRF_V71_NUISANCE_QUOTIENT_COVARIANCE_AND_DECONDITIONING_GATE/GW250114_V71_NUISANCE_QUOTIENT_COVARIANCE_AND_DECONDITIONING_GATE.md`
3. `HRF_V71_NUISANCE_QUOTIENT_COVARIANCE_AND_DECONDITIONING_GATE/GW250114_V71_THEOREM_AND_PROOF.md`
4. `HRF_V71_NUISANCE_QUOTIENT_COVARIANCE_AND_DECONDITIONING_GATE/GW250114_V71_GENERATIVE_WAVEFORM_CONTRACT.md`
5. `HRF_V71_NUISANCE_QUOTIENT_COVARIANCE_AND_DECONDITIONING_GATE/GW250114_V71_gate_status.csv`
6. `GW250114_MASTER_PROGRESS_v65_v71_STATUS.csv`

## Next legitimate step

Provision a locked Python 3.11 reproduction environment, replay the released network direct-wave grid from raw discovery-v1 strain, build H1-only/L1-only diagnostic grids, and then obtain detector-specific remnant inference or one genuine joint likelihood. Calibrate standard-GR/no-extra-HRF detection over the complete nonregular scan before any branch selection.

## Publication decision

Do not publish a new Zenodo version from v71 alone. The next public milestone should contain a preregistered raw detector/joint execution with calibrated null and composite alternatives, or a documented negative result from that workflow.
