# Master bundle v71 release notes

v71 advances the v65–v70 chain by converting v70’s unknown-covariance caveat into an exact feasibility and nuisance-quotient gate.

The new standalone package:

- proves that a proposed completion observable has positive first-order nuisance-profiled information only when its fixed-product branch tangent lies outside the full nuisance tangent space, within the stated regular fixed-covariance mean model;
- replaces fixed-nuisance global comparison with a nuisance-image intersection test;
- derives exact log-ratio likelihood separation, covariance-rescue, common-systematic, catalog, and bias bounds;
- shows that the current audited carrier proxy cannot enter the covariance-rescue band at event-relevant SNR, even with perfect positive correlation;
- reconstructs the cached-sample H1/L1 relative log-probability decomposition encoded in the released direct-wave cache, not detector likelihood surfaces or absolute normalizations;
- shows that the released direct-wave chain fails the declared walker-as-chain rank-normalized split-Rhat admission screen and direct-importance support; the Rhat diagnostic is not by itself proof of nonconvergence;
- shows direct-importance support failure for all eight formal H1/L1 targets across four LVK network-posterior families; nonadditive stored likelihood fields keep those targets semantically nonadmitted;
- formalizes the no-extra-HRF null as nonregular and separates HRF detection, conditional branch choice, composite-alternative testing, and physical interpretation;
- adds the missing generative waveform contract and strengthens control-count, MAP/ML, PSD, DQ/injection, prior-coordinate, and trajectory-nuisance firewalls.

The package remains methods-only. Real `ln(4)`, `g=4`, area-quantization, microstate, or quantum-horizon claims remain locked.
