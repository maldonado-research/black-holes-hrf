# GW250114 master progress bundle v72

**Date:** 2026-08-17  
**Status:** mathematical/statistical methods and official-data reproducibility; no detection or discovery claim.

## Included chain

- **v65:** carrier-conditioned detection and matched branch-control calibration with source-hygiene gate.
- **v66:** finite-control confidence audit.
- **v67:** sign-locked conditional branch boundary `D=0`.
- **v68:** branch-coordinate and direct-wave model firewall.
- **v69:** exact single-delay nonidentifiability, catalog null direction, finite-SNR power audit, amplitude-normalization gauge, and observable-completion rule.
- **v70:** fail-closed official-input execution, project-timescale propagation from four official remnant-posterior families, released evolving-rate cache audit, and covariance-complete product–anchor model.
- **v71:** nuisance-quotient information theorem, global nuisance-image alias gate, covariance-rescue envelope, catalog floor/bias theorem, released cached-sample relative-log-probability decomposition, direct-importance support audit, and nonregular no-extra-HRF firewall.
- **v72:** corrected total-variation closure and composite-control theorem; distinct one-competitor and two-endpoint exclusion thresholds; least-favorable Gaussian, optimal-design, local detector-alias, and bounded-bias methods; plus a complete fixed-conditioning `-7M`, `85x40` raw-strain replay with fail-closed preflight and an independent fresh-surface comparator.

## Current decision

v72 closes the unrestricted continuous-alternative loophole at the level of a fixed statistical experiment. If admitted punctured alternatives approach the target law in total variation, an exact point target has zero uniform separation from that continuum and the randomized minimax maximum error is `1/2`. A scientifically testable continuous-target claim therefore needs a preregistered exclusion/indifference region or a normalized prior with declared scale sensitivity.

The finite-composite screen now distinguishes one named competitor from a symmetric two-sided exclusion. At the full historical log gap, the stipulated scalar log-Gaussian design threshold is `q_eff<=0.115190902%` for one preregistered competitor. Requiring 90% joint success against both exclusion endpoints gives the corrected Bonferroni threshold `q_eff<=0.100155239%`. These are design screens, not measurements of GW250114.

The complete fixed-conditioning `-7M` grid was replayed at all `85x40=3400` frequency–damping points using official H1/L1 discovery-v1 strain and the released direct-wave implementation. A fail-closed preflight checks the frozen official inputs, source identity, environment, imports, and expected data schemas before evaluation. A separately resolved fresh replay preserves the released-point surface maxima and agrees with the packaged centered surfaces within the declared comparator tolerance. This reproduces the released fixed grid; it does **not** reproduce the Nature analysis's full marginalization, template/SNR inference, or other start-time lanes.

Under one common released parameter row and preprocessing convention, the H1 and L1 conditional quadratic contributions add to the network value at machine precision. This is an implementation identity, not independent detector validation, detector-only inference, or evidence for an HRF branch. Replacing the released posterior-density proxy with the maximum-`log_likelihood` released row materially changes the surface and damping maximum. The changed row moves mass, spin, sky position, and geocentric time together, so the sensitivity is not attributable to one nuisance.

The detector-sharing theorem remains local/tangent: inconsistent detector alias coefficients can supply local shared-nuisance information, but exact global identifiability still requires a finite transformation or separated nuisance images. Detector-specific remnant/QNM inference, an HRF generative likelihood, global nonlinear nuisance distances, and nonregular-null calibration remain unexecuted. Physical interpretation remains locked.

```text
UNRESTRICTED_CONTINUOUS_TAU_UNIFORM_GATE_EXACT_FAIL
FINITE_COMPOSITE_LEAST_FAVORABLE_FRAMEWORK_PASS_METHOD_ONLY
ONE_COMPETITOR_VS_TWO_ENDPOINT_CONTROL_CORRECTED
OFFICIAL_RAW_MINUS7M_FIXED_GRID_REPRODUCTION_PASS
FAIL_CLOSED_RAW_PREFLIGHT_PASS
FRESH_RAW_SURFACE_COMPARATOR_PASS
CONDITIONAL_RAW_DETECTOR_QUADRATIC_ARITHMETIC_IDENTITY_PASS
POINT_SELECTION_SENSITIVITY_MATERIAL_NOT_RESOLVED
FULL_NATURE_INFERENCE_NOT_REPRODUCED
DETECTOR_SPECIFIC_REMNANT_INFERENCE_NOT_EXECUTED
HRF_GENERATIVE_LIKELIHOOD_NOT_EXECUTED
NONREGULAR_NULL_NOT_CALIBRATED
PHYSICAL_INTERPRETATION_LOCKED
```

## Read first

1. `HRF_V72_COMPOSITE_CLOSURE_LEAST_FAVORABLE_SEPARATION_AND_RAW_REPLAY/GW250114_V72_ONE_PAGE_CERTIFICATE.md`
2. `HRF_V72_COMPOSITE_CLOSURE_LEAST_FAVORABLE_SEPARATION_AND_RAW_REPLAY/GW250114_V72_COMPOSITE_CLOSURE_LEAST_FAVORABLE_SEPARATION_AND_RAW_REPLAY.md`
3. `HRF_V72_COMPOSITE_CLOSURE_LEAST_FAVORABLE_SEPARATION_AND_RAW_REPLAY/GW250114_V72_THEOREM_AND_PROOF.md`
4. `HRF_V72_COMPOSITE_CLOSURE_LEAST_FAVORABLE_SEPARATION_AND_RAW_REPLAY/GW250114_V72_RAW_MINUS7M_REPLAY_AUDIT.md`
5. `HRF_V72_COMPOSITE_CLOSURE_LEAST_FAVORABLE_SEPARATION_AND_RAW_REPLAY/GW250114_V72_RECOVERY_REDTEAM_AUDIT.md`
6. `HRF_V72_COMPOSITE_CLOSURE_LEAST_FAVORABLE_SEPARATION_AND_RAW_REPLAY/GW250114_V72_gate_status.csv`
7. `GW250114_MASTER_PROGRESS_v65_v72_STATUS.csv`

## Next legitimate step

Obtain detector-specific remnant/QNM inference or one genuine joint likelihood, construct and validate an HRF generative likelihood, evaluate bounded nonlinear nuisance-image separation with all active nuisances, and calibrate the standard-GR/no-extra-HRF null over the complete nonregular scan. Any proposed completion observable must demonstrate nonparallel physical response after the full nuisance tangent is included.

## Publication decision

Do not publish a new Zenodo version from v72 alone. No real `ln(4)`, `g=4`, area-quantization, black-hole microstate, or quantum-horizon inference is admitted.
