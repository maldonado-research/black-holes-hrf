# Master bundle v72 release notes

**Date:** 2026-08-17

v72 advances the v65–v71 chain by correcting the continuous-composite decision theory and completing a fail-closed, fixed-conditioning raw replay of the released `-7M` grid.

## Added

- An exact total-variation closure/minimax theorem for a point target against an unrestricted punctured continuous alternative in a fixed statistical experiment.
- Least-favorable Gaussian endpoint scores, affine nuisance-image distance, conservative finite-composite control, two-observable optimal allocation, a shared-versus-detector-specific local-alias theorem, and a bounded-bias separation frontier.
- A complete `85x40` fixed-conditioning replay of the released `-7M` frequency–damping grid on official H1/L1 discovery-v1 strain.
- A fail-closed preflight that verifies frozen input identities, expected HDF5 schemas, the pinned `qnm_filter` source, Python/runtime imports, and the resolved environment before raw evaluation.
- An independent fresh replay and numerical comparator for the centered raw surfaces, axes, maxima, and detector/network arithmetic.
- Raw H1, L1, and network conditional quadratic-contribution surfaces under common released parameters and preprocessing.
- A released posterior-density-proxy versus maximum-`log_likelihood`-row sensitivity run.
- A recovery/red-team audit and strengthened deterministic package verification.

## Corrected

- Total-variation closure now controls the full-law theorem: an exact point target cannot be uniformly separated from an unrestricted continuous alternative that excludes only the point itself.
- The one-competitor full-gap threshold `q_eff<=0.115190902%` is no longer applied to a symmetric two-sided exclusion. Two endpoint competitors require the corrected 90%-joint threshold `q_eff<=0.100155239%` in the stipulated scalar log-Gaussian design.
- The released row chosen by `argmax(log_likelihood+log_prior)` is described as a posterior-density sample proxy, not as a maximum-likelihood solution.
- Detector-sharing conclusions are explicitly local/tangent unless a finite global gauge or separated nuisance images are separately established.
- H1/L1-to-network additivity is labeled an arithmetic implementation identity, not independent detector validation or detector-only inference.
- The row-sensitivity run is described by the inputs it actually changes—mass, spin, sky position, and geocentric time together—and does not attribute the result to polarization.

## Cleared since v71

- The Python 3.11 raw-pipeline environment blocker.
- The official fixed-conditioning `-7M`, `85x40` network-grid execution blocker.
- The conditional H1/L1 quadratic-arithmetic implementation blocker for the released-point calculation.
- Fresh-replay verification of the packaged centered surfaces within the declared tolerance.

## Still locked

- The Nature paper's full inference, including marginalizations, template/SNR inference, and other start-time lanes; v72 reproduces only the declared fixed-conditioning grid.
- Absolute detector normalizations and detector-specific remnant/QNM inference.
- Real joint product–anchor covariance and bounded nonlinear nuisance-image distances.
- An HRF generative likelihood and calibrated nonregular no-extra-HRF null.
- A physically calibrated, rank-completing nonproduct observable.
- Any `ln(4)`, `g=4`, area-quantization, black-hole microstate, or quantum-horizon interpretation.

## Publication decision

No Zenodo update is recommended from v72 alone.
