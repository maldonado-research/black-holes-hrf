# GW250114 v65 — control-calibrated carrier-conditioned branch likelihood

**Status:** methods/admission-control only; not a detection claim.

## Why v65 was needed

v64 made a GR-carrier-conditioned physical-vs-neighboring-delay likelihood executable. During the next audit, a problem became clear: calibrating a branch direction only against a source-only/null off-source distribution can be misleading if the off-source branch contrast is biased by the analysis operator or source model.

v65 therefore separates the logic into three gates:

1. **Source hygiene:** require `eta_perp >= 0.90` so the GR carrier bank does not absorb the physical-vs-delay branch vector.
2. **Detection:** compare the best HRF branch against the source-only GR model and calibrate that statistic on source-only/off-source trials.
3. **Branch identity:** calibrate the physical-ln4-vs-delay contrast using matched synthetic branch controls, not by using the source-only/null branch distribution alone.

The branch contrast is still

`D = log p(d | tau0 = ln4) - log p(d | tau0 = tau_delay)`.

But the physical threshold is now chosen from the delay-control distribution so that delay controls have a pre-registered false-physical rate <= 0.10.

## Smoke-test results

The clean detector-conditioned carrier bank behaved correctly:

| Truth | detection p | detection upper95 | D_branch | verdict |
|---|---:|---:|---:|---|
| source-only/null | 0.457364 | 0.529648 | -109923.612 | NO_DETECTION_OR_POINT_ONLY |
| ln4 | 0.007752 | 0.023132 | 4052.507 | PHYSICAL_BRANCH_ADMISSIBLE_CONTROL |
| neighboring-delay | 0.007752 | 0.023132 | -3967.697 | DELAY_BRANCH_ADMISSIBLE_CONTROL |

For the clean bank:

- `eta_perp = 0.999997`
- branch AUC, ln4 vs delay controls = `1.000000`
- physical-control TPR at the delay-FPR<=0.10 threshold = `1.000000`
- delay false-physical rate = `0.093750`

The contaminated bank shows why source hygiene remains mandatory. For `network_contam`, the ln4 synthetic control has `eta_perp = 0.000005`, so the physical branch lane remains locked regardless of its likelihood score.

## Main conclusion

v65 is a claim-locking upgrade. It prevents a likelihood or branch-score win from being overinterpreted unless both of the following are true:

- the carrier bank preserves the branch vector (`eta_perp >= 0.90`), and
- branch identity is calibrated against matched branch controls, not against source-only/null off-source trials alone.

## Updated decision ladder

```text
authoritative H1/L1 real-data intake
→ official posterior HDF5 intake
→ detector-conditioned GR carrier generation
→ carrier assembly and source-hygiene eta_perp gate
→ v65 source-only/off-source detection calibration
→ v65 branch-control-calibrated physical-vs-delay gate
→ separate resampling/operator-gridlock test
→ GR-residual survival
→ amplitude-law diagnostic
→ physical interpretation only if every gate survives
```

## Current scientific status

Still no discovery claim. The old native GW250114 snapshot remains grid-favored. Source-free branch interpretation remains nonidentifiable. v65 makes the GR-conditioned route safer by requiring control-calibrated branch identity after source hygiene and detection.
