# GW250114 v65 next task

The next useful step is to connect v65 to the actual v62/v63 carrier-bank products and real H1/L1 data spectra:

1. Fetch/validate official H1/L1 strain and posterior files.
2. Generate detector-conditioned waveform carrier chunks locally with LALSuite/bilby/pycbc.
3. Assemble carrier bank with v62.
4. Run v61/v62 source-hygiene.
5. Run v64/v65 likelihood and paired branch-control calibration.

Do not publish another Zenodo version until this official-input workflow runs or the GR-conditioned branch method passes held-out waveform-family admission.
