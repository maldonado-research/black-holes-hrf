# GW250114 v65 runbook

## Purpose

Use v65 after a detector-conditioned GR carrier bank has been assembled and validated. The method is an admission-control layer; it is not event evidence by itself.

## Required gates

1. Source hygiene: eta_perp >= 0.90.
2. Detection: HRF branch model improves over source-only GR model under paired off-source/source-only calibration.
3. Branch identity: D = logL(ln4) - logL(delay) exceeds a threshold learned from matched delay controls at a pre-registered false-physical rate <= 0.10.

## Smoke test

```bash
python gw250114_v65_control_calibrated_branch_likelihood.py --run-smoke --outdir v65_outputs
```

## Real-data adaptation

For real GW250114, replace the synthetic controls with injections through the official GR posterior carrier bank and the measured noise/off-source structure. Do not use source-only/null D_branch alone to claim physical branch identity.
