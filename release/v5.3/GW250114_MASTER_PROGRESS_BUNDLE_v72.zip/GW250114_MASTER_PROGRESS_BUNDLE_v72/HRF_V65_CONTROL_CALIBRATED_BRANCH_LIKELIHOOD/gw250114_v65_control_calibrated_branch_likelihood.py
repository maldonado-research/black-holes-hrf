#!/usr/bin/env python3
"""GW250114 v65: control-calibrated carrier-conditioned branch likelihood.

This is an admission-control / methods audit, not a detection claim.

Why v65 exists
--------------
v64 made a carrier-conditioned physical-vs-delay likelihood executable, but a
branch direction calibrated only against source-only/null off trials can be
misleading if the off-source branch-contrast distribution has an analysis bias.

v65 separates the gates:
  1. detection gate: HRF-vs-source-only improvement calibrated on source-only off trials;
  2. branch gate: physical-ln4 vs neighboring-delay direction calibrated on matched
     synthetic branch controls, not on the source-only/null background alone;
  3. source-hygiene gate: eta_perp >= threshold before any branch claim is admissible.

The script can run an internal smoke test and can also score precomputed CSVs.
"""
from __future__ import annotations

import argparse, json, math, hashlib, zipfile
from pathlib import Path
from dataclasses import dataclass
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.stats import beta

LN4 = float(np.log(4.0))
T_DW = 0.003183821
FS_NATIVE = 4096.0
TAU_DELAY = float(18.0/(FS_NATIVE*T_DW))
FAMILIES = np.array(['NRSur7dq4','SEOBNRv5PHM','PhenomXPHM','PhenomXO4a'])


def cp_upper_one_sided(b: int, n: int, conf: float = 0.95) -> float:
    """One-sided Clopper-Pearson upper bound for binomial tail probability."""
    if b >= n:
        return 1.0
    return float(beta.ppf(conf, b+1, n-b))


def transfer(freq: np.ndarray, tau0: float, rho: float = 0.25, t_dw: float = T_DW) -> np.ndarray:
    t0 = 0.5*float(tau0)*float(t_dw)
    return (1.0 + float(rho)*np.exp(-2j*np.pi*freq*t0)).astype(np.complex128)


def base_carrier(freq: np.ndarray, det: str) -> np.ndarray:
    amp = (freq/100.0)**(-7.0/6.0) * np.exp(-(freq/900.0)**2)
    phase = 0.019*freq + 1.1e-5*freq**2
    if det == 'L1':
        phase = phase + 0.63 + 2*np.pi*freq*0.0069
    return (amp*np.exp(1j*phase)).astype(np.complex128)


def orthonormal_basis(vecs, tol: float = 1e-12) -> np.ndarray:
    Q = []
    for v in vecs:
        u = np.asarray(v, dtype=np.complex128).copy()
        for q in Q:
            u -= q*np.vdot(q, u)
        n = float(np.sqrt(max(np.vdot(u,u).real, 0.0)))
        if n > tol:
            Q.append(u/n)
    if not Q:
        return np.zeros((0, len(vecs[0]) if vecs else 0), dtype=np.complex128)
    return np.vstack(Q)


def project_out(v: np.ndarray, basis: np.ndarray) -> np.ndarray:
    r = np.asarray(v, dtype=np.complex128).copy()
    for q in basis:
        r -= q*np.vdot(q, r)
    return r


def make_detector_carrier_bank(kind: str, n_carriers: int = 96, n_freq: int = 512, seed: int = 1234) -> dict:
    """Build a synthetic detector-conditioned carrier bank.

    kind='clean_gr': smooth source variation orthogonal to the branch vector.
    kind='network_contam': source basis contains the physical-delay branch vector.
    kind='h1_only_contam'/'l1_only_contam': contamination in one detector sector.
    """
    rng = np.random.default_rng(seed)
    freq = np.linspace(50.0, 1024.0, n_freq)
    bh = base_carrier(freq, 'H1')
    bl = base_carrier(freq, 'L1')
    delta = transfer(freq, LN4) - transfer(freq, TAU_DELAY)
    bnet = np.r_[bh*delta, bl*delta]
    branch_net = bnet/np.sqrt(np.vdot(bnet,bnet).real)
    branch_h1 = np.r_[bh*delta, np.zeros_like(bl)]
    branch_h1 = branch_h1/np.sqrt(np.vdot(branch_h1,branch_h1).real)
    branch_l1 = np.r_[np.zeros_like(bh), bl*delta]
    branch_l1 = branch_l1/np.sqrt(np.vdot(branch_l1,branch_l1).real)

    x = (freq-freq.min())/np.ptp(freq)
    raw = []
    for k in range(1, 19):
        env = np.sin(2*np.pi*k*x).astype(np.complex128)
        env += 0.45j*np.cos(2*np.pi*(k+1)*x)
        raw.append(np.r_[bh*env*0.12, bl*np.roll(env, k % 17)*0.12])

    if kind == 'clean_gr':
        basis = orthonormal_basis([project_out(v, branch_net[None,:]) for v in raw])
    elif kind == 'network_contam':
        basis = orthonormal_basis([branch_net] + raw)
    elif kind == 'h1_only_contam':
        basis = orthonormal_basis([branch_h1] + raw)
    elif kind == 'l1_only_contam':
        basis = orthonormal_basis([branch_l1] + raw)
    else:
        raise ValueError(f'Unknown bank kind: {kind}')

    h1 = []
    l1 = []
    fam = []
    for i in range(n_carriers):
        coeff = rng.normal(0.0, 0.035, size=basis.shape[0])
        perturb = np.sum(coeff[:,None]*basis, axis=0) if basis.size else 0.0
        h1.append(bh + perturb[:n_freq])
        l1.append(bl + perturb[n_freq:])
        fam.append(FAMILIES[i % len(FAMILIES)])
    return {
        'freq': freq,
        'carrier_H1': np.asarray(h1, dtype=np.complex128),
        'carrier_L1': np.asarray(l1, dtype=np.complex128),
        'posterior_weight': np.ones(n_carriers)/n_carriers,
        'family': np.asarray(fam),
        'kind': kind,
    }


def source_hygiene_eta(bank: dict) -> float:
    freq = bank['freq']
    H1 = bank['carrier_H1']
    L1 = bank['carrier_L1']
    delta = transfer(freq, LN4) - transfer(freq, TAU_DELAY)
    base_h = H1.mean(axis=0)
    base_l = L1.mean(axis=0)
    b = np.r_[base_h*delta, base_l*delta]
    vecs = [np.r_[H1[i]-base_h, L1[i]-base_l] for i in range(H1.shape[0])]
    Q = orthonormal_basis(vecs)
    if Q.shape[0] == 0:
        return 1.0
    coeff = Q @ np.conjugate(b)  # not used directly; use vdot below for numerical clarity
    proj = np.zeros_like(b)
    for q in Q:
        proj += q*np.vdot(q, b)
    lam = float(np.vdot(proj,proj).real/np.vdot(b,b).real)
    return max(0.0, min(1.0, 1.0-lam))


def weighted_resid_logl(data_h1, data_l1, model_h1, model_l1, sigma_h1, sigma_l1) -> float:
    d = np.r_[data_h1/sigma_h1, data_l1/sigma_l1].astype(np.complex128)
    m = np.r_[model_h1/sigma_h1, model_l1/sigma_l1].astype(np.complex128)
    denom = float(np.vdot(m,m).real)
    if denom <= 0 or not np.isfinite(denom):
        return -np.inf
    a = np.vdot(m,d)/denom
    r = d - a*m
    return float(-0.5*np.vdot(r,r).real)


def logsumexp(a: np.ndarray) -> float:
    a = np.asarray(a, dtype=float)
    m = np.max(a)
    if not np.isfinite(m):
        return float(m)
    return float(m + np.log(np.sum(np.exp(a-m))))


def logl_tau(bank: dict, data: tuple, tau0: float, rho: float = 0.25) -> float:
    freq = bank['freq']
    H = transfer(freq, tau0, rho=rho)
    data_h1, data_l1, sigma_h1, sigma_l1 = data
    terms = []
    for j,w in enumerate(bank['posterior_weight']):
        ll = weighted_resid_logl(
            data_h1, data_l1,
            bank['carrier_H1'][j]*H,
            bank['carrier_L1'][j]*H,
            sigma_h1, sigma_l1,
        )
        terms.append(np.log(max(w, 1e-300)) + ll)
    return logsumexp(np.asarray(terms))


def logl_source_only(bank: dict, data: tuple) -> float:
    data_h1, data_l1, sigma_h1, sigma_l1 = data
    terms = []
    for j,w in enumerate(bank['posterior_weight']):
        ll = weighted_resid_logl(
            data_h1, data_l1,
            bank['carrier_H1'][j],
            bank['carrier_L1'][j],
            sigma_h1, sigma_l1,
        )
        terms.append(np.log(max(w, 1e-300)) + ll)
    return logsumexp(np.asarray(terms))


def make_data(bank: dict, truth: str, seed: int, noise_frac: float = 0.003, rho: float = 0.25, truth_index: int | None = None) -> tuple:
    rng = np.random.default_rng(seed)
    freq = bank['freq']
    if truth_index is None:
        truth_index = seed % bank['carrier_H1'].shape[0]
    h = bank['carrier_H1'][truth_index]
    l = bank['carrier_L1'][truth_index]
    if truth == 'ln4':
        H = transfer(freq, LN4, rho=rho)
    elif truth == 'delay':
        H = transfer(freq, TAU_DELAY, rho=rho)
    elif truth == 'source_only':
        H = np.ones_like(freq, dtype=np.complex128)
    else:
        raise ValueError(f'Unknown truth: {truth}')
    sigma0 = float(noise_frac*np.median(np.abs(np.r_[h,l])))
    sigma_h1 = np.full(freq.size, sigma0)
    sigma_l1 = np.full(freq.size, sigma0)
    nh = sigma0/np.sqrt(2)*(rng.normal(size=freq.size)+1j*rng.normal(size=freq.size))
    nl = sigma0/np.sqrt(2)*(rng.normal(size=freq.size)+1j*rng.normal(size=freq.size))
    return h*H + nh, l*H + nl, sigma_h1, sigma_l1


def score(bank: dict, data: tuple, rho: float = 0.25) -> dict:
    ll_phys = logl_tau(bank, data, LN4, rho=rho)
    ll_delay = logl_tau(bank, data, TAU_DELAY, rho=rho)
    ll_src = logl_source_only(bank, data)
    return {
        'E_detect': max(ll_phys, ll_delay) - ll_src,
        'D_branch': ll_phys - ll_delay,
        'll_phys': ll_phys,
        'll_delay': ll_delay,
        'll_source': ll_src,
    }


def auc_from_scores(pos: np.ndarray, neg: np.ndarray) -> float:
    # Probability a random positive score exceeds a random negative score, with 0.5 ties.
    pos = np.asarray(pos)
    neg = np.asarray(neg)
    greater = 0.0
    for x in pos:
        greater += np.sum(x > neg) + 0.5*np.sum(x == neg)
    return float(greater/(len(pos)*len(neg)))


def quantile_threshold_for_fpr(negative_scores: np.ndarray, target_fpr: float = 0.10) -> float:
    # threshold theta with P_neg(D > theta) <= target_fpr.
    return float(np.quantile(negative_scores, 1.0-target_fpr, method='higher'))


def run_smoke(outdir: Path, n_cal: int = 128, n_off: int = 128, noise_frac: float = 0.003,
              target_fpr: float = 0.10, eta_threshold: float = 0.90,
              alpha: float = 0.05, conf: float = 0.95) -> tuple[pd.DataFrame, pd.DataFrame]:
    outdir.mkdir(parents=True, exist_ok=True)
    summary_rows = []
    score_rows = []
    for bank_kind in ['clean_gr','network_contam','h1_only_contam','l1_only_contam']:
        bank = make_detector_carrier_bank(bank_kind)
        eta = source_hygiene_eta(bank)
        off_E = []
        off_D = []
        for i in range(n_off):
            s = score(bank, make_data(bank, 'source_only', 10000+i, noise_frac=noise_frac))
            off_E.append(s['E_detect'])
            off_D.append(s['D_branch'])
            score_rows.append({'bank_kind':bank_kind,'set':'source_only_off','truth':'source_only','seed':10000+i,**s})
        off_E = np.asarray(off_E)
        off_D = np.asarray(off_D)

        ctrl_ln4_D = []
        ctrl_delay_D = []
        ctrl_ln4_E = []
        ctrl_delay_E = []
        for i in range(n_cal):
            sl = score(bank, make_data(bank, 'ln4', 20000+i, noise_frac=noise_frac))
            sd = score(bank, make_data(bank, 'delay', 30000+i, noise_frac=noise_frac))
            ctrl_ln4_D.append(sl['D_branch'])
            ctrl_delay_D.append(sd['D_branch'])
            ctrl_ln4_E.append(sl['E_detect'])
            ctrl_delay_E.append(sd['E_detect'])
            score_rows.append({'bank_kind':bank_kind,'set':'branch_control','truth':'ln4','seed':20000+i,**sl})
            score_rows.append({'bank_kind':bank_kind,'set':'branch_control','truth':'delay','seed':30000+i,**sd})
        ctrl_ln4_D = np.asarray(ctrl_ln4_D)
        ctrl_delay_D = np.asarray(ctrl_delay_D)
        ctrl_ln4_E = np.asarray(ctrl_ln4_E)
        ctrl_delay_E = np.asarray(ctrl_delay_E)
        theta_phys = quantile_threshold_for_fpr(ctrl_delay_D, target_fpr=target_fpr)
        theta_delay = float(np.quantile(ctrl_ln4_D, target_fpr, method='lower'))
        auc = auc_from_scores(ctrl_ln4_D, ctrl_delay_D)
        tpr_phys = float(np.mean(ctrl_ln4_D > theta_phys))
        fpr_delay_as_phys = float(np.mean(ctrl_delay_D > theta_phys))
        tpr_delay = float(np.mean(ctrl_delay_D < theta_delay))
        fpr_phys_as_delay = float(np.mean(ctrl_ln4_D < theta_delay))

        for truth, seed in [('source_only',40001),('ln4',40002),('delay',40003)]:
            on = score(bank, make_data(bank, truth, seed, noise_frac=noise_frac))
            b_det = int(np.sum(off_E >= on['E_detect']))
            p_det = (b_det+1)/(n_off+1)
            u_det = cp_upper_one_sided(b_det, n_off, conf=conf)
            detection_conf_pass = (p_det < alpha) and (u_det < alpha)
            phys_branch_pass = on['D_branch'] > theta_phys
            delay_branch_pass = on['D_branch'] < theta_delay
            source_hygiene_pass = eta >= eta_threshold
            physical_claim_lane = bool(source_hygiene_pass and detection_conf_pass and phys_branch_pass and truth != 'source_only')
            delay_lane = bool(source_hygiene_pass and detection_conf_pass and delay_branch_pass and truth != 'source_only')
            if not source_hygiene_pass:
                verdict = 'LOCKED_SOURCE_HYGIENE_FAIL'
            elif not detection_conf_pass:
                verdict = 'NO_DETECTION_OR_POINT_ONLY'
            elif phys_branch_pass and not delay_branch_pass:
                verdict = 'PHYSICAL_BRANCH_ADMISSIBLE_CONTROL' if truth == 'ln4' else 'FALSE_PHYSICAL_BRANCH_ON_CONTROL'
            elif delay_branch_pass and not phys_branch_pass:
                verdict = 'DELAY_BRANCH_ADMISSIBLE_CONTROL' if truth == 'delay' else 'FALSE_DELAY_BRANCH_ON_CONTROL'
            else:
                verdict = 'BRANCH_AMBIGUOUS_AFTER_DETECTION'
            row = {
                'bank_kind': bank_kind,
                'truth': truth,
                'eta_perp': eta,
                'source_hygiene_pass': source_hygiene_pass,
                'E_detect_on': on['E_detect'],
                'D_branch_on': on['D_branch'],
                'p_detection_rank': p_det,
                'upper95_detection_tail': u_det,
                'detection_confidence_pass': detection_conf_pass,
                'theta_phys_at_fpr10': theta_phys,
                'theta_delay_at_fpr10': theta_delay,
                'branch_auc_ln4_vs_delay': auc,
                'ctrl_tpr_phys_at_theta': tpr_phys,
                'ctrl_fpr_delay_as_phys': fpr_delay_as_phys,
                'ctrl_tpr_delay_at_theta': tpr_delay,
                'ctrl_fpr_phys_as_delay': fpr_phys_as_delay,
                'phys_branch_pass_control_calibrated': phys_branch_pass,
                'delay_branch_pass_control_calibrated': delay_branch_pass,
                'physical_claim_lane_unlocked': physical_claim_lane,
                'delay_lane_unlocked': delay_lane,
                'v65_verdict': verdict,
                'n_off': n_off,
                'n_branch_control_per_class': n_cal,
                'alpha': alpha,
                'confidence': conf,
                'target_branch_fpr': target_fpr,
            }
            summary_rows.append(row)
            score_rows.append({'bank_kind':bank_kind,'set':'on_source_smoke','truth':truth,'seed':seed,**on})
    summary = pd.DataFrame(summary_rows)
    scores = pd.DataFrame(score_rows)
    summary.to_csv(outdir/'GW250114_V65_control_calibrated_summary.csv', index=False)
    scores.to_csv(outdir/'GW250114_V65_score_table.csv', index=False)
    return summary, scores


def make_plots(outdir: Path, summary: pd.DataFrame, scores: pd.DataFrame) -> None:
    outdir.mkdir(parents=True, exist_ok=True)
    # Detection/branch plane for clean bank.
    fig, ax = plt.subplots(figsize=(8,6))
    for truth in ['source_only','ln4','delay']:
        sub = scores[(scores.bank_kind=='clean_gr') & (scores.truth==truth)]
        ax.scatter(sub['D_branch'], sub['E_detect'], s=18, alpha=0.7, label=truth)
    ax.set_xlabel('D_branch = logL(ln4) - logL(delay)')
    ax.set_ylabel('E_detect = max(logL branches) - logL(source only)')
    ax.set_title('v65 clean carrier: detection vs control-calibrated branch score')
    ax.legend()
    fig.tight_layout()
    fig.savefig(outdir/'GW250114_V65_clean_detection_branch_plane.png', dpi=180)
    plt.close(fig)

    # AUC and eta plane.
    banks = summary[summary.truth=='ln4'].copy()
    fig, ax = plt.subplots(figsize=(8,5))
    ax.scatter(banks['eta_perp'], banks['branch_auc_ln4_vs_delay'], s=80)
    for _,r in banks.iterrows():
        ax.annotate(r['bank_kind'], (r['eta_perp'], r['branch_auc_ln4_vs_delay']), xytext=(5,5), textcoords='offset points')
    ax.axvline(0.90, linestyle='--')
    ax.axhline(0.90, linestyle='--')
    ax.set_xlabel('source-hygiene eta_perp')
    ax.set_ylabel('control AUC: ln4 vs delay')
    ax.set_title('v65 admission plane: source hygiene is mandatory')
    fig.tight_layout()
    fig.savefig(outdir/'GW250114_V65_admission_plane.png', dpi=180)
    plt.close(fig)

    # Verdict matrix.
    pivot = summary.pivot(index='bank_kind', columns='truth', values='v65_verdict')
    fig, ax = plt.subplots(figsize=(10,3.5))
    ax.axis('off')
    tbl = ax.table(cellText=pivot.values, rowLabels=pivot.index, colLabels=pivot.columns, loc='center')
    tbl.auto_set_font_size(False)
    tbl.set_fontsize(7)
    tbl.scale(1.0, 1.8)
    ax.set_title('v65 smoke-test verdict matrix')
    fig.tight_layout()
    fig.savefig(outdir/'GW250114_V65_verdict_matrix.png', dpi=220)
    plt.close(fig)

    # Branch control distributions for clean bank.
    fig, ax = plt.subplots(figsize=(8,5))
    sub_l = scores[(scores.bank_kind=='clean_gr') & (scores.set=='branch_control') & (scores.truth=='ln4')]
    sub_d = scores[(scores.bank_kind=='clean_gr') & (scores.set=='branch_control') & (scores.truth=='delay')]
    ax.hist(sub_l['D_branch'], bins=35, alpha=0.6, density=True, label='ln4 controls')
    ax.hist(sub_d['D_branch'], bins=35, alpha=0.6, density=True, label='delay controls')
    theta = summary[(summary.bank_kind=='clean_gr') & (summary.truth=='ln4')]['theta_phys_at_fpr10'].iloc[0]
    ax.axvline(theta, linestyle='--', label='physical threshold @ delay FPR<=0.10')
    ax.set_xlabel('D_branch')
    ax.set_ylabel('density')
    ax.set_title('v65 clean carrier: branch-control calibration')
    ax.legend()
    fig.tight_layout()
    fig.savefig(outdir/'GW250114_V65_clean_branch_control_distributions.png', dpi=180)
    plt.close(fig)


def write_reports(base: Path, summary: pd.DataFrame) -> None:
    outdir = base/'v65_outputs'
    clean_ln4 = summary[(summary.bank_kind=='clean_gr') & (summary.truth=='ln4')].iloc[0]
    clean_delay = summary[(summary.bank_kind=='clean_gr') & (summary.truth=='delay')].iloc[0]
    clean_null = summary[(summary.bank_kind=='clean_gr') & (summary.truth=='source_only')].iloc[0]
    contam_ln4 = summary[(summary.bank_kind=='network_contam') & (summary.truth=='ln4')].iloc[0]

    main = f"""# GW250114 v65 — control-calibrated carrier-conditioned branch likelihood

**Status:** methods/admission-control only; not a detection claim.

## Why v65 was needed

v64 made a GR-carrier-conditioned physical-vs-neighboring-delay likelihood executable. During the next audit, a problem became clear: calibrating a branch direction only against a source-only/null off-source distribution can be misleading if the off-source branch contrast is biased by the analysis operator or source model.

v65 therefore separates the logic into three gates:

1. **Source hygiene:** require `eta_perp >= 0.90` so the GR carrier bank does not absorb the physical-vs-delay branch vector.
2. **Detection:** compare the best HRF branch against the source-only GR model and calibrate that statistic on source-only/off-source trials.
3. **Branch identity:** calibrate the physical-ln4-vs-delay contrast using matched synthetic branch controls, not by using the source-only/null branch distribution alone.

The branch contrast is still

`D = log p(d | tau0 = ln4) - log p(d | tau0 = tau_delay)`.

But the physical threshold is now chosen from the delay-control distribution so that delay controls have a pre-registered false-physical rate <= 0.10.

## Smoke-test results

The clean detector-conditioned carrier bank behaved correctly:

| Truth | detection p | detection upper95 | D_branch | verdict |
|---|---:|---:|---:|---|
| source-only/null | {clean_null.p_detection_rank:.6f} | {clean_null.upper95_detection_tail:.6f} | {clean_null.D_branch_on:.3f} | {clean_null.v65_verdict} |
| ln4 | {clean_ln4.p_detection_rank:.6f} | {clean_ln4.upper95_detection_tail:.6f} | {clean_ln4.D_branch_on:.3f} | {clean_ln4.v65_verdict} |
| neighboring-delay | {clean_delay.p_detection_rank:.6f} | {clean_delay.upper95_detection_tail:.6f} | {clean_delay.D_branch_on:.3f} | {clean_delay.v65_verdict} |

For the clean bank:

- `eta_perp = {clean_ln4.eta_perp:.6f}`
- branch AUC, ln4 vs delay controls = `{clean_ln4.branch_auc_ln4_vs_delay:.6f}`
- physical-control TPR at the delay-FPR<=0.10 threshold = `{clean_ln4.ctrl_tpr_phys_at_theta:.6f}`
- delay false-physical rate = `{clean_ln4.ctrl_fpr_delay_as_phys:.6f}`

The contaminated bank shows why source hygiene remains mandatory. For `network_contam`, the ln4 synthetic control has `eta_perp = {contam_ln4.eta_perp:.6f}`, so the physical branch lane remains locked regardless of its likelihood score.

## Main conclusion

v65 is a claim-locking upgrade. It prevents a likelihood or branch-score win from being overinterpreted unless both of the following are true:

- the carrier bank preserves the branch vector (`eta_perp >= 0.90`), and
- branch identity is calibrated against matched branch controls, not against source-only/null off-source trials alone.

## Updated decision ladder

```text
authoritative H1/L1 real-data intake
→ official posterior HDF5 intake
→ detector-conditioned GR carrier generation
→ carrier assembly and source-hygiene eta_perp gate
→ v65 source-only/off-source detection calibration
→ v65 branch-control-calibrated physical-vs-delay gate
→ separate resampling/operator-gridlock test
→ GR-residual survival
→ amplitude-law diagnostic
→ physical interpretation only if every gate survives
```

## Current scientific status

Still no discovery claim. The old native GW250114 snapshot remains grid-favored. Source-free branch interpretation remains nonidentifiable. v65 makes the GR-conditioned route safer by requiring control-calibrated branch identity after source hygiene and detection.
"""
    (base/'GW250114_V65_CONTROL_CALIBRATED_BRANCH_LIKELIHOOD.md').write_text(main)

    runbook = """# GW250114 v65 runbook

## Purpose

Use v65 after a detector-conditioned GR carrier bank has been assembled and validated. The method is an admission-control layer; it is not event evidence by itself.

## Required gates

1. Source hygiene: eta_perp >= 0.90.
2. Detection: HRF branch model improves over source-only GR model under paired off-source/source-only calibration.
3. Branch identity: D = logL(ln4) - logL(delay) exceeds a threshold learned from matched delay controls at a pre-registered false-physical rate <= 0.10.

## Smoke test

```bash
python gw250114_v65_control_calibrated_branch_likelihood.py --run-smoke --outdir v65_outputs
```

## Real-data adaptation

For real GW250114, replace the synthetic controls with injections through the official GR posterior carrier bank and the measured noise/off-source structure. Do not use source-only/null D_branch alone to claim physical branch identity.
"""
    (base/'GW250114_V65_RUNBOOK.md').write_text(runbook)

    nexttask = """# GW250114 v65 next task

The next useful step is to connect v65 to the actual v62/v63 carrier-bank products and real H1/L1 data spectra:

1. Fetch/validate official H1/L1 strain and posterior files.
2. Generate detector-conditioned waveform carrier chunks locally with LALSuite/bilby/pycbc.
3. Assemble carrier bank with v62.
4. Run v61/v62 source-hygiene.
5. Run v64/v65 likelihood and paired branch-control calibration.

Do not publish another Zenodo version until this official-input workflow runs or the GR-conditioned branch method passes held-out waveform-family admission.
"""
    (base/'GW250114_V65_NEXT_TASK.md').write_text(nexttask)

    charter = """version: v65
status: methods_admission_only_not_detection_claim
primary_locks:
  source_hygiene_eta_perp_min: 0.90
  detection_alpha: 0.05
  detection_confidence: 0.95
  branch_control_target_false_physical_rate: 0.10
prohibited_interpretations_unless_all_gates_pass:
  - physical ln4 horizon response
  - g=4 entropy step
  - area quantization
  - quantum-horizon reflectivity
  - discovery claim
calibration_rule:
  detection_background: source-only/off-source trials
  branch_identity_background: matched synthetic ln4 and delay branch controls
"""
    (base/'HRF_v65_control_calibrated_branch_likelihood_charter.yaml').write_text(charter)


def make_zip(src_dir: Path, zip_path: Path) -> None:
    if zip_path.exists():
        zip_path.unlink()
    with zipfile.ZipFile(zip_path, 'w', compression=zipfile.ZIP_DEFLATED) as z:
        for p in src_dir.rglob('*'):
            if p.is_file():
                z.write(p, p.relative_to(src_dir.parent))


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1<<20), b''):
            h.update(chunk)
    return h.hexdigest()


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument('--run-smoke', action='store_true')
    ap.add_argument('--outdir', type=Path, default=Path('v65_outputs'))
    ap.add_argument('--base-dir', type=Path, default=Path('.'))
    ap.add_argument('--n-cal', type=int, default=128)
    ap.add_argument('--n-off', type=int, default=128)
    ap.add_argument('--noise-frac', type=float, default=0.003)
    args = ap.parse_args()
    if args.run_smoke:
        summary, scores = run_smoke(args.outdir, n_cal=args.n_cal, n_off=args.n_off, noise_frac=args.noise_frac)
        make_plots(args.outdir, summary, scores)
        print(json.dumps({
            'status':'v65 smoke complete',
            'summary_csv': str(args.outdir/'GW250114_V65_control_calibrated_summary.csv'),
            'scores_csv': str(args.outdir/'GW250114_V65_score_table.csv'),
        }, indent=2))

if __name__ == '__main__':
    main()
