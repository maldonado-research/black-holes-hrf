# GW250114 v66 — Branch-control confidence frontier and survival-gate audit

**Status:** methods/admission-control only; **not a detection claim**.

## Why v66 was needed

v65 separated source hygiene, source-only/off-source detection calibration, and branch-control calibration. It showed that a clean synthetic GR-like carrier bank can distinguish the injected `ln4` and neighboring-delay controls at the point-estimate level. v66 adds the missing finite-control uncertainty layer:

> A branch point-pass is not enough. The matched branch controls must also pass one-sided confidence bounds.

For branch identity, the two operating targets are:

```text
TPR(ln4 controls accepted as physical) >= 0.90
FPR(delay controls falsely accepted as physical) <= 0.10
```

v66 requires confidence-calibrated versions:

```text
lower95(TPR) >= 0.90
upper95(FPR) <= 0.10
```

## Re-read of v65 clean-carrier controls

For the clean GR-like synthetic carrier bank in v65:

```text
n branch controls per class = 128
observed physical-branch TPR = 1.00000
physical-branch lower95 TPR = 0.97687
observed delay→physical FPR = 0.09375
delay→physical upper95 FPR = 0.14747
```

So v65 is a **point-level branch pass**, but not yet a **confidence-level branch pass**, because the FPR upper bound is still above 0.10.

## Main v66 result

If the observed delay→physical false-positive rate remains close to v65's observed value, `12/128 = 0.09375`, then many more controls are required to certify the true FPR is below 0.10. Exact Clopper–Pearson calculations give:

```text
observed FPR 0.05000 → minimum n ≈ 76 controls/class for upper95 <= 0.10
observed FPR 0.07500 → minimum n ≈ 333 controls/class for upper95 <= 0.10
observed FPR 0.09375 → minimum n ≈ 6026 controls/class for upper95 <= 0.10
```

This means the practical next step is **not** to interpret the v65 branch result. The next step is to either:

1. choose a stricter threshold that drives the observed branch-control FPR down, or
2. run substantially more held-out matched branch controls, or
3. both.

## Recommended two-stage branch calibration

v66 recommends a nested calibration structure:

1. **Training controls:** choose the physical/delay branch threshold, aiming for observed FPR around 0.05 or lower.
2. **Held-out controls:** certify:
   - `lower95(TPR) >= 0.90`
   - `upper95(FPR) <= 0.10`
3. Only after that may a real on-source branch likelihood be interpreted.

This prevents threshold tuning on the same controls used to certify branch identity.

## Current status

- No discovery claim.
- The old native GW250114 snapshot remains grid-favored.
- Source-free branch interpretation remains nonidentifiable.
- v65 made the GR-conditioned branch likelihood executable.
- v66 shows that finite branch-control uncertainty still locks the physical interpretation lane until matched control calibration is confidence-level, not just point-level.

## Files in this v66 bundle

- `GW250114_V66_v65_branch_control_confidence.csv`
- `GW250114_V66_v65_detection_confidence.csv`
- `GW250114_V66_branch_control_sample_requirements.csv`
- `GW250114_V66_two_stage_branch_calibration_plan.csv`
- `GW250114_V66_external_pack_triage.csv`
- plots for FPR/TPR/detection confidence frontiers and decision ladder
