# GW250114 v66 next task

The next productive task is a larger branch-control calibration run.

Recommended development target:

```text
n_source_only_off >= 300
n_ln4_branch_controls >= 300
n_delay_branch_controls >= 300
```

Recommended stronger target:

```text
n_source_only_off >= 1000
n_ln4_branch_controls >= 1000
n_delay_branch_controls >= 1000
```

The threshold should be trained on one half of branch controls and certified on the other half. A physical branch claim remains locked unless the held-out controls satisfy:

```text
lower95(TPR_ln4) >= 0.90
upper95(FPR_delay_as_physical) <= 0.10
```

This should be run only after official H1/L1 strain and official posterior/carrier products are available, or as a synthetic admission test for the v65/v64 method.
