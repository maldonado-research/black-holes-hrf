# GW250114 v66 runbook — branch-control confidence gate

1. Generate or collect matched branch controls:
   - `ln4` controls
   - neighboring physical-delay controls
   - source-only/off-source controls for detection calibration

2. Split branch controls into two disjoint sets:
   - training threshold controls
   - held-out certification controls

3. On the training set, choose a threshold for the physical branch. Do not use real event data for this choice.

4. On the held-out set, compute:
   - observed TPR for ln4 controls
   - observed FPR for delay controls falsely called physical
   - one-sided 95% Clopper–Pearson lower bound for TPR
   - one-sided 95% Clopper–Pearson upper bound for FPR

5. Admit physical branch interpretation only if:
   - source hygiene passes
   - detection calibration passes
   - held-out TPR lower95 >= 0.90
   - held-out FPR upper95 <= 0.10

6. If the FPR point estimate is near 0.10, do not interpret the branch result. Either lower the threshold or increase branch-control count.
