import os, json, math, zipfile, shutil, textwrap
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.stats import beta

OUT = Path('/mnt/data/HRF_V66_BRANCH_CONTROL_CONFIDENCE')
OUT.mkdir(exist_ok=True)
(OUT/'v66_outputs').mkdir(exist_ok=True)

alpha = 0.05
conf = 0.95
fpr_target = 0.10
tpr_target = 0.90
v65_sum_path = Path('/mnt/data/HRF_V65_CONTROL_CALIBRATED_BRANCH_LIKELIHOOD/v65_outputs/GW250114_V65_control_calibrated_summary.csv')
v65_scores_path = Path('/mnt/data/HRF_V65_CONTROL_CALIBRATED_BRANCH_LIKELIHOOD/v65_outputs/GW250114_V65_score_table.csv')
summary = pd.read_csv(v65_sum_path) if v65_sum_path.exists() else pd.DataFrame()

def cp_upper(k,n,alpha=0.05):
    if n <= 0: return np.nan
    if k >= n: return 1.0
    return float(beta.ppf(1-alpha, k+1, n-k))

def cp_lower(k,n,alpha=0.05):
    if n <= 0: return np.nan
    if k <= 0: return 0.0
    return float(beta.ppf(alpha, k, n-k+1))

# Recompute branch control confidence rows from v65 summary fields.
rows=[]
if not summary.empty:
    for bank in sorted(summary['bank_kind'].unique()):
        sub=summary[summary.bank_kind==bank]
        # use fields same across truth rows
        r=sub.iloc[0]
        n=int(r['n_branch_control_per_class'])
        fpr_phys=float(r['ctrl_fpr_delay_as_phys'])
        fpr_delay=float(r['ctrl_fpr_phys_as_delay'])
        tpr_phys=float(r['ctrl_tpr_phys_at_theta'])
        tpr_delay=float(r['ctrl_tpr_delay_at_theta'])
        vals=[('physical_branch', tpr_phys, fpr_phys), ('delay_branch', tpr_delay, fpr_delay)]
        for branch,tpr,fpr in vals:
            k_fpr=int(round(fpr*n)); k_tpr=int(round(tpr*n))
            rows.append({
                'bank_kind':bank,'branch':branch,'n_controls_per_class':n,
                'source_hygiene_pass':bool(r['source_hygiene_pass']),
                'eta_perp':float(r['eta_perp']),
                'observed_tpr':tpr,'observed_fpr':fpr,
                'tpr_successes':k_tpr,'fpr_false_positives':k_fpr,
                'tpr_cp_lower95':cp_lower(k_tpr,n,alpha),
                'fpr_cp_upper95':cp_upper(k_fpr,n,alpha),
                'point_tpr_pass': tpr >= tpr_target,
                'point_fpr_pass': fpr <= fpr_target,
                'confidence_tpr_pass': cp_lower(k_tpr,n,alpha) >= tpr_target,
                'confidence_fpr_pass': cp_upper(k_fpr,n,alpha) <= fpr_target,
                'branch_confidence_admitted': bool(r['source_hygiene_pass']) and cp_lower(k_tpr,n,alpha) >= tpr_target and cp_upper(k_fpr,n,alpha) <= fpr_target,
            })
branch_conf=pd.DataFrame(rows)
branch_conf.to_csv(OUT/'v66_outputs'/'GW250114_V66_v65_branch_control_confidence.csv',index=False)

# detection confidence rows
rows=[]
if not summary.empty:
    for _,r in summary.iterrows():
        n=int(r['n_off'])
        p=float(r['p_detection_rank'])
        # p=(b+1)/(n+1) => b = p*(n+1)-1
        b=int(round(p*(n+1)-1))
        rows.append({
            'bank_kind':r['bank_kind'], 'truth':r['truth'], 'n_off':n,
            'p_detection_rank':p, 'exceedances':b,
            'upper95_tail':cp_upper(b,n,alpha),
            'point_pass_alpha_0p05':p<0.05,
            'confidence_pass_alpha_0p05':cp_upper(b,n,alpha)<0.05,
            'confidence_pass_alpha_0p01':cp_upper(b,n,alpha)<0.01,
        })
detect_conf=pd.DataFrame(rows)
detect_conf.to_csv(OUT/'v66_outputs'/'GW250114_V66_v65_detection_confidence.csv',index=False)

# exact sample requirement tables for branch controls.
def min_n_for_fpr_upper(observed_rate, target=0.1, nmax=200000):
    for n in range(1,nmax+1):
        k=math.floor(observed_rate*n + 1e-12)
        if cp_upper(k,n,alpha) <= target:
            return n,k,cp_upper(k,n,alpha)
    return None,None,None

def min_n_for_tpr_lower(observed_rate, target=0.9, nmax=200000):
    for n in range(1,nmax+1):
        k=math.ceil(observed_rate*n - 1e-12)
        if k>n: k=n
        if cp_lower(k,n,alpha) >= target:
            return n,k,cp_lower(k,n,alpha)
    return None,None,None

fpr_rates=[0.0,0.005,0.01,0.02,0.025,0.05,0.075,0.09,0.09375,0.095,0.099]
tpr_rates=[1.0,0.99,0.98,0.975,0.95,0.925,0.91,0.90]
req_rows=[]
for q in fpr_rates:
    n,k,u=min_n_for_fpr_upper(q,fpr_target)
    req_rows.append({'gate':'FPR upper95 <= 0.10','observed_rate_assumption':q,'minimum_n':n,'count_at_min_n':k,'bound_at_min_n':u})
for q in tpr_rates:
    n,k,l=min_n_for_tpr_lower(q,tpr_target)
    req_rows.append({'gate':'TPR lower95 >= 0.90','observed_rate_assumption':q,'minimum_n':n,'count_at_min_n':k,'bound_at_min_n':l})
req_df=pd.DataFrame(req_rows)
req_df.to_csv(OUT/'v66_outputs'/'GW250114_V66_branch_control_sample_requirements.csv',index=False)

# two-stage calibration plan table
plan_rows=[]
for design_fpr in [0.0,0.01,0.02,0.025,0.05,0.075]:
    n,k,u=min_n_for_fpr_upper(design_fpr,fpr_target)
    plan_rows.append({'calibration_role':'held_out_branch_controls','design_observed_fpr':design_fpr,'target_certified_fpr_upper95':fpr_target,'minimum_controls_per_class':n,'max_false_positives_at_min_n':k,'upper95_at_min_n':u})
for design_tpr in [1.0,0.99,0.98,0.975,0.95,0.925]:
    n,k,l=min_n_for_tpr_lower(design_tpr,tpr_target)
    plan_rows.append({'calibration_role':'held_out_branch_controls','design_observed_tpr':design_tpr,'target_certified_tpr_lower95':tpr_target,'minimum_controls_per_class':n,'min_successes_at_min_n':k,'lower95_at_min_n':l})
plan_df=pd.DataFrame(plan_rows)
plan_df.to_csv(OUT/'v66_outputs'/'GW250114_V66_two_stage_branch_calibration_plan.csv',index=False)

# make plots
plt.figure(figsize=(8,5))
ns=np.arange(10,5001)
for q in [0.0,0.01,0.025,0.05,0.075,0.09375]:
    upp=[cp_upper(int(math.floor(q*n+1e-12)), int(n), alpha) for n in ns]
    plt.plot(ns, upp, label=f'observed FPR≈{q:g}')
plt.axhline(fpr_target, linestyle='--')
plt.yscale('log')
plt.xlabel('held-out controls per branch class')
plt.ylabel('one-sided 95% upper bound on true FPR')
plt.title('v66 branch false-positive confidence frontier')
plt.legend(fontsize=8)
plt.tight_layout()
plt.savefig(OUT/'v66_outputs'/'GW250114_V66_fpr_confidence_frontier.png', dpi=160)
plt.close()

plt.figure(figsize=(8,5))
ns=np.arange(10,5001)
for q in [1.0,0.99,0.98,0.95,0.925]:
    lows=[cp_lower(min(int(math.ceil(q*n-1e-12)), int(n)), int(n), alpha) for n in ns]
    plt.plot(ns,lows,label=f'observed TPR≈{q:g}')
plt.axhline(tpr_target, linestyle='--')
plt.xlabel('held-out controls per branch class')
plt.ylabel('one-sided 95% lower bound on true TPR')
plt.title('v66 branch true-positive confidence frontier')
plt.legend(fontsize=8)
plt.tight_layout()
plt.savefig(OUT/'v66_outputs'/'GW250114_V66_tpr_confidence_frontier.png', dpi=160)
plt.close()

# v65 bank confidence plane
if not branch_conf.empty:
    plt.figure(figsize=(8,6))
    # plot only physical branch rows for readability
    dfp=branch_conf[branch_conf.branch=='physical_branch'].copy()
    for _,r in dfp.iterrows():
        label=r['bank_kind']
        plt.errorbar(r['observed_fpr'], r['observed_tpr'],
                     xerr=[[max(0, r['observed_fpr']-0)],[max(0, r['fpr_cp_upper95']-r['observed_fpr'])]],
                     yerr=[[max(0, r['observed_tpr']-r['tpr_cp_lower95'])],[max(0, 1-r['observed_tpr'])]],
                     fmt='o')
        plt.text(r['observed_fpr']+0.003, r['observed_tpr']-0.01, label, fontsize=8)
    plt.axvline(fpr_target, linestyle='--')
    plt.axhline(tpr_target, linestyle='--')
    plt.xlim(-0.01, max(0.2, dfp['fpr_cp_upper95'].max()+0.02))
    plt.ylim(0.85, 1.01)
    plt.xlabel('observed / bounded delay→physical false-positive rate')
    plt.ylabel('observed / bounded ln4 true-positive rate')
    plt.title('v66 v65 physical-branch control calibration: point pass vs confidence pass')
    plt.tight_layout()
    plt.savefig(OUT/'v66_outputs'/'GW250114_V66_v65_branch_confidence_plane.png', dpi=160)
    plt.close()

# detection off-source frontier
plt.figure(figsize=(8,5))
ns=np.arange(10,5001)
for b in [0,1,2,5,10]:
    upp=[cp_upper(min(b,int(n)), int(n), alpha) for n in ns]
    plt.plot(ns,upp,label=f'exceedances={b}')
plt.axhline(0.05, linestyle='--')
plt.axhline(0.01, linestyle=':')
plt.yscale('log')
plt.xlabel('source-only/off-source trials')
plt.ylabel('one-sided 95% upper bound on tail probability')
plt.title('v66 detection finite-background confidence frontier')
plt.legend(fontsize=8)
plt.tight_layout()
plt.savefig(OUT/'v66_outputs'/'GW250114_V66_detection_confidence_frontier.png',dpi=160)
plt.close()

# Decision diagram as simple text plot
fig, ax = plt.subplots(figsize=(10,4.5))
ax.axis('off')
steps=[
    'official H1/L1 + posterior intake',
    'detector-carrier source hygiene η⊥≥0.90',
    'source-only paired detection: p + upper-tail pass',
    'branch controls: TPR lower95≥0.90 and FPR upper95≤0.10',
    'real on-source physical-vs-delay branch likelihood',
    'resampling/operator-gridlock + GR residual + amplitude law'
]
y=0.92
for i,s in enumerate(steps):
    ax.text(0.05,y,f'{i+1}. {s}',fontsize=11, va='center', bbox=dict(boxstyle='round', alpha=0.12))
    if i<len(steps)-1:
        ax.annotate('', xy=(0.5,y-0.085), xytext=(0.5,y-0.025), arrowprops=dict(arrowstyle='->'))
    y-=0.15
ax.set_title('v66 control-confidence gate order', fontsize=14)
plt.tight_layout()
plt.savefig(OUT/'v66_outputs'/'GW250114_V66_control_confidence_decision_ladder.png',dpi=160)
plt.close()

# External pack triage from new uploads.
triage = [
    {'pack':'DMDE_upgrade_pack_v0.9.11_spectral_survival_thresholds_2026-07-02.zip','used_for':'method analogy: survival thresholds and provider-style pass/fail gates','merged_into_HRF_physics':'no','reason':'Useful statistical discipline; no direct GW250114 physics content.'},
    {'pack':'v1.14_highq_factorization_test_bundle.zip','used_for':'method analogy: factorization gates / leakage catalog mindset','merged_into_HRF_physics':'no','reason':'No direct official GW data or GR posterior content; useful only as inspiration for leakage/factorization audits.'},
    {'pack':'HDBLAST_PHYS_M221_M224_MOMENTUM_SOURCE_OPERATOR_KIT.zip','used_for':'method analogy: source/momentum operator boundary discipline','merged_into_HRF_physics':'no','reason':'Theory-only pack; does not improve the carrier-conditioned branch likelihood without official inputs.'},
    {'pack':'HDBLAST_PHYS_M221_M224_MOMENTUM_SOURCE_SPIN2_LEDGER_AND_CONSTRAINT_COUNTERTERM_AUDIT_THEORY_ONLY_NO_V432_20260707.zip','used_for':'method analogy: constraint/counterterm non-promotion discipline','merged_into_HRF_physics':'no','reason':'Theory-only; helps keep claim boundary locked but is not empirical HRF evidence.'},
    {'pack':'TOE_TierE_v260_parent_lock_marked_Bockstein_label_rigidity_gate_2026-07-06.zip','used_for':'method analogy: parent-lock / rigidity-gate vocabulary','merged_into_HRF_physics':'no','reason':'Abstract formal pack; no direct GW250114 likelihood or waveform-posterior role.'},
]
pd.DataFrame(triage).to_csv(OUT/'v66_outputs'/'GW250114_V66_external_pack_triage.csv',index=False)

# Write scripts (this builder as reproducible script)
import inspect
# Save simplified script (copy self)
this = Path('/tmp/build_v66.py').read_text()
(OUT/'gw250114_v66_control_confidence_audit.py').write_text(this)

# YAML charter
charter = f"""
name: GW250114 v66 branch-control confidence charter
version: v66
status: methods/admission-control; not a detection claim
alpha: {alpha}
confidence: {conf}
branch_fpr_target: {fpr_target}
branch_tpr_target: {tpr_target}
rules:
  - source_hygiene_must_pass: eta_perp >= 0.90
  - detection_must_be_calibrated_on_source_only_off_trials: true
  - branch_identity_must_be_calibrated_on_matched_ln4_and_delay_controls: true
  - branch_point_pass_is_not_enough: true
  - physical_claim_requires:
      - detection_upper95_tail < 0.05
      - physical_control_tpr_lower95 >= 0.90
      - delay_control_false_physical_upper95 <= 0.10
      - source_hygiene_pass == true
""".strip()+"\n"
(OUT/'HRF_v66_control_confidence_charter.yaml').write_text(charter)

# Reports.
# Extract a few numbers for report
clean_phys = branch_conf[(branch_conf.bank_kind=='clean_gr') & (branch_conf.branch=='physical_branch')].iloc[0] if not branch_conf.empty else None
clean_delay = branch_conf[(branch_conf.bank_kind=='clean_gr') & (branch_conf.branch=='delay_branch')].iloc[0] if not branch_conf.empty else None
req_005 = req_df[(req_df.gate=='FPR upper95 <= 0.10') & (req_df.observed_rate_assumption==0.05)].iloc[0]
req_0075 = req_df[(req_df.gate=='FPR upper95 <= 0.10') & (req_df.observed_rate_assumption==0.075)].iloc[0]
req_009375 = req_df[(req_df.gate=='FPR upper95 <= 0.10') & (req_df.observed_rate_assumption==0.09375)].iloc[0]

report = f"""# GW250114 v66 — Branch-control confidence frontier and survival-gate audit

**Status:** methods/admission-control only; **not a detection claim**.

## Why v66 was needed

v65 separated source hygiene, source-only/off-source detection calibration, and branch-control calibration. It showed that a clean synthetic GR-like carrier bank can distinguish the injected `ln4` and neighboring-delay controls at the point-estimate level. v66 adds the missing finite-control uncertainty layer:

> A branch point-pass is not enough. The matched branch controls must also pass one-sided confidence bounds.

For branch identity, the two operating targets are:

```text
TPR(ln4 controls accepted as physical) >= 0.90
FPR(delay controls falsely accepted as physical) <= 0.10
```

v66 requires confidence-calibrated versions:

```text
lower95(TPR) >= 0.90
upper95(FPR) <= 0.10
```

## Re-read of v65 clean-carrier controls

For the clean GR-like synthetic carrier bank in v65:

```text
n branch controls per class = {int(clean_phys['n_controls_per_class']) if clean_phys is not None else 'NA'}
observed physical-branch TPR = {clean_phys['observed_tpr']:.5f}
physical-branch lower95 TPR = {clean_phys['tpr_cp_lower95']:.5f}
observed delay→physical FPR = {clean_phys['observed_fpr']:.5f}
delay→physical upper95 FPR = {clean_phys['fpr_cp_upper95']:.5f}
```

So v65 is a **point-level branch pass**, but not yet a **confidence-level branch pass**, because the FPR upper bound is still above 0.10.

## Main v66 result

If the observed delay→physical false-positive rate remains close to v65's observed value, `12/128 = 0.09375`, then many more controls are required to certify the true FPR is below 0.10. Exact Clopper–Pearson calculations give:

```text
observed FPR 0.05000 → minimum n ≈ {int(req_005['minimum_n'])} controls/class for upper95 <= 0.10
observed FPR 0.07500 → minimum n ≈ {int(req_0075['minimum_n'])} controls/class for upper95 <= 0.10
observed FPR 0.09375 → minimum n ≈ {int(req_009375['minimum_n'])} controls/class for upper95 <= 0.10
```

This means the practical next step is **not** to interpret the v65 branch result. The next step is to either:

1. choose a stricter threshold that drives the observed branch-control FPR down, or
2. run substantially more held-out matched branch controls, or
3. both.

## Recommended two-stage branch calibration

v66 recommends a nested calibration structure:

1. **Training controls:** choose the physical/delay branch threshold, aiming for observed FPR around 0.05 or lower.
2. **Held-out controls:** certify:
   - `lower95(TPR) >= 0.90`
   - `upper95(FPR) <= 0.10`
3. Only after that may a real on-source branch likelihood be interpreted.

This prevents threshold tuning on the same controls used to certify branch identity.

## Current status

- No discovery claim.
- The old native GW250114 snapshot remains grid-favored.
- Source-free branch interpretation remains nonidentifiable.
- v65 made the GR-conditioned branch likelihood executable.
- v66 shows that finite branch-control uncertainty still locks the physical interpretation lane until matched control calibration is confidence-level, not just point-level.

## Files in this v66 bundle

- `GW250114_V66_v65_branch_control_confidence.csv`
- `GW250114_V66_v65_detection_confidence.csv`
- `GW250114_V66_branch_control_sample_requirements.csv`
- `GW250114_V66_two_stage_branch_calibration_plan.csv`
- `GW250114_V66_external_pack_triage.csv`
- plots for FPR/TPR/detection confidence frontiers and decision ladder
"""
(OUT/'GW250114_V66_BRANCH_CONTROL_CONFIDENCE_FRONTIER.md').write_text(report)

runbook = """# GW250114 v66 runbook — branch-control confidence gate

1. Generate or collect matched branch controls:
   - `ln4` controls
   - neighboring physical-delay controls
   - source-only/off-source controls for detection calibration

2. Split branch controls into two disjoint sets:
   - training threshold controls
   - held-out certification controls

3. On the training set, choose a threshold for the physical branch. Do not use real event data for this choice.

4. On the held-out set, compute:
   - observed TPR for ln4 controls
   - observed FPR for delay controls falsely called physical
   - one-sided 95% Clopper–Pearson lower bound for TPR
   - one-sided 95% Clopper–Pearson upper bound for FPR

5. Admit physical branch interpretation only if:
   - source hygiene passes
   - detection calibration passes
   - held-out TPR lower95 >= 0.90
   - held-out FPR upper95 <= 0.10

6. If the FPR point estimate is near 0.10, do not interpret the branch result. Either lower the threshold or increase branch-control count.
"""
(OUT/'GW250114_V66_RUNBOOK.md').write_text(runbook)

next_task = """# GW250114 v66 next task

The next productive task is a larger branch-control calibration run.

Recommended development target:

```text
n_source_only_off >= 300
n_ln4_branch_controls >= 300
n_delay_branch_controls >= 300
```

Recommended stronger target:

```text
n_source_only_off >= 1000
n_ln4_branch_controls >= 1000
n_delay_branch_controls >= 1000
```

The threshold should be trained on one half of branch controls and certified on the other half. A physical branch claim remains locked unless the held-out controls satisfy:

```text
lower95(TPR_ln4) >= 0.90
upper95(FPR_delay_as_physical) <= 0.10
```

This should be run only after official H1/L1 strain and official posterior/carrier products are available, or as a synthetic admission test for the v65/v64 method.
"""
(OUT/'GW250114_V66_NEXT_TASK.md').write_text(next_task)

# Zip outputs
zip_path=Path('/mnt/data/HRF_V66_BRANCH_CONTROL_CONFIDENCE.zip')
if zip_path.exists(): zip_path.unlink()
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
    for p in OUT.rglob('*'):
        z.write(p, p.relative_to(OUT.parent))
# master bundle combine v65 and v66 maybe just include v66 plus critical v65 summaries
master=Path('/mnt/data/GW250114_MASTER_PROGRESS_BUNDLE_v66.zip')
if master.exists(): master.unlink()
with zipfile.ZipFile(master,'w',zipfile.ZIP_DEFLATED) as z:
    for base in [OUT, Path('/mnt/data/HRF_V65_CONTROL_CALIBRATED_BRANCH_LIKELIHOOD')]:
        if base.exists():
            for p in base.rglob('*'):
                if p.is_file():
                    z.write(p, p.relative_to('/mnt/data'))

# Integrity test
for z in [zip_path, master]:
    with zipfile.ZipFile(z) as zz:
        bad=zz.testzip()
        assert bad is None, f'Bad file in zip: {bad}'
print('wrote', zip_path, master)
print(branch_conf.to_string(index=False))
print(req_df.to_string(index=False))
