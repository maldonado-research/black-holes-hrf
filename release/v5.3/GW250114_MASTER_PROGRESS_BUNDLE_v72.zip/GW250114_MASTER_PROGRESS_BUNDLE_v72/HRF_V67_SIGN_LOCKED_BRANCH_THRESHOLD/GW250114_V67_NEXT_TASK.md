# GW250114 v67 next task

The next useful step is **v68: sign-locked branch likelihood on official-input products**.

Required inputs:

- H-H1_GWOSC_O4b_4KHZ_R1-1420877824-4096.hdf5
- L-L1_GWOSC_O4b_4KHZ_R1-1420877824-4096.hdf5
- posterior_samples_NRSur7dq4.h5
- posterior_samples_PhenomXO4a.h5
- posterior_samples_PhenomXPHM.h5
- posterior_samples_SEOBNRv5PHM.h5

Method order:

```text
official input validation
→ posterior schema probe
→ detector carrier-bank generation
→ eta_perp source hygiene
→ source-only detection calibration
→ D=0 sign-locked branch-control confidence certification
→ real on-source D_branch evaluation
```
