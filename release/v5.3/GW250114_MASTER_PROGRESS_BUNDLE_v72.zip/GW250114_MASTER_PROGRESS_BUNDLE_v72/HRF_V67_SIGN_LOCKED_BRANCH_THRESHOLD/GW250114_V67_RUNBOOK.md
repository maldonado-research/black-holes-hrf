# GW250114 v67 runbook

1. Compute or load a branch score table with columns `bank_kind`, `set`, `truth`, and `D_branch`.
2. Use `D_branch > 0` as the primary physical-branch rule. Do not tune the physical/delay threshold on the same controls used for certification.
3. For matched branch controls, certify:
   - `lower95(TPR_ln4) >= 0.90`
   - `upper95(FPR_delay_as_physical) <= 0.10`
4. Keep source-hygiene as a hard upstream lock: `eta_perp >= 0.90` is required before branch interpretation.
5. Apply the sign-locked threshold to real on-source data only after real-data/provenance, posterior, carrier, hygiene, and detection gates pass.

Command:

```bash
python gw250114_v67_sign_locked_branch_threshold.py   --score-table /path/to/GW250114_V65_score_table.csv   --summary-table /path/to/GW250114_V65_control_calibrated_summary.csv   --outdir v67_outputs
```
