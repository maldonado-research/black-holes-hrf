# GW250114 v67 — Sign-locked branch threshold and confidence-gate repair

**Status:** methods/admission-control only; **not a detection claim**.

## Why v67 was needed

v66 correctly noticed that the v65 branch-control calibration did not pass finite-control confidence at the empirical `FPR10` threshold.  However, v65 used a threshold chosen from the delay-control distribution.  For the actual branch likelihood contrast,

```text
D = log p(d | tau0 = ln4) - log p(d | tau0 = tau_delay),
```

the natural equal-prior branch boundary is not an empirical quantile.  It is exactly:

```text
D = 0.
```

Positive `D` favors the physical `ln4` branch.  Negative `D` favors the neighboring physical-delay / gridlike branch.  This sign-locked threshold is preregisterable, interpretable as a Bayes-factor boundary, and does not tune on branch controls.

## Main result on the v65 clean carrier-bank controls

Using the sign-locked threshold `D > 0` on the clean GR-like synthetic carrier bank:

```text
ln4 controls accepted as physical: 128/128
delay controls falsely accepted as physical: 0/128
observed TPR = 1.000000
lower95 TPR = 0.976868
observed FPR = 0.000000
upper95 FPR = 0.023132
status = PASS_CONFIDENCE_BRANCH_GATE
```

This passes the v66 confidence rule:

```text
lower95(TPR_ln4) >= 0.90
upper95(FPR_delay_as_physical) <= 0.10
```

By comparison, the older v65 empirical `FPR10` threshold gave:

```text
observed FPR = 0.093750
upper95 FPR = 0.147468
status = FAIL_FPR_CONFIDENCE
```

So v67 repairs the specific v66 failure by replacing a control-quantile threshold with the physically meaningful log-likelihood sign threshold.

## Important safety condition

This does **not** unlock the real GW250114 claim lane.  The sign-locked branch rule is only admitted after all upstream gates pass:

```text
real-data intake
→ official posterior intake
→ detector-conditioned GR carrier generation
→ source-hygiene eta_perp >= 0.90
→ source-only/off-source detection calibration
→ sign-locked branch-control confidence gate
→ real on-source branch likelihood
→ resampling/operator-gridlock test
→ GR-residual and amplitude-law checks
```

For contaminated synthetic carrier banks, the sign threshold may still classify branch controls correctly, but those banks remain locked by source hygiene.  This is deliberate.  A branch-likelihood win is not enough if the carrier basis can absorb or mimic the HRF branch vector.

## Current interpretation

- No discovery claim.
- The old native GW250114 snapshot remains grid-favored.
- Source-free branch interpretation remains nonidentifiable.
- v65 made the GR-conditioned branch likelihood executable.
- v66 added confidence-level branch-control requirements.
- v67 shows that the correct preregistered branch boundary is `D=0`, and on the clean synthetic carrier bank it passes the confidence rule.

## Files produced

- `GW250114_V67_sign_locked_branch_metrics.csv`
- `GW250114_V67_on_source_smoke_classification.csv`
- `GW250114_V67_clean_branch_distribution_sign_threshold.png`
- `GW250114_V67_threshold_confidence_comparison.png`
- `GW250114_V67_sign_locked_admission_plane.png`
- `GW250114_V67_sign_margin_by_bank.png`
