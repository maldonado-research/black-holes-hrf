#!/usr/bin/env python3
"""
GW250114 v67 — sign-locked branch-threshold audit.

Purpose
-------
Re-read the v65/v66 branch-control outputs and compare:
  1. the natural, preregistered sign threshold D>0 for physical ln4, and
  2. the v65 empirical FPR10 quantile threshold.

D = log p(d | tau=ln4) - log p(d | tau=neighboring delay).
For equal prior odds, D=0 is the Bayes-factor neutrality point.  Therefore
D>0 is a natural branch-identity rule that does not need threshold tuning on
branch controls.

This script produces CSVs, plots, and a Markdown report.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Dict, Tuple

import numpy as np
import pandas as pd
from scipy.stats import beta
import matplotlib.pyplot as plt


def lower_cp(successes: int, n: int, conf: float = 0.95) -> float:
    """One-sided lower Clopper-Pearson bound for a binomial proportion."""
    alpha = 1.0 - conf
    if n <= 0:
        return float("nan")
    if successes <= 0:
        return 0.0
    return float(beta.ppf(alpha, successes, n - successes + 1))


def upper_cp(successes: int, n: int, conf: float = 0.95) -> float:
    """One-sided upper Clopper-Pearson bound for a binomial proportion."""
    alpha = 1.0 - conf
    if n <= 0:
        return float("nan")
    if successes >= n:
        return 1.0
    return float(beta.ppf(conf, successes + 1, n - successes))


def classify_status(source_hygiene: bool, lower_tpr: float, upper_fpr: float,
                    target_tpr: float = 0.90, target_fpr: float = 0.10) -> str:
    if not source_hygiene:
        return "LOCKED_SOURCE_HYGIENE_FAIL"
    if lower_tpr >= target_tpr and upper_fpr <= target_fpr:
        return "PASS_CONFIDENCE_BRANCH_GATE"
    if lower_tpr >= target_tpr:
        return "FAIL_FPR_CONFIDENCE"
    if upper_fpr <= target_fpr:
        return "FAIL_TPR_CONFIDENCE"
    return "FAIL_TPR_AND_FPR_CONFIDENCE"


def compute_metrics(score: pd.DataFrame, summary: pd.DataFrame, conf: float = 0.95) -> pd.DataFrame:
    rows = []
    bank_rows = summary.drop_duplicates("bank_kind").set_index("bank_kind")

    for bank, g in score.groupby("bank_kind"):
        bc = g[g["set"].eq("branch_control")].copy()
        ln4 = bc[bc["truth"].eq("ln4")]["D_branch"].to_numpy()
        delay = bc[bc["truth"].eq("delay")]["D_branch"].to_numpy()
        if len(ln4) == 0 or len(delay) == 0:
            continue
        source_hygiene = bool(bank_rows.loc[bank, "source_hygiene_pass"])
        eta = float(bank_rows.loc[bank, "eta_perp"])
        v65_theta = float(bank_rows.loc[bank, "theta_phys_at_fpr10"])

        thresholds = {
            "sign_locked_zero": 0.0,
            "v65_fpr10_quantile": v65_theta,
            # A descriptor only, not admitted: midpoint between nearest opposing samples.
            "empirical_mid_gap_descriptor": 0.5 * (np.min(ln4) + np.max(delay)),
        }
        for name, theta in thresholds.items():
            tpr_success = int(np.sum(ln4 > theta))
            fpr_success = int(np.sum(delay > theta))
            n_tpr = int(len(ln4))
            n_fpr = int(len(delay))
            tpr = tpr_success / n_tpr
            fpr = fpr_success / n_fpr
            ltpr = lower_cp(tpr_success, n_tpr, conf)
            ufpr = upper_cp(fpr_success, n_fpr, conf)
            rows.append({
                "bank_kind": bank,
                "threshold_rule": name,
                "theta": theta,
                "eta_perp": eta,
                "source_hygiene_pass": source_hygiene,
                "n_ln4_controls": n_tpr,
                "n_delay_controls": n_fpr,
                "tpr_ln4": tpr,
                "tpr_successes": tpr_success,
                f"lower{int(conf*100)}_tpr_ln4": ltpr,
                "fpr_delay_as_physical": fpr,
                "fpr_successes": fpr_success,
                f"upper{int(conf*100)}_fpr_delay_as_physical": ufpr,
                "min_ln4_D": float(np.min(ln4)),
                "max_delay_D": float(np.max(delay)),
                "sign_gap_min_ln4_minus_max_delay": float(np.min(ln4) - np.max(delay)),
                "zero_margin_min_abs": float(min(abs(np.min(ln4)), abs(np.max(delay)))),
                "branch_gate_status": classify_status(source_hygiene, ltpr, ufpr),
            })
    return pd.DataFrame(rows)


def compute_on_source(score: pd.DataFrame, metrics: pd.DataFrame, summary: pd.DataFrame) -> pd.DataFrame:
    out = []
    m0 = metrics[metrics["threshold_rule"].eq("sign_locked_zero")].set_index("bank_kind")
    sidx = summary.set_index(["bank_kind", "truth"])
    for _, row in score[score["set"].eq("on_source_smoke")].iterrows():
        bank = row["bank_kind"]
        truth = row["truth"]
        D = float(row["D_branch"])
        theta = 0.0
        branch = "physical_ln4" if D > theta else "delay_or_gridlike" if D < theta else "exact_tie"
        det_conf = bool(sidx.loc[(bank, truth), "detection_confidence_pass"]) if (bank, truth) in sidx.index else False
        hygiene = bool(m0.loc[bank, "source_hygiene_pass"])
        branch_gate = str(m0.loc[bank, "branch_gate_status"])
        if truth == "source_only":
            verdict = "NO_DETECTION_EXPECTED"
        elif not hygiene:
            verdict = "LOCKED_SOURCE_HYGIENE_FAIL"
        elif not det_conf:
            verdict = "NO_DETECTION_OR_POINT_ONLY"
        elif branch_gate != "PASS_CONFIDENCE_BRANCH_GATE":
            verdict = "BRANCH_CALIBRATION_LOCKED"
        elif truth == "ln4" and branch == "physical_ln4":
            verdict = "PHYSICAL_BRANCH_SYNTHETIC_PASS"
        elif truth == "delay" and branch == "delay_or_gridlike":
            verdict = "DELAY_BRANCH_SYNTHETIC_PASS"
        else:
            verdict = "MISCLASSIFIED_OR_INCONCLUSIVE"
        out.append({
            "bank_kind": bank,
            "truth": truth,
            "D_branch_on": D,
            "sign_locked_branch_call": branch,
            "detection_confidence_pass": det_conf,
            "source_hygiene_pass": hygiene,
            "branch_gate_status": branch_gate,
            "v67_sign_locked_verdict": verdict,
        })
    return pd.DataFrame(out)


def make_plots(score: pd.DataFrame, metrics: pd.DataFrame, outdir: Path) -> None:
    outdir.mkdir(parents=True, exist_ok=True)

    # 1. Clean bank distribution with thresholds.
    clean = score[(score.bank_kind == "clean_gr") & (score.set == "branch_control")]
    fig, ax = plt.subplots(figsize=(9, 5))
    ax.hist(clean[clean.truth == "delay"].D_branch, bins=25, alpha=0.55, label="delay controls")
    ax.hist(clean[clean.truth == "ln4"].D_branch, bins=25, alpha=0.55, label="ln4 controls")
    ax.axvline(0.0, linestyle="--", linewidth=2, label="sign-locked threshold D=0")
    theta_v65 = metrics[(metrics.bank_kind == "clean_gr") & (metrics.threshold_rule == "v65_fpr10_quantile")].theta.iloc[0]
    ax.axvline(theta_v65, linestyle=":", linewidth=2, label="v65 FPR10 quantile")
    ax.set_xlabel("D = log p(ln4) - log p(delay)")
    ax.set_ylabel("control count")
    ax.set_title("v67 clean-carrier branch-control distributions")
    ax.legend()
    fig.tight_layout()
    fig.savefig(outdir / "GW250114_V67_clean_branch_distribution_sign_threshold.png", dpi=200)
    plt.close(fig)

    # 2. Confidence bars for threshold rules.
    fig, ax = plt.subplots(figsize=(10, 5))
    m = metrics[metrics.bank_kind == "clean_gr"].copy()
    x = np.arange(len(m))
    ax.scatter(x, m["lower95_tpr_ln4"], marker="o", label="lower95 TPR ln4")
    ax.scatter(x, m["upper95_fpr_delay_as_physical"], marker="x", label="upper95 FPR delay→phys")
    ax.axhline(0.90, linestyle="--", linewidth=1, label="TPR target 0.90")
    ax.axhline(0.10, linestyle=":", linewidth=1, label="FPR target 0.10")
    ax.set_xticks(x)
    ax.set_xticklabels(m.threshold_rule, rotation=25, ha="right")
    ax.set_ylim(-0.02, 1.05)
    ax.set_ylabel("confidence bound")
    ax.set_title("v67 clean-carrier threshold confidence comparison")
    ax.legend(loc="center right")
    fig.tight_layout()
    fig.savefig(outdir / "GW250114_V67_threshold_confidence_comparison.png", dpi=200)
    plt.close(fig)

    # 3. Admission plane all banks.
    sign = metrics[metrics.threshold_rule == "sign_locked_zero"].copy()
    fig, ax = plt.subplots(figsize=(8, 6))
    for _, r in sign.iterrows():
        ax.scatter(r["upper95_fpr_delay_as_physical"], r["lower95_tpr_ln4"], s=80)
        ax.annotate(r["bank_kind"], (r["upper95_fpr_delay_as_physical"], r["lower95_tpr_ln4"]), xytext=(5,5), textcoords="offset points", fontsize=9)
    ax.axvline(0.10, linestyle="--", linewidth=1)
    ax.axhline(0.90, linestyle="--", linewidth=1)
    ax.set_xlim(-0.01, max(0.20, sign["upper95_fpr_delay_as_physical"].max()+0.03))
    ax.set_ylim(0.85, 1.01)
    ax.set_xlabel("upper95 FPR(delay→physical)")
    ax.set_ylabel("lower95 TPR(ln4)")
    ax.set_title("v67 sign-locked branch confidence plane")
    fig.tight_layout()
    fig.savefig(outdir / "GW250114_V67_sign_locked_admission_plane.png", dpi=200)
    plt.close(fig)

    # 4. Sign margins.
    fig, ax = plt.subplots(figsize=(9,5))
    ax.bar(sign.bank_kind, sign.zero_margin_min_abs)
    ax.set_ylabel("minimum |D| distance to zero")
    ax.set_title("v67 sign-threshold safety margin by carrier bank")
    ax.tick_params(axis='x', rotation=20)
    fig.tight_layout()
    fig.savefig(outdir / "GW250114_V67_sign_margin_by_bank.png", dpi=200)
    plt.close(fig)


def write_report(metrics: pd.DataFrame, ons: pd.DataFrame, outdir: Path) -> None:
    clean_sign = metrics[(metrics.bank_kind == "clean_gr") & (metrics.threshold_rule == "sign_locked_zero")].iloc[0]
    clean_v65 = metrics[(metrics.bank_kind == "clean_gr") & (metrics.threshold_rule == "v65_fpr10_quantile")].iloc[0]
    n_ln4 = int(clean_sign.n_ln4_controls)
    n_delay = int(clean_sign.n_delay_controls)

    txt = f"""# GW250114 v67 — Sign-locked branch threshold and confidence-gate repair

**Status:** methods/admission-control only; **not a detection claim**.

## Why v67 was needed

v66 correctly noticed that the v65 branch-control calibration did not pass finite-control confidence at the empirical `FPR10` threshold.  However, v65 used a threshold chosen from the delay-control distribution.  For the actual branch likelihood contrast,

```text
D = log p(d | tau0 = ln4) - log p(d | tau0 = tau_delay),
```

the natural equal-prior branch boundary is not an empirical quantile.  It is exactly:

```text
D = 0.
```

Positive `D` favors the physical `ln4` branch.  Negative `D` favors the neighboring physical-delay / gridlike branch.  This sign-locked threshold is preregisterable, interpretable as a Bayes-factor boundary, and does not tune on branch controls.

## Main result on the v65 clean carrier-bank controls

Using the sign-locked threshold `D > 0` on the clean GR-like synthetic carrier bank:

```text
ln4 controls accepted as physical: {int(clean_sign.tpr_successes)}/{n_ln4}
delay controls falsely accepted as physical: {int(clean_sign.fpr_successes)}/{n_delay}
observed TPR = {clean_sign.tpr_ln4:.6f}
lower95 TPR = {clean_sign.lower95_tpr_ln4:.6f}
observed FPR = {clean_sign.fpr_delay_as_physical:.6f}
upper95 FPR = {clean_sign.upper95_fpr_delay_as_physical:.6f}
status = {clean_sign.branch_gate_status}
```

This passes the v66 confidence rule:

```text
lower95(TPR_ln4) >= 0.90
upper95(FPR_delay_as_physical) <= 0.10
```

By comparison, the older v65 empirical `FPR10` threshold gave:

```text
observed FPR = {clean_v65.fpr_delay_as_physical:.6f}
upper95 FPR = {clean_v65.upper95_fpr_delay_as_physical:.6f}
status = {clean_v65.branch_gate_status}
```

So v67 repairs the specific v66 failure by replacing a control-quantile threshold with the physically meaningful log-likelihood sign threshold.

## Important safety condition

This does **not** unlock the real GW250114 claim lane.  The sign-locked branch rule is only admitted after all upstream gates pass:

```text
real-data intake
→ official posterior intake
→ detector-conditioned GR carrier generation
→ source-hygiene eta_perp >= 0.90
→ source-only/off-source detection calibration
→ sign-locked branch-control confidence gate
→ real on-source branch likelihood
→ resampling/operator-gridlock test
→ GR-residual and amplitude-law checks
```

For contaminated synthetic carrier banks, the sign threshold may still classify branch controls correctly, but those banks remain locked by source hygiene.  This is deliberate.  A branch-likelihood win is not enough if the carrier basis can absorb or mimic the HRF branch vector.

## Current interpretation

- No discovery claim.
- The old native GW250114 snapshot remains grid-favored.
- Source-free branch interpretation remains nonidentifiable.
- v65 made the GR-conditioned branch likelihood executable.
- v66 added confidence-level branch-control requirements.
- v67 shows that the correct preregistered branch boundary is `D=0`, and on the clean synthetic carrier bank it passes the confidence rule.

## Files produced

- `GW250114_V67_sign_locked_branch_metrics.csv`
- `GW250114_V67_on_source_smoke_classification.csv`
- `GW250114_V67_clean_branch_distribution_sign_threshold.png`
- `GW250114_V67_threshold_confidence_comparison.png`
- `GW250114_V67_sign_locked_admission_plane.png`
- `GW250114_V67_sign_margin_by_bank.png`
"""
    (outdir / "GW250114_V67_SIGN_LOCKED_BRANCH_THRESHOLD.md").write_text(txt, encoding="utf-8")

    runbook = """# GW250114 v67 runbook

1. Compute or load a branch score table with columns `bank_kind`, `set`, `truth`, and `D_branch`.
2. Use `D_branch > 0` as the primary physical-branch rule. Do not tune the physical/delay threshold on the same controls used for certification.
3. For matched branch controls, certify:
   - `lower95(TPR_ln4) >= 0.90`
   - `upper95(FPR_delay_as_physical) <= 0.10`
4. Keep source-hygiene as a hard upstream lock: `eta_perp >= 0.90` is required before branch interpretation.
5. Apply the sign-locked threshold to real on-source data only after real-data/provenance, posterior, carrier, hygiene, and detection gates pass.

Command:

```bash
python gw250114_v67_sign_locked_branch_threshold.py \
  --score-table /path/to/GW250114_V65_score_table.csv \
  --summary-table /path/to/GW250114_V65_control_calibrated_summary.csv \
  --outdir v67_outputs
```
"""
    (outdir / "GW250114_V67_RUNBOOK.md").write_text(runbook, encoding="utf-8")

    next_task = """# GW250114 v67 next task

The next useful step is **v68: sign-locked branch likelihood on official-input products**.

Required inputs:

- H-H1_GWOSC_O4b_4KHZ_R1-1420877824-4096.hdf5
- L-L1_GWOSC_O4b_4KHZ_R1-1420877824-4096.hdf5
- posterior_samples_NRSur7dq4.h5
- posterior_samples_PhenomXO4a.h5
- posterior_samples_PhenomXPHM.h5
- posterior_samples_SEOBNRv5PHM.h5

Method order:

```text
official input validation
→ posterior schema probe
→ detector carrier-bank generation
→ eta_perp source hygiene
→ source-only detection calibration
→ D=0 sign-locked branch-control confidence certification
→ real on-source D_branch evaluation
```
"""
    (outdir / "GW250114_V67_NEXT_TASK.md").write_text(next_task, encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--score-table", default="/mnt/data/HRF_V65_CONTROL_CALIBRATED_BRANCH_LIKELIHOOD/v65_outputs/GW250114_V65_score_table.csv")
    parser.add_argument("--summary-table", default="/mnt/data/HRF_V65_CONTROL_CALIBRATED_BRANCH_LIKELIHOOD/v65_outputs/GW250114_V65_control_calibrated_summary.csv")
    parser.add_argument("--outdir", default="/mnt/data/HRF_V67_SIGN_LOCKED_BRANCH_THRESHOLD/v67_outputs")
    args = parser.parse_args()
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    score = pd.read_csv(args.score_table)
    summary = pd.read_csv(args.summary_table)
    metrics = compute_metrics(score, summary)
    ons = compute_on_source(score, metrics, summary)

    metrics.to_csv(outdir / "GW250114_V67_sign_locked_branch_metrics.csv", index=False)
    ons.to_csv(outdir / "GW250114_V67_on_source_smoke_classification.csv", index=False)
    make_plots(score, metrics, outdir)
    write_report(metrics, ons, outdir)

    manifest = {
        "version": "v67",
        "score_table": str(args.score_table),
        "summary_table": str(args.summary_table),
        "primary_threshold_rule": "D_branch > 0 for physical ln4; D_branch < 0 for neighboring delay",
        "outputs": sorted(p.name for p in outdir.iterdir()),
    }
    (outdir / "GW250114_V67_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(json.dumps(manifest, indent=2))

if __name__ == "__main__":
    main()
