# GW250114 HRF v68 — Branch-coordinate resolution gate and direct-wave model firewall

**Date:** 2026-07-10  
**Status:** methods/admission-control only; **not a detection or discovery claim**.

## Executive result

v67 remains correct **conditional on a fixed carrier/nuisance model**: for

`D = log p(d | tau=ln4) - log p(d | tau=tau_delay)`, the equal-prior boundary is `D=0`.

v68 adds the missing upstream identifiability condition.  In the v65-v67 transfer,

`H(f;tau,t_DW,rho) = 1 + rho exp[-i*pi*f*tau*t_DW]`,

so the strain depends on `tau` and `t_DW` through the product `s=tau*t_DW`.  If `t_DW` is not independently resolved, nearby `tau` branches are coordinate reparameterizations rather than separately measured physics.  Therefore the real statistic must be a **marginal** contrast,

`D_marg = log ∫p(d|ln4,t,m)p(t,m)dt dm - log ∫p(d|tau_delay,t,m)p(t,m)dt dm`,

where `m` spans the GR carrier and direct-wave nuisance models.

## Exact branch geometry

### v65-v67 fixed working value

- `t_DW = 3.183821000 ms`
- `tau_grid = 1.380269572316`
- `ln(4)-tau_grid = 0.006024788804`
- relative gap = `0.434597%`
- delay-coordinate gap = `9.590925 microseconds`
- native sample-coordinate gap = `0.039284427 sample`

Only a `0.436494%` change in `t_DW` lets the neighboring branch reproduce the same product exactly.

### Official-median Kerr proxy (`t_DW=2/kappa`, diagnostic only)

Using the public NRSur7dq4 medians `M_f^det=68.1 M_sun` and `chi_f=0.68`:

- `t_DW,Kerr = 3.171602222 ms`
- exact 9-sample/ln(4) alignment occurs at `3.169984221 ms`
- remaining delay-coordinate gap = `1.121513 microseconds`
- remaining sample-coordinate gap = `0.004593718 sample`
- relative gap = `0.051015%`

This proxy moves the branch about 88% of the way from the old fixed value to exact grid alignment.  It is **not** adopted as truth: the direct-wave-to-horizon mapping is currently disputed and must be model-compared.

## Best-case evidence ceiling

If the product `s=tau*t_DW` were measured with effectively infinite precision and an independent Gaussian constraint on `t_DW` were centered on the true value, then

`Z_tau ∝ p_t(s/tau)/tau`.

This is an optimistic ceiling; finite strain information and extra nuisances can only weaken it.

From the public marginal 90% intervals, a simple independent-Gaussian propagation through `t_DW=2/kappa` gives:

- mass contribution to relative sigma: `0.758830%`
- spin contribution to relative sigma: `0.443681%`
- combined proxy relative sigma: `0.879020%`

The exact 9-sample/ln(4) alignment coordinate lies at approximately the `47.443`th percentile of this crude proxy distribution, so it is not in a remote tail.

At that proxy width:

- best-case BF for the old fixed geometry: `1.126296`
- best-case BF for the official-median Kerr geometry: `1.001176`

For the old fixed geometry, even best-case `BF=10` requires independent `t_DW` precision better than `0.203210%`; `BF=100` requires `0.143759%`.  For the official-median Kerr proxy geometry, `BF=10` requires `0.023782%`.

These are not claims about the actual posterior; they are **precision targets**.  The official posterior HDF5 must be propagated with its true mass-spin covariance and with competing direct-wave models.

## Direct-wave literature firewall

Two current results must be carried simultaneously:

1. Lu et al., *Nature* (published 24 June 2026), report observational evidence for a direct wave in GW250114 and agreement with a Kerr-horizon interpretation.
2. Kankani & McWilliams, arXiv:2607.02380v1 (2 July 2026), argue from numerical-relativity strain that direct-wave frequency does not generally track horizon frequency, damping evolves rapidly, and the agreement near `chi_f≈0.68` may be incidental.

v68 does not decide this debate.  It prevents the HRF analysis from inheriting either interpretation by assumption.  A physical HRF result must survive the Kerr-linked, free/evolving-transient, and standard GR carrier lanes in `GW250114_V68_directwave_model_firewall.csv`.

## Updated decision ladder

```text
official H1/L1 and posterior validation
→ posterior mass-spin covariance and waveform-family intake
→ standard GR IMR/QNM carrier assembly
→ competing direct-wave lanes (Kerr-linked and free/evolving transient)
→ source-hygiene eta_perp gate
→ branch-coordinate resolution gate on the full t_DW posterior
→ source-only/off-source detection calibration
→ matched branch controls with sign-locked D=0
→ real on-source D_marg, not fixed-t_DW D
→ resampling/operator-gridlock test
→ survival across carrier/direct-wave model lanes
→ GR-residual and amplitude-law diagnostics
→ physical interpretation only if every gate passes
```

## Input status

The official manifest contains six required files.  Locally present in this runtime: `0/6`; missing: `6/6`.  Therefore v68 does not execute the real on-source likelihood.

## Honest status after v68

- v67's sign threshold repair is reproduced and remains valid conditionally.
- The branch-coordinate product degeneracy is now explicit.
- The old native snapshot remains grid-favored.
- The current direct-wave physical interpretation is externally contested.
- Real `ln(4)`, `g=4`, area-quantization, or quantum-horizon interpretation remains locked.
- No Zenodo update is recommended until the official posterior is propagated through this gate and the competing direct-wave lanes.
