# GW250114 v68 — Direct-wave literature snapshot frozen 2026-07-10

This note records the competing interpretations that the HRF likelihood must treat as model uncertainty rather than resolve by assumption.

## Result supporting a Kerr-horizon interpretation

Neil Lu, Sizheng Ma, Ornella J. Piccinni, Yanbei Chen, and Ling Sun, “GW250114 reveals signatures of post-merger black-hole horizon,” *Nature* (published 24 June 2026), DOI 10.1038/s41586-026-10696-0; arXiv:2510.01001v3.

Reported content relevant to this project:

- evidence for a non-QNM direct-wave component in GW250114;
- matched-filter SNR reported separately for Hanford and Livingston;
- a frequency and decay behavior interpreted through Kerr horizon rotation and surface gravity;
- agreement with that interpretation for this event.

## Result challenging universality of that mapping

Anuj Kankani and Sean T. McWilliams, “The Direct Wave is Not a Meaningful Test of Horizon Properties,” arXiv:2607.02380v1 (2 July 2026).

Reported content relevant to this project:

- across numerical-relativity simulations, direct-wave frequency does not generally track the horizon frequency;
- the crossing near remnant spin about 0.68–0.70 may be incidental, which is especially relevant because GW250114 has final spin near 0.68;
- direct-wave damping evolves significantly over short intervals;
- a fixed damped sinusoid or horizon-based mapping can generate misleading horizon-area interpretations away from that spin region.

## Official GR baseline

The LIGO Scientific Collaboration, Virgo Collaboration, and KAGRA Collaboration, “Black Hole Spectroscopy and Tests of General Relativity with GW250114,” arXiv:2509.08099 / *Physical Review Letters* 136, 041403 (2026).

Relevant baseline:

- at least two QNMs are required in the post-merger description;
- the event supplies stringent single-event tests of Kerr/GR;
- official posterior samples are provided for NRSur7dq4, SEOBNRv5PHM, PhenomXPHM, and PhenomXO4a.

## v68 policy

The HRF project does not choose a winner in the direct-wave debate before the data test. It freezes three nuisance/carrier lanes:

1. Kerr-linked direct wave;
2. free or time-evolving non-QNM transient;
3. standard GR IMR/QNM carrier without a fixed horizon-linked direct-wave calibration.

A branch or residual is physically interpretable only if its sign and evidence survive all three lanes.
