#!/usr/bin/env bash
set -euo pipefail

# Usage:
#   bash GW250114_V68_FETCH_OFFICIAL_INPUTS.sh minimal /path/to/output
#   bash GW250114_V68_FETCH_OFFICIAL_INPUTS.sh all /path/to/output
# minimal = H1 + L1 4 kHz strain + NRSur7dq4 posterior
# all     = minimal + the other three waveform posterior files

MODE="${1:-minimal}"
OUT="${2:-GW250114_official_inputs}"
mkdir -p "$OUT"

fetch() {
  local url="$1" name="$2"
  echo "Fetching $name"
  curl -fL --retry 5 --retry-delay 3 --continue-at - "$url" -o "$OUT/$name"
}

fetch "https://gwosc.org/archive/data/O4b_4KHZ_R1/1420820480/H-H1_GWOSC_O4b_4KHZ_R1-1420877824-4096.hdf5" \
  "H-H1_GWOSC_O4b_4KHZ_R1-1420877824-4096.hdf5"
fetch "https://gwosc.org/archive/data/O4b_4KHZ_R1/1420820480/L-L1_GWOSC_O4b_4KHZ_R1-1420877824-4096.hdf5" \
  "L-L1_GWOSC_O4b_4KHZ_R1-1420877824-4096.hdf5"
fetch "https://zenodo.org/api/records/16877102/files/posterior_samples_NRSur7dq4.h5/content" \
  "posterior_samples_NRSur7dq4.h5"

if [[ "$MODE" == "all" ]]; then
  fetch "https://zenodo.org/api/records/16877102/files/posterior_samples_PhenomXO4a.h5/content" \
    "posterior_samples_PhenomXO4a.h5"
  fetch "https://zenodo.org/api/records/16877102/files/posterior_samples_PhenomXPHM.h5/content" \
    "posterior_samples_PhenomXPHM.h5"
  fetch "https://zenodo.org/api/records/16877102/files/posterior_samples_SEOBNRv5PHM.h5/content" \
    "posterior_samples_SEOBNRv5PHM.h5"
elif [[ "$MODE" != "minimal" ]]; then
  echo "Unknown mode: $MODE (use minimal or all)" >&2
  exit 2
fi

cat <<'EOF'
Expected posterior MD5 checks:
9b115931b66439a1d5649a2b7b7aa143  posterior_samples_NRSur7dq4.h5
cf690b8ea60c2d0f469bd5f7960119c6  posterior_samples_PhenomXO4a.h5
62991eb44428c1f0e4fe9bd173b9f1b6  posterior_samples_PhenomXPHM.h5
74ee4e88c189c7f76d2735b7999683fc  posterior_samples_SEOBNRv5PHM.h5
EOF

if command -v md5sum >/dev/null 2>&1; then
  (cd "$OUT" && md5sum posterior_samples_*.h5 || true)
elif command -v md5 >/dev/null 2>&1; then
  md5 "$OUT"/posterior_samples_*.h5 || true
fi

echo "Done. Probe with:"
echo "python gw250114_v68_input_probe.py --input-dir '$OUT' --outdir '${OUT}_probe'"
