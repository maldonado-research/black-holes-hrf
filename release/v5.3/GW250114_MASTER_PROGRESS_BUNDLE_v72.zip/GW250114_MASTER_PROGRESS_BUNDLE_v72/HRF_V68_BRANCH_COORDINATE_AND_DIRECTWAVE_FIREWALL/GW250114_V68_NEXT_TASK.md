# GW250114 HRF v68 next task

## Highest-value execution

Upload the official NRSur7dq4 posterior first.  The first real-data-independent computation should be:

1. locate remnant detector-frame mass and final-spin samples;
2. compute a draw-level `t_DW` posterior under every frozen convention/model;
3. quantify `P(|tau_grid(t_DW)-ln4| < epsilon)` and the achievable branch BF ceiling;
4. compare NRSur7dq4, SEOBNRv5PHM, PhenomXPHM, and PhenomXO4a;
5. freeze the direct-wave model set before touching the on-source branch score.

Then add H1/L1 strain and run the full marginalized likelihood.

## Immediate kill condition

If the `t_DW` posterior/model spread is broader than the ln(4)-grid coordinate separation and the marginalized BF remains weak or model-dependent, the single-event physical branch interpretation is not identifiable and must stop there.  That is a scientifically useful negative result.
