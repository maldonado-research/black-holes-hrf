# GW250114 HRF v68 — One-page admission certificate

**Claim class:** methods-only; no detection.

## Theorem-like audit statement

For the current response transfer

`H(f;tau,t_DW,rho)=1+rho exp[-i*pi*f*tau*t_DW]`,

the data identify the product `tau*t_DW`, not `tau` and `t_DW` separately.  Thus a fixed-`t_DW` sign result (`D>0`) is not sufficient for a physical branch claim.  The admitted statistic is the nuisance- and model-marginalized `D_marg`.

## Numeric gate

At the v65-v67 fixed value, `ln(4)` and the 9-sample branch are separated by only `0.434597%` in the scale coordinate (`9.590925 microseconds`, `0.039284427` native sample).  Under the official-median `t_DW=2/kappa` proxy, the separation shrinks to `0.051015%` (`1.121513 microseconds`, `0.004593718` sample).

A best-case BF of 10 requires independent `t_DW` precision below `0.203210%` for the old geometry and `0.023782%` for the official-median Kerr proxy geometry.

## Firewall

No HRF residual may be interpreted until it survives:

1. standard GR IMR/QNM carriers;
2. a Kerr-linked direct-wave model;
3. a free/evolving non-QNM direct-wave model;
4. source hygiene, matched controls, resampling/gridlock, and amplitude-law gates.

## Verdict

**LOCKED — OFFICIAL POSTERIOR AND DIRECT-WAVE MODEL MARGINALIZATION REQUIRED.**
