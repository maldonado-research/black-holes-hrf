# GW250114 HRF v68 — Product-gauge proof and marginal branch evidence

**Scope:** mathematical admission control for the current v65–v67 transfer model. This is not an event claim.

## 1. Exact product dependence

The branch transfer is

```text
H(f; tau, t_DW, rho) = 1 + rho exp[-i pi f tau t_DW].
```

Define the product coordinate

```text
s = tau t_DW.
```

Then `H(f;tau,t_DW,rho)=H(f;s,rho)`. For every nonzero pair of branch values `tau_a`, `tau_b`, the transformation

```text
t_DW,b = t_DW,a tau_a / tau_b
```

leaves `s`, and therefore the complete noiseless transfer, unchanged. Any likelihood built only from this transfer has an exact ridge along `tau t_DW = constant` unless independent information constrains `t_DW`.

This is separate from the v55 source-transfer gauge. v55 showed that a free source spectrum can absorb a common transfer. v68 shows that even after conditioning on the source carrier, the current branch coordinate itself is degenerate with the direct-wave timescale.

## 2. Consequence for the v67 sign rule

With `t_DW` fixed and equal branch prior odds,

```text
D_fixed = log p(d | tau=ln4, t_DW) - log p(d | tau=tau_grid, t_DW)
```

has the natural boundary `D_fixed=0`. v67 is therefore correct for its frozen synthetic experiment.

For real inference, the admitted statistic is instead

```text
D_marg = log Z_ln4 - log Z_grid,
Z_i = integral p(d | tau_i, t_DW, m) p(t_DW,m) dt_DW dm,
```

where `m` includes the waveform family, direct-wave model, timing, calibration, and other nuisances.

A positive `D_fixed` at one selected `t_DW` is not a physical branch measurement if `D_marg` is weak, changes sign, or depends on the direct-wave lane.

## 3. Infinite-product-SNR evidence ceiling

Suppose the data constrain only `s=tau t_DW` and the likelihood becomes arbitrarily narrow around `s=s0`. For a fixed branch `tau_i`,

```text
Z_i = integral L(tau_i t) p_t(t) dt.
```

Changing variables to `s=tau_i t` gives

```text
Z_i = (1/tau_i) integral L(s) p_t(s/tau_i) ds.
```

In the narrow-likelihood limit,

```text
Z_i proportional to p_t(s0/tau_i) / tau_i.
```

For a Gaussian independent constraint on `t_DW`, centered on the true `ln4` value `t0` with relative width `sigma_rel`, the optimistic log Bayes factor is

```text
log BF_ln4/grid
  = 0.5 [(ln4/tau_grid - 1)/sigma_rel]^2
    + log(tau_grid/ln4).
```

This is an optimistic one-dimensional ceiling under the stated model. It is not a substitute for the official posterior or for a full detector likelihood.

## 4. Exact native-coordinate numbers

Using `fs=4096 Hz`, grid sample `k=9`, and the v65–v67 fixed `t_DW=3.183821 ms`:

```text
tau_grid = 18/(fs t_DW) = 1.380269572316
ln4 - tau_grid = 0.006024788804
relative tau gap = 0.434596647%
q gap = 9.590924558 microseconds
sample-coordinate gap = 0.039284427 sample
```

The grid branch reproduces the same product after only a `0.436493633%` change in `t_DW`.

Under the project diagnostic convention `t_DW=2/kappa`, using public NRSur7dq4 median remnant values `M_f^det=68.1 M_sun`, `chi_f=0.68`:

```text
t_DW = 3.171602222 ms
tau_grid = 1.385587139203
relative tau gap = 0.051015278%
q gap = 1.121513302 microseconds
sample-coordinate gap = 0.004593718 sample
```

Because the direct-wave-to-horizon mapping is under active dispute, this second line is a sensitivity diagnostic, not a preferred physical calibration.

## 5. Admission rule

The physical branch is admissible only when all of the following hold:

1. the full posterior/model mixture yields a sufficiently narrow independent `t_DW` coordinate;
2. `D_marg` is positive with preregistered evidence strength;
3. the sign and strength survive standard GR, Kerr-linked direct-wave, and free/evolving direct-wave carrier lanes;
4. source hygiene, matched branch controls, resampling/operator-gridlock, and residual checks all pass.

Otherwise the branch is **nonidentifiable**, even if a fixed-parameter score is positive.
