# GW250114 HRF v68 runbook

1. Place the two official 4 kHz GWOSC strain HDF5 files and four official posterior HDF5 files in one input directory.
2. Run `gw250114_v68_input_probe.py --input-dir <dir> --outdir <probe-dir>`.
3. Build `t_DW` for every posterior draw under each preregistered direct-wave lane; retain the full mass-spin covariance.
4. For each branch, compute evidence after marginalizing over `t_DW`, waveform family, detector calibration, timing, response amplitude, and direct-wave nuisance parameters.
5. Use `D_marg=0` as the equal-prior boundary.  Do not use the fixed-value v67 score as the real-data result.
6. Require strong evidence and stability across the standard GR, Kerr-linked direct-wave, and free/evolving direct-wave lanes.
7. Only then execute resampling/operator-gridlock, residual, and amplitude-law gates.

Regenerate the v68 diagnostics:

```bash
python gw250114_v68_branch_coordinate_firewall.py --outdir v68_outputs --input-dir /path/to/official_inputs
```
