#!/usr/bin/env python3
"""Probe official GW250114 HDF5 inputs without assuming one posterior schema."""
from __future__ import annotations
import argparse, hashlib, json
from pathlib import Path
from typing import Any

EXPECTED = {
    "H-H1_GWOSC_O4b_4KHZ_R1-1420877824-4096.hdf5": "",
    "L-L1_GWOSC_O4b_4KHZ_R1-1420877824-4096.hdf5": "",
    "posterior_samples_NRSur7dq4.h5": "9b115931b66439a1d5649a2b7b7aa143",
    "posterior_samples_PhenomXO4a.h5": "cf690b8ea60c2d0f469bd5f7960119c6",
    "posterior_samples_PhenomXPHM.h5": "62991eb44428c1f0e4fe9bd173b9f1b6",
    "posterior_samples_SEOBNRv5PHM.h5": "74ee4e88c189c7f76d2735b7999683fc",
}


def md5(path: Path) -> str:
    h=hashlib.md5()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024*1024), b''):
            h.update(chunk)
    return h.hexdigest()


def scalar(v: Any) -> Any:
    try:
        if hasattr(v, 'item'):
            v=v.item()
        if isinstance(v, bytes):
            return v.decode('utf-8', errors='replace')
        if isinstance(v, (str,int,float,bool)) or v is None:
            return v
        return str(v)
    except Exception:
        return str(v)


def hdf_inventory(path: Path) -> dict[str, Any]:
    try:
        import h5py
    except ImportError as e:
        return {"error": f"h5py unavailable: {e}"}
    out: dict[str, Any] = {"root_attrs": {}, "groups": [], "datasets": []}
    with h5py.File(path, 'r') as h:
        out["root_attrs"]={str(k): scalar(v) for k,v in h.attrs.items()}
        def visit(name: str, obj: Any) -> None:
            if isinstance(obj, h5py.Group):
                out["groups"].append({
                    "path": name,
                    "attrs": {str(k): scalar(v) for k,v in obj.attrs.items()},
                })
            elif isinstance(obj, h5py.Dataset):
                fields = list(obj.dtype.fields.keys()) if obj.dtype.fields else []
                out["datasets"].append({
                    "path": name,
                    "shape": list(obj.shape),
                    "dtype": str(obj.dtype),
                    "fields": fields,
                    "attrs": {str(k): scalar(v) for k,v in obj.attrs.items()},
                })
        h.visititems(visit)
    return out


def strain_checks(inv: dict[str, Any]) -> dict[str, Any]:
    ds={d["path"]: d for d in inv.get("datasets", [])}
    candidates=[k for k in ds if k.lower().endswith('strain') or '/strain' in k.lower()]
    return {
        "strain_dataset_candidates": candidates,
        "has_approximately_4096s_at_4096hz_by_shape": any(
            d.get("shape") == [4096*4096] for d in ds.values()
        ),
    }


def posterior_checks(inv: dict[str, Any]) -> dict[str, Any]:
    likely=[]
    tokens=("mass", "spin", "posterior", "sample", "remnant", "final")
    for d in inv.get("datasets", []):
        hay=(d.get("path","")+" "+" ".join(d.get("fields",[]))).lower()
        if any(t in hay for t in tokens):
            likely.append(d["path"])
    return {"likely_posterior_or_remnant_datasets": likely}


def main() -> None:
    ap=argparse.ArgumentParser()
    ap.add_argument('--input-dir', required=True)
    ap.add_argument('--outdir', required=True)
    args=ap.parse_args()
    indir=Path(args.input_dir); outdir=Path(args.outdir); outdir.mkdir(parents=True, exist_ok=True)
    summary=[]
    for name, expected in EXPECTED.items():
        p=indir/name
        row={"filename":name,"path":str(p),"present":p.exists(),"expected_md5":expected}
        if not p.exists():
            row["status"]="MISSING"
            summary.append(row); continue
        row["bytes"]=p.stat().st_size
        row["md5"]=md5(p)
        row["hash_status"]="PASS" if (not expected or row["md5"]==expected) else "FAIL"
        inv=hdf_inventory(p)
        row["hdf5_inventory_file"]=f"{p.stem}_hdf5_inventory.json"
        if name.startswith(('H-','L-')):
            row.update(strain_checks(inv))
        else:
            row.update(posterior_checks(inv))
        (outdir/row["hdf5_inventory_file"]).write_text(json.dumps(inv,indent=2),encoding='utf-8')
        row["status"]="PROBED" if row["hash_status"]=="PASS" else "HASH_FAIL"
        summary.append(row)
    result={
        "input_dir":str(indir),
        "files":summary,
        "all_present":all(r["present"] for r in summary),
        "all_hashes_pass_where_known":all(r.get("hash_status") in (None,"PASS") for r in summary),
    }
    (outdir/'GW250114_V68_input_probe_summary.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result,indent=2))

if __name__=='__main__':
    main()
