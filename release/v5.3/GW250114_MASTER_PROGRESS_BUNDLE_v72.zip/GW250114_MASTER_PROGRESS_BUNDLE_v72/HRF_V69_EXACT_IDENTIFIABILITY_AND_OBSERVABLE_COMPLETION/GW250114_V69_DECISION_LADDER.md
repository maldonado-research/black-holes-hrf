# GW250114 HRF v69 decision ladder

```text
canonical v65-v68 reproduction
-> exact single-delay rank audit
-> realistic branch-component SNR/power audit
-> official Nature direct-wave + LVK posterior intake
-> frozen Kerr-linked / free-evolving / standard-GR model lanes
-> joint or detector-cross-fitted nuisance-timescale inference
-> observable-completion determinant t*g_t - tau*g_tau != 0
-> source-hygiene eta_perp gate
-> source-only/off-source detection calibration
-> matched branch controls with conditional D=0 boundary
-> real on-source marginalized branch evidence
-> 4 kHz / 16 kHz / noncommensurate operator-grid veto
-> waveform-family and detector leave-one-out survival
-> GR-residual and absolute-amplitude diagnostics
-> physical interpretation only if every gate passes
```

## Locked shortcuts

- A fixed plug-in `t_DW` estimate is not a substitute for a joint posterior.
- H1/L1 duplication, extra frequency bins, and resampling do not add a new physical coordinate.
- Product-only catalog stacking retains one global scale null direction.
- A branch-dependent amplitude law with free multiplicative normalization is still gauge-degenerate.
