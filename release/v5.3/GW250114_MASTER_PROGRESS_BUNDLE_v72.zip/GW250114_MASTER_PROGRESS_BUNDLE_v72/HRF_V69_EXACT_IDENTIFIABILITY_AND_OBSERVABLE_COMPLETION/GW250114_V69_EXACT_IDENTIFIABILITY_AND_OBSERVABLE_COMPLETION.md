# GW250114 HRF v69 — Exact single-delay nonidentifiability theorem and observable-completion gate

**Date:** 2026-07-10  
**Status:** methods/admission-control only; **not a detection or discovery claim**.

## Executive result

v69 unifies the two v68 findings and strengthens them into an exact theorem.

For the current transfer with `rho` fixed with respect to `tau` and `t_DW`,

```text
H(f; tau, t_DW, rho) = 1 + rho exp[-i pi f tau t_DW],
```

the data depend on `tau` and `t_DW` only through `s=tau*t_DW`. The waveform derivatives obey

```text
partial_t H = (tau/t_DW) partial_tau H,
```

so the `(tau,t_DW)` Fisher block has determinant exactly zero for every carrier, detector network, PSD, sample rate, and SNR. Infinite SNR narrows the product but does not select a point along the ridge.

This structural lock is separate from the finite-power lock. Even if `t_DW` is frozen, the v65 carrier gives

- `M = 0.999998362799`,
- `1-M^2 = 3.274399794e-06`,
- direct-wave network SNR context `sqrt(15.8^2+17.1^2) = 23.281967`,
- `E[D] = 0.000887`,
- `P(D>0) ~= 0.511872`,
- SNR for 90% sign accuracy `= 1001.6`,
- SNR for expected BF=10 `= 1185.9`.

Thus the current point statistic is both structurally nonidentifiable when the timescale is free and severely underpowered when it is fixed. The direct-wave SNR used here is already an optimistic ceiling for the HRF branch component; the branch-modulation SNR cannot exceed the SNR of the full direct-wave component.

The analytic sign probabilities use the exact first two moments of the one-complex-amplitude profile statistic followed by a Gaussian moment approximation. A `200,000`-draw complex-noise Monte Carlo reproduces those probabilities with maximum absolute discrepancy `0.001343` across the audited scenarios and SNR points.

## The exact rank theorem

Let a detector-conditioned carrier be `c_k(f)` in detector `k`, with `rho` independent of `tau` and `t`, and let

```text
h_k(f;tau,t) = c_k(f) [1 + rho exp(-i pi f tau t)].
```

Define `u_k(f)=-i pi f c_k(f) rho exp(-i pi f tau t)`. Then

```text
partial_tau h_k = t u_k,
partial_t   h_k = tau u_k.
```

The network Fisher block is therefore an outer product,

```text
Gamma_(tau,t) = A [[t^2, t tau], [t tau, tau^2]],   A >= 0,
```

and

```text
det Gamma_(tau,t) = 0.
```

The null direction is the infinitesimal scaling `(delta tau, delta t) proportional to (tau,-t)`, corresponding to the exact finite transformation

```text
(tau,t) -> (a tau, t/a).
```

This is a model theorem, not a numerical coincidence.

## Catalog-stacking theorem

For `N` events with a shared branch parameter `tau` and free event times `t_j`, the product-only observables are `s_j=tau*t_j`. The Jacobian has `N` rows and `N+1` columns and always retains the null vector

```text
(tau,-t_1,...,-t_N).
```

Therefore adding events improves detection of the products but does **not** identify `tau` unless at least one event has an independent timescale anchor or another nonproduct observable. This corrects the earlier idea that rescaled-frequency stacking alone could identify the lattice branch.

## Marginal evidence is prior-driven on the ridge

In the infinite product-SNR limit,

```text
Z(tau_i) proportional to p_t(s/tau_i)/|tau_i|.
```

A broad uniform prior in `t` gives a small Jacobian preference for the smaller grid branch; a broad log-uniform prior gives exactly BF=1. A narrow Gaussian prior can create a large BF, but that evidence is supplied by the external timescale prior. In the old fixed-t geometry, the exact infinite-product-SNR prior-width ceilings are:

- BF >= 3: `sigma_t/t <= 0.293888%`;
- BF >= 10: `sigma_t/t <= 0.203210%`;
- BF >= 100: `sigma_t/t <= 0.143759%`.

These are not event posteriors. They quantify how strong an external timescale constraint would have to be before product-only branch evidence becomes appreciable.

## Amplitude-law completion audit

A fixed, physically calibrated amplitude law can break the rank defect. For the minimal lock

```text
rho(tau)=exp(-tau),
```

the exact phase-aligned branches have

- `1-M^2 = 7.073669187e-07`,
- `P(D>0 | SNR=23.282) ~= 0.505519`,
- SNR for 90% sign accuracy `= 2154.9`.

So this natural internal completion removes the exact equality but is even more underpowered after the nuisance timescale aligns the phases.

Moreover, a law of the form `rho=C*r(tau)` does **not** identify `tau` if the multiplicative normalization `C` is free: changing the branch can be exactly compensated by

```text
C' = C r(tau)/r(tau').
```

Absolute amplitude and phase calibration, or an additional nonfactorizable observable, is required.

At `a=1` in `rho=exp(-a tau)`, the phase-aligned SNR90 is approximately `2154.9`. For the older small-reflectivity rungs `a>=8`, the absolute modulation becomes so small that the required SNR grows dramatically.

## Observable-completion criterion

Take the product observable `s=tau*t` and any second scalar prediction `g(tau,t)`. Local identifiability requires

```text
Delta_g = det [[partial_tau s, partial_t s],
               [partial_tau g, partial_t g]]
        = t partial_t g - tau partial_tau g != 0.
```

The emitted scorecard applies this criterion. Genuine completions include:

1. an independently measured `t_DW` posterior;
2. an echo invariant `kappa Delta t_echo=tau` with independent `kappa`;
3. an absolutely calibrated amplitude law;
4. a second delay/harmonic with nonproportional `tau` dependence.

More detectors, more bins, 4/16-kHz resampling, a second pure multiple of the same delay, minimum-phase reconstruction of the same transfer, and catalog stacking with free event times do not remove the rank defect. They remain useful detection/systematics tests. An "independent timescale" can come from the same strain only when it is encoded through a genuinely different waveform feature, such as a time-domain envelope, and is fitted jointly rather than reused as a fixed plug-in estimate.

## Updated real-data protocol

```text
Nature direct-wave release + official remnant posterior intake
-> freeze Kerr-linked, free/evolving-transient, and standard-GR lanes
-> estimate nuisance timescale in a joint or detector-cross-fitted analysis
-> require an observable-completion determinant distinct from zero
-> source-hygiene eta_perp gate
-> realistic-SNR injections
-> sign-locked D=0 branch test
-> 4k/16k and noncommensurate operator-grid veto
-> waveform-family and detector leave-one-out survival
-> physical interpretation only if every gate passes
```

## Input status

Required official inputs present: `0/4`. The current runtime therefore cannot execute the draw-level/direct-wave posterior or detector likelihood.

## Honest status after v69

- v67's `D=0` boundary remains correct for fixed point hypotheses.
- v68's product-coordinate warning is now an exact Fisher-rank theorem.
- v68's finite-SNR concern is reproduced and incorporated.
- All numerical gauge, catalog-rank, free-normalization, and sign-power self-tests pass: `True`.
- The natural fixed-normalization amplitude lock is not powerful enough at GW250114-relevant SNR under the current carrier.
- The original three-channel triangulation is now understood as a mathematical identifiability requirement, not optional corroboration.
- Real `ln(4)`, `g=4`, area-quantization, or quantum-horizon interpretation remains locked.
- No Zenodo update is recommended until an official-input observable-completion run exists.
