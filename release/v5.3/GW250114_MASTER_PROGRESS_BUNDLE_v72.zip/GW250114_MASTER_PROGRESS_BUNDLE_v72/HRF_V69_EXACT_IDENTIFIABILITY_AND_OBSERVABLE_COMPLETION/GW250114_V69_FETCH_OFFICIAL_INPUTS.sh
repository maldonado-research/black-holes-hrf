#!/usr/bin/env bash
set -euo pipefail

DEST="${1:-official_inputs}"
mkdir -p "$DEST"

fetch() {
  local url="$1"
  local name="$2"
  echo "Fetching $name"
  curl -L --fail --retry 5 --retry-delay 5 -o "$DEST/$name.part" "$url"
  mv "$DEST/$name.part" "$DEST/$name"
}

fetch "https://zenodo.org/records/20017347/files/GW250114_horizon_signatures.zip?download=1" \
      "GW250114_horizon_signatures.zip"
fetch "https://zenodo.org/records/16877102/files/posterior_samples_NRSur7dq4.h5?download=1" \
      "posterior_samples_NRSur7dq4.h5"
fetch "https://gwosc.org/archive/data/O4b_4KHZ_R1/1420820480/H-H1_GWOSC_O4b_4KHZ_R1-1420877824-4096.hdf5" \
      "H-H1_GWOSC_O4b_4KHZ_R1-1420877824-4096.hdf5"
fetch "https://gwosc.org/archive/data/O4b_4KHZ_R1/1420820480/L-L1_GWOSC_O4b_4KHZ_R1-1420877824-4096.hdf5" \
      "L-L1_GWOSC_O4b_4KHZ_R1-1420877824-4096.hdf5"

echo "Expected MD5 checksums for the two Zenodo files:"
echo "4874fef35088209c9fa4073f15a27a78  $DEST/GW250114_horizon_signatures.zip"
echo "9b115931b66439a1d5649a2b7b7aa143  $DEST/posterior_samples_NRSur7dq4.h5"
command -v md5sum >/dev/null && md5sum \
  "$DEST/GW250114_horizon_signatures.zip" \
  "$DEST/posterior_samples_NRSur7dq4.h5" || true
