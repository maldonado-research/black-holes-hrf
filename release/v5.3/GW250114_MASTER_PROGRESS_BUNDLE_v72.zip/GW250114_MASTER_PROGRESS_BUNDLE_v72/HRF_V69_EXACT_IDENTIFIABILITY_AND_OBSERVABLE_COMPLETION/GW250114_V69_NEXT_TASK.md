# GW250114 HRF v69 next task

## Highest-value execution

Use the official Nature direct-wave release and NRSur7dq4 posterior to build a **joint or detector-cross-fitted nuisance anchor**:

1. extract segmented direct-wave frequency/damping posteriors rather than assuming one constant horizon-linked decay time;
2. run three frozen lanes: Kerr-linked, free/evolving transient, and standard GR/QNM;
3. estimate the nuisance timescale in H1 and test the branch in L1, then swap detectors;
4. compute the full joint evidence so the timescale uncertainty and its correlation with the branch statistic are propagated;
5. require an observable-completion determinant distinct from zero before interpreting `D_marg`;
6. repeat at 4 kHz and 16 kHz only as an operator/grid veto, not as independent evidence.

## Immediate stop condition

Stop the single-event physical branch lane if every defensible model has either:

- a product-gauge/null Fisher direction;
- 90%-accuracy required SNR far above the recovered branch-component SNR; or
- branch evidence that changes materially under the nuisance prior, waveform family, detector split, or direct-wave model.

A negative identifiability result is publishable methods progress; it is not a failed experiment.
