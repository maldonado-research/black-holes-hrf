# Official inputs for the next execution

The v69 theorem and synthetic-power audit run without external binaries. The real-data lane requires:

- `GW250114_horizon_signatures.zip` from Zenodo record 20017347;
- `posterior_samples_NRSur7dq4.h5` from Zenodo record 16877102;
- H1 and L1 4096-second, 4-kHz GWOSC strain files for GW250114.

The three other waveform-posterior files in the manifest are optional for the first run and required for the later waveform-family systematics gate.

Place downloaded files in `official_inputs/`, run the script, and require checksum matches where checksums are provided. The current package was generated with 0/4 required files present because the execution environment could not complete the external downloads.
