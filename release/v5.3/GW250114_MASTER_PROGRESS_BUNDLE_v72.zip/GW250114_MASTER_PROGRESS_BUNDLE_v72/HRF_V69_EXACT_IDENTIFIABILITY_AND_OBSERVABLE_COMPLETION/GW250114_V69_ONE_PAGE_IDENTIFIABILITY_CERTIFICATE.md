# GW250114 v69 one-page identifiability certificate

**Certificate:** negative admission-control result for the current single-delay transfer.  
**Claim status:** no detection or physical branch interpretation certified.

## Exact result

For `H=1+rho exp(-i pi f tau t_DW)` with `rho` fixed independently of `tau` and `t_DW`, the waveform depends on `tau` and `t_DW` only through `tau*t_DW`. The network Fisher determinant in those two parameters is exactly zero and the transformation `(tau,t)->(a tau,t/a)` leaves the signal unchanged.

## Finite-power result

With `t_DW=3.183821 ms` frozen and the v65 carrier:

- `M=0.999998362799`;
- `1-M^2=3.274399794e-06`;
- at the optimistic full-direct-wave network SNR `23.282`, `P(correct sign)=0.5119`;
- 90% sign accuracy requires SNR `1001.6`.

A fixed-normalization `rho=exp(-tau)` law breaks exact equality but, after phase alignment, requires SNR `2154.9` for 90% sign accuracy. If its normalization is free, the exact gauge returns.

At infinite product SNR, an external Gaussian `t_DW` prior would need width `<= 0.203210%` to supply BF>=10 for the physical branch in the old fixed-t geometry. This is a prior-resolution target, not evidence from the strain.

## Certificate statement

> The present single-delay branch statistic cannot identify `ln(4)` from GW250114 at event-relevant SNR, and it cannot identify `tau` at any SNR while `t_DW` remains free. More events or resampling alone do not repair this. A physical interpretation requires an independent timescale, an absolutely calibrated branch-amplitude law, an echo/QNM channel with nonproduct dependence, or another derived observable satisfying `t g_t - tau g_tau != 0`.

## Decision

`ln(4)`, `g=4`, area-quantization, and quantum-horizon interpretations remain **LOCKED**. No new Zenodo version is recommended before the official direct-wave/posterior data pass an observable-completion analysis.
