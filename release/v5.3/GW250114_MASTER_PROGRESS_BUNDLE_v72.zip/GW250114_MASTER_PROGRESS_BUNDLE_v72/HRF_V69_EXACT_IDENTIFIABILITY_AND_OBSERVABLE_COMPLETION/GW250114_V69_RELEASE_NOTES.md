# GW250114 HRF v69 release notes

## What changed from v68

1. Upgraded the product-coordinate warning to an exact network Fisher-rank theorem.
2. Proved that product-only catalog stacking retains one null direction for any event count.
3. Added the general observable-completion determinant `t*g_t - tau*g_tau`.
4. Reproduced the fixed-timescale branch mismatch and translated it to realistic-SNR sign power.
5. Audited a fixed-normalization amplitude law and proved that a free normalization restores the gauge.
6. Added exact prior-width targets: BF10 requires `sigma_t/t <= 0.203210%` in the old geometry at infinite product SNR.
7. Added a `200,000`-draw sign-power Monte Carlo and numerical gauge/rank self-tests.
8. Added a gate-status scorecard and official-input manifest.

## Decision

This is a methods/admission-control advance, not a black-hole discovery. The real physical branch remains locked pending an observable-complete official-data analysis. A new Zenodo release is not recommended yet.
