# GW250114 HRF v69 runbook

## Reproduce

```bash
python gw250114_v69_exact_identifiability.py   --v65-score-table reference_inputs/GW250114_V65_score_table.csv   --input-dir official_inputs   --outdir v69_outputs
```

Python requirements: numpy, pandas, scipy, matplotlib.

## Read first

1. `GW250114_V69_ONE_PAGE_IDENTIFIABILITY_CERTIFICATE.md`
2. `GW250114_V69_EXACT_IDENTIFIABILITY_AND_OBSERVABLE_COMPLETION.md`
3. `GW250114_V69_observable_completion_matrix.csv`
4. `GW250114_V69_point_power_context.csv`
5. `GW250114_V69_gate_status.csv`
6. `GW250114_V69_NUMERICAL_SELF_TEST.json`

## Interpretation rules

- Do not use a fixed-timescale `D>0` as a physical certificate.
- Do not count H1/L1, 4/16 kHz, or multiple bins as independent branch coordinates.
- Do not use catalog stacking to infer a shared `tau` unless at least one nonproduct anchor is included.
- If a branch-amplitude law contains a free normalization, test its exact reparameterization before claiming rank completion.
- Preserve the v67 `D=0` boundary only inside a fully specified point-hypothesis or marginalized model comparison.
