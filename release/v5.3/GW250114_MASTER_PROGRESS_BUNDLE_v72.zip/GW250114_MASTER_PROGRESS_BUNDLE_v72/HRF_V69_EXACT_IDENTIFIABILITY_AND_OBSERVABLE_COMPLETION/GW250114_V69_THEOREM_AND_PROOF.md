# GW250114 HRF v69 theorem and proof

## Theorem 1 — Single-delay product gauge

Let a network waveform have detector components

\[
h_k(f;\tau,t,\rho)=c_k(f)\left[1+\rho e^{-i\pi f\tau t}\right],
\]

where each carrier \(c_k\), the noise inner products, and the fixed complex coefficient \(\rho\) are otherwise arbitrary, with \(\rho\) independent of \(\tau\) and \(t\). Then \(\tau\) and \(t\) are not separately identifiable from these data.

### Proof

Set

\[
u_k(f)=-i\pi f c_k(f)\rho e^{-i\pi f\tau t}.
\]

Then

\[
\partial_\tau h_k=t u_k,\qquad \partial_t h_k=\tau u_k.
\]

The derivative vectors are exactly collinear in every detector. Any network Fisher matrix formed by summing detector inner products therefore has

\[
\Gamma_{\tau t}=A
\begin{pmatrix}
t^2&t\tau\\
t\tau&\tau^2
\end{pmatrix},\qquad A\ge0,
\]

and determinant zero. Equivalently, the finite transformation

\[
(\tau,t)\mapsto(a\tau,t/a)
\]

leaves every waveform sample unchanged. QED.

## Corollary 1 — Infinite SNR does not select the branch

As SNR tends to infinity, the likelihood can collapse onto \(s=\tau t=s_0\), but it remains constant along that curve. Branch evidence after marginalizing \(t\) is therefore supplied by the nuisance prior and Jacobian:

\[
Z(\tau_i)\propto \frac{p_t(s_0/\tau_i)}{|\tau_i|}.
\]

For a Gaussian prior centered on the physical-branch time \(t_p\), the exact
infinite-product-SNR branch ratio is

\[
\mathrm{BF}_{p/g}=\frac{\tau_g}{\tau_p}
\exp\!\left[\frac{(t_g-t_p)^2}{2\sigma_t^2}\right].
\]

This expression makes explicit that any product-only branch preference is a
statement about the nuisance prior, not new likelihood curvature transverse to
the product ridge.

## Theorem 2 — Catalog stacking retains one null direction

For \(N\) events with shared \(\tau\), event times \(t_j\), and product observables \(s_j=\tau t_j\), the Jacobian has null vector

\[
v=(\tau,-t_1,\ldots,-t_N).
\]

Thus its rank is at most \(N\) for \(N+1\) parameters. No number of product-only events identifies the shared \(\tau\) without an anchor. QED.

## Theorem 3 — Observable-completion criterion

Add a second scalar prediction \(g(\tau,t)\). The map \((\tau,t)\mapsto(s,g)\), with \(s=\tau t\), is locally invertible iff

\[
\Delta_g=t\,\partial_tg-\tau\,\partial_\tau g\ne0.
\]

This follows immediately from the inverse-function theorem.

## Corollary 2 — A free amplitude normalization restores the gauge

Suppose

\[
H=1+C r(\tau)e^{-i\pi f\tau t}
\]

with free multiplicative \(C\). For any \(\tau'\), choose

\[
t'=\frac{\tau t}{\tau'},\qquad C'=C\frac{r(\tau)}{r(\tau')}.
\]

Then \(H(f;\tau',t',C')=H(f;\tau,t,C)\) exactly. Therefore a branch-dependent amplitude law is not an identifying observable unless its absolute normalization is constrained or another nonfactorizable prediction is added.

## Practical interpretation

The theorem does not rule out horizon-response physics. It states the minimum information content the measurement must contain. A valid physical claim requires either an independent timescale, an independently calibrated branch amplitude, an echo/QNM channel that measures \(\tau\) differently, or a richer transfer with nonproportional branch dependence.
