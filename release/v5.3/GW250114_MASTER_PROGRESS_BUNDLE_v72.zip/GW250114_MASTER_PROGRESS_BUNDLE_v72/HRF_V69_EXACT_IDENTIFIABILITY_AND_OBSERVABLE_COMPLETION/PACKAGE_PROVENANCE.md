# Package provenance

- Canonical predecessor: user-supplied `GW250114_MASTER_PROGRESS_BUNDLE_v68(1).zip`.
- Reused internal input: `GW250114_V65_score_table.csv` from the canonical v68 master chain.
- v67 and v68 conclusions were independently replayed before v69 was built.
- External source metadata and checksums were verified from GWOSC, the LVK Zenodo release, the 2026 Nature direct-wave publication and companion release, and the July 2026 numerical-relativity critique.
- Official binary downloads could not be completed in the generation runtime; `official_inputs/` therefore contains instructions only.
- Cross-project HDBLAST, ToE, DMDE, FTL, CLFV, antimatter, and other materials were treated as reference-only and were not imported as assumptions into the GW250114 likelihood or theorem.
