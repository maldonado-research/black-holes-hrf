# HRF v69 — Exact identifiability and observable completion

**Project:** GW250114 Quantized Horizon Response / branch-control program  
**Version:** v69  
**Date:** 2026-07-10  
**Status:** methods and admission control only; **no detection or discovery claim**.

## Core result

For the current single-delay transfer

```text
H(f; tau, t_DW, rho) = 1 + rho exp[-i pi f tau t_DW],
```

with `rho` fixed independently of `tau` and `t_DW`, the waveform depends on those two parameters only through the product `tau*t_DW`. The network Fisher block therefore has determinant zero at every SNR. Fixing the timescale removes that exact ridge, but the physical `ln(4)` branch and the neighboring nine-sample branch remain too closely matched for event-scale branch power under the audited carrier.

The package also proves that product-only catalog stacking retains one global scale null direction and supplies the general local completion condition

```text
t * partial_t g - tau * partial_tau g != 0.
```

## Read first

1. `GW250114_V69_ONE_PAGE_IDENTIFIABILITY_CERTIFICATE.md`
2. `GW250114_V69_EXACT_IDENTIFIABILITY_AND_OBSERVABLE_COMPLETION.md`
3. `GW250114_V69_THEOREM_AND_PROOF.md`
4. `GW250114_V69_gate_status.csv`
5. `GW250114_V69_observable_completion_matrix.csv`
6. `GW250114_V69_NEXT_TASK.md`

## Reproduce

```bash
python gw250114_v69_exact_identifiability.py \
  --v65-score-table reference_inputs/GW250114_V65_score_table.csv \
  --input-dir official_inputs \
  --outdir reproduced_outputs
```

Dependencies are listed in `requirements.txt`. The fixed-seed generation was replayed twice; all 30 generated files were bit-for-bit identical. See `audits/`.

## Official-data lane

The theorem and synthetic-power audit do not require external binaries. The real-data lane requires the Nature direct-wave companion archive, the official NRSur7dq4 posterior, and H1/L1 GWOSC strain. Use `GW250114_V69_FETCH_OFFICIAL_INPUTS.sh` or place those files in `official_inputs/` manually. The package itself contains no official strain or posterior binaries.

## Decision

The v67 `D=0` boundary remains valid conditionally for fixed point hypotheses. A physical `ln(4)`, `g=4`, area-quantization, or quantum-horizon interpretation remains locked until a joint observable-complete official-data workflow passes every gate.
