# Sources and provenance

Primary external anchors used by v69:

- GWOSC GW250114 event page and open strain products: DOI 10.7935/1g4j-2028.
- LVK GW250114 discovery data release: DOI 10.5281/zenodo.16877102.
- Lu et al., Nature 655, 71-75 (2026), `GW250114 reveals signatures of post-merger black-hole horizon`.
- Lu et al. companion data release: DOI 10.5281/zenodo.20017347.
- Kankani & McWilliams, arXiv:2607.02380v1 (2 July 2026), `The Direct Wave is Not a Meaningful Test of Horizon Properties`.

Internal provenance:

- v65 score table from the canonical user-supplied v68 master bundle.
- v67 sign threshold and v68 product-coordinate calculations are reproduced rather than assumed.

No external binary data were present in the runtime used to generate this package.
