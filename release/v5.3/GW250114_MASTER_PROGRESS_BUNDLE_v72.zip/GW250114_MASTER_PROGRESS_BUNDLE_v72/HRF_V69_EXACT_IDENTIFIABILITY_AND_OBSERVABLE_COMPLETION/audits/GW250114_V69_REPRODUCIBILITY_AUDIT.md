# GW250114 HRF v69 reproducibility audit

- Run 1 files: `30`
- Run 2 files: `30`
- Same filename set: `True`
- All files bit-for-bit identical: `True`
- Differences: `[]`

Both runs used the same canonical v65 score table, empty official-input directory, source code, and fixed Monte Carlo seed.
