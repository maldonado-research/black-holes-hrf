#!/usr/bin/env python3
"""GW250114 HRF v69 — exact identifiability and observable-completion audit.

Methods/admission-control only. This script does not claim a detection.

It combines two independent questions:
  1. Structural identifiability: can tau and t_DW be separately inferred from
     H(f)=1+rho exp[-i pi f tau t_DW]?
  2. Finite-SNR power: even if t_DW is fixed, can ln(4) be distinguished from
     the neighboring native-grid branch at GW250114-relevant SNR?

It also derives and evaluates a minimal observable-completion criterion and
checks whether a locked amplitude law can repair the exact product gauge.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
from typing import Any

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.optimize import minimize_scalar
from scipy.stats import norm

VERSION = "GW250114_HRF_v69"
DATE = "2026-07-10"
STATUS = "METHODS_ONLY_NO_DETECTION"
MC_SEED = 690114
MC_N = 200_000

LN4 = float(np.log(4.0))
FS_NATIVE_HZ = 4096.0
GRID_INDEX = 9.0
Q_GRID_S = GRID_INDEX / FS_NATIVE_HZ
T_REF_S = 0.003183821
TAU_GRID = 2.0 * Q_GRID_S / T_REF_S
T_ALIGN_S = 2.0 * Q_GRID_S / LN4
RHO_FIXED = 0.25
NOISE_FRAC_V65 = 0.003

DIRECT_WAVE_SNR_H1 = 15.8
DIRECT_WAVE_SNR_L1 = 17.1
DIRECT_WAVE_NETWORK_SNR = float(np.hypot(DIRECT_WAVE_SNR_H1, DIRECT_WAVE_SNR_L1))
FULL_EVENT_SNR_CONTEXTS = {
    "cwb_72p8": 72.8,
    "gstlal_76p6": 76.6,
    "mbta_78p6": 78.6,
    "round_80": 80.0,
}

OFFICIAL_FILES = [
    {
        "stage": "A_directwave_nuisance",
        "required": True,
        "filename": "GW250114_horizon_signatures.zip",
        "size_mb": 53.0,
        "md5": "4874fef35088209c9fa4073f15a27a78",
        "source": "Nature companion data release, Zenodo record 20017347",
        "purpose": "direct-wave posterior/results and plotting notebooks",
    },
    {
        "stage": "A_remnant_posterior",
        "required": True,
        "filename": "posterior_samples_NRSur7dq4.h5",
        "size_mb": 27.0,
        "md5": "9b115931b66439a1d5649a2b7b7aa143",
        "source": "LVK GW250114 discovery data release, Zenodo record 16877102",
        "purpose": "draw-level remnant mass-spin covariance",
    },
    {
        "stage": "B_waveform_systematics",
        "required": False,
        "filename": "posterior_samples_PhenomXO4a.h5",
        "size_mb": 26.8,
        "md5": "cf690b8ea60c2d0f469bd5f7960119c6",
        "source": "LVK GW250114 discovery data release, Zenodo record 16877102",
        "purpose": "waveform-family leave-one-out",
    },
    {
        "stage": "B_waveform_systematics",
        "required": False,
        "filename": "posterior_samples_PhenomXPHM.h5",
        "size_mb": 26.8,
        "md5": "62991eb44428c1f0e4fe9bd173b9f1b6",
        "source": "LVK GW250114 discovery data release, Zenodo record 16877102",
        "purpose": "waveform-family leave-one-out",
    },
    {
        "stage": "B_waveform_systematics",
        "required": False,
        "filename": "posterior_samples_SEOBNRv5PHM.h5",
        "size_mb": 26.8,
        "md5": "74ee4e88c189c7f76d2735b7999683fc",
        "source": "LVK GW250114 discovery data release, Zenodo record 16877102",
        "purpose": "waveform-family leave-one-out",
    },
    {
        "stage": "C_detector_likelihood",
        "required": True,
        "filename": "H-H1_GWOSC_O4b_4KHZ_R1-1420877824-4096.hdf5",
        "size_mb": None,
        "md5": None,
        "source": "GWOSC GW250114_082203 event release",
        "purpose": "H1 detector-conditioned likelihood",
    },
    {
        "stage": "C_detector_likelihood",
        "required": True,
        "filename": "L-L1_GWOSC_O4b_4KHZ_R1-1420877824-4096.hdf5",
        "size_mb": None,
        "md5": None,
        "source": "GWOSC GW250114_082203 event release",
        "purpose": "L1 detector-conditioned likelihood",
    },
]


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def md5(path: Path) -> str:
    h = hashlib.md5()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def transfer(freq: np.ndarray, tau: float, t_s: float, rho: complex) -> np.ndarray:
    return 1.0 + complex(rho) * np.exp(-1j * np.pi * freq * float(tau) * float(t_s))


def carrier_amplitude(freq: np.ndarray) -> np.ndarray:
    return (freq / 100.0) ** (-7.0 / 6.0) * np.exp(-(freq / 900.0) ** 2)


def stable_profile_mismatch(a: np.ndarray, b: np.ndarray) -> float:
    """Return 1-M^2 stably after maximizing over one complex amplitude."""
    aa = np.asarray(a, dtype=np.complex128)
    bb = np.asarray(b, dtype=np.complex128)
    na = float(np.vdot(aa, aa).real)
    nb = float(np.vdot(bb, bb).real)
    if na <= 0.0 or nb <= 0.0:
        return float("nan")
    scale = np.vdot(bb, aa) / nb
    r = aa - scale * bb
    delta = float(np.vdot(r, r).real / na)
    return min(1.0, max(0.0, delta))


def match_from_delta(delta: float) -> float:
    return float(math.sqrt(max(0.0, 1.0 - float(delta))))


def expected_D(snr: float, delta: float) -> float:
    return 0.5 * float(snr) ** 2 * float(delta)


def sign_accuracy(snr: float, delta: float) -> float:
    rho = float(snr)
    d = float(delta)
    if d <= 0.0:
        return 0.5
    mu = 0.5 * rho * rho * d
    var = 0.5 * d * (1.0 + rho * rho)
    return float(norm.cdf(mu / math.sqrt(var)))


def required_snr_for_D(target_D: float, delta: float) -> float:
    if delta <= 0.0:
        return float("inf")
    return float(math.sqrt(2.0 * float(target_D) / float(delta)))


def required_snr_for_accuracy(target_p: float, delta: float) -> float:
    if delta <= 0.0:
        return float("inf")
    z = float(norm.ppf(target_p))
    y = (z * z + math.sqrt(z**4 + 2.0 * delta * z * z)) / delta
    return float(math.sqrt(y))


def gaussian_prior_sigma_rel_for_bf(target_bf: float) -> float:
    """Exact infinite-product-SNR Gaussian-prior width for a target BF.

    The prior is centered on the physical branch timescale.  With
    s0=tau_p*t_p and the product measured exactly,

      BF_{p/g} = (tau_g/tau_p) exp[(t_g-t_p)^2/(2 sigma_t^2)].

    This quantity is a prior-resolution target, not a strain-data result.
    """
    if target_bf <= 0:
        raise ValueError("target_bf must be positive")
    t_phys = T_REF_S
    t_grid = T_REF_S * LN4 / TAU_GRID
    denom = 2.0 * math.log(float(target_bf) * LN4 / TAU_GRID)
    if denom <= 0:
        return float("inf")
    return abs(t_grid - t_phys) / (t_phys * math.sqrt(denom))


def base_carrier(freq: np.ndarray, det: str) -> np.ndarray:
    amp = carrier_amplitude(freq)
    phase = 0.019 * freq + 1.1e-5 * freq**2
    if det == "L1":
        phase = phase + 0.63 + 2.0 * np.pi * freq * 0.0069
    return (amp * np.exp(1j * phase)).astype(np.complex128)


def orthonormal_basis(vecs: list[np.ndarray], tol: float = 1e-12) -> np.ndarray:
    qlist: list[np.ndarray] = []
    for v in vecs:
        u = np.asarray(v, dtype=np.complex128).copy()
        for q in qlist:
            u -= q * np.vdot(q, u)
        n = float(np.sqrt(max(np.vdot(u, u).real, 0.0)))
        if n > tol:
            qlist.append(u / n)
    if not qlist:
        return np.zeros((0, len(vecs[0])), dtype=np.complex128)
    return np.vstack(qlist)


def project_out(v: np.ndarray, basis: np.ndarray) -> np.ndarray:
    r = np.asarray(v, dtype=np.complex128).copy()
    for q in basis:
        r -= q * np.vdot(q, r)
    return r


def make_clean_v65_bank(n_carriers: int = 96, n_freq: int = 512, seed: int = 1234) -> dict[str, np.ndarray]:
    rng = np.random.default_rng(seed)
    freq = np.linspace(50.0, 1024.0, n_freq)
    bh = base_carrier(freq, "H1")
    bl = base_carrier(freq, "L1")
    hp = transfer(freq, LN4, T_REF_S, RHO_FIXED)
    hg = transfer(freq, TAU_GRID, T_REF_S, RHO_FIXED)
    branch_net = np.r_[bh * (hp - hg), bl * (hp - hg)]
    branch_net /= np.sqrt(np.vdot(branch_net, branch_net).real)
    x = (freq - freq.min()) / np.ptp(freq)
    raw: list[np.ndarray] = []
    for k in range(1, 19):
        env = np.sin(2.0 * np.pi * k * x).astype(np.complex128)
        env += 0.45j * np.cos(2.0 * np.pi * (k + 1) * x)
        raw.append(np.r_[bh * env * 0.12, bl * np.roll(env, k % 17) * 0.12])
    basis = orthonormal_basis([project_out(v, branch_net[None, :]) for v in raw])
    h1, l1 = [], []
    for _ in range(n_carriers):
        coeff = rng.normal(0.0, 0.035, size=basis.shape[0])
        perturb = np.sum(coeff[:, None] * basis, axis=0) if basis.size else 0.0
        h1.append(bh + perturb[:n_freq])
        l1.append(bl + perturb[n_freq:])
    return {"freq": freq, "H1": np.asarray(h1), "L1": np.asarray(l1)}


def synthetic_snr_audit(score_table: Path | None) -> dict[str, float | int | None]:
    bank = make_clean_v65_bank()
    f = bank["freq"]
    hp = transfer(f, LN4, T_REF_S, RHO_FIXED)
    rows = []
    for h, l in zip(bank["H1"], bank["L1"]):
        model = np.r_[h * hp, l * hp]
        sigma = NOISE_FRAC_V65 * np.median(np.abs(np.r_[h, l]))
        snr = float(np.sqrt(np.vdot(model, model).real / sigma**2))
        rows.append(snr)
    observed = None
    if score_table is not None and score_table.exists():
        df = pd.read_csv(score_table)
        q = df[(df.get("bank_kind") == "clean_gr") & (df.get("set") == "branch_control")]
        if len(q):
            observed = float(q["D_branch"].abs().median())
    return {
        "n_carriers": len(rows),
        "median_effective_network_snr": float(np.median(rows)),
        "observed_median_abs_D": observed,
    }


def point_power_rows() -> tuple[pd.DataFrame, dict[str, float]]:
    f = np.linspace(50.0, 1024.0, 8192)
    amp = carrier_amplitude(f)
    hp_const = amp * transfer(f, LN4, T_REF_S, RHO_FIXED)
    hg_const_fixed = amp * transfer(f, TAU_GRID, T_REF_S, RHO_FIXED)
    delta_const_fixed = stable_profile_mismatch(hp_const, hg_const_fixed)

    # Exact phase alignment by moving the grid-branch nuisance timescale.
    t_grid_align = T_REF_S * LN4 / TAU_GRID
    hg_const_align = amp * transfer(f, TAU_GRID, t_grid_align, RHO_FIXED)
    delta_const_align = stable_profile_mismatch(hp_const, hg_const_align)

    # Minimal internally locked amplitude law: rho(tau)=exp(-tau), C fixed.
    hp_amp = amp * transfer(f, LN4, T_REF_S, math.exp(-LN4))
    hg_amp_fixed = amp * transfer(f, TAU_GRID, T_REF_S, math.exp(-TAU_GRID))
    hg_amp_align = amp * transfer(f, TAU_GRID, t_grid_align, math.exp(-TAU_GRID))
    delta_amp_fixed = stable_profile_mismatch(hp_amp, hg_amp_fixed)
    delta_amp_align = stable_profile_mismatch(hp_amp, hg_amp_align)

    scenarios = [
        ("constant_rho_fixed_t", delta_const_fixed, "v65-v68 point-template test"),
        ("constant_rho_phase_aligned", delta_const_align, "exact product-gauge counterpart"),
        ("rho_exp_minus_tau_fixed_t", delta_amp_fixed, "fixed-normalization amplitude lock"),
        ("rho_exp_minus_tau_phase_aligned", delta_amp_align, "amplitude lock after exact phase alignment"),
    ]
    contexts = {"directwave_network_23p282": DIRECT_WAVE_NETWORK_SNR, **FULL_EVENT_SNR_CONTEXTS}
    rows: list[dict[str, Any]] = []
    for name, delta, desc in scenarios:
        row: dict[str, Any] = {
            "scenario": name,
            "description": desc,
            "one_minus_M2": delta,
            "match_M": match_from_delta(delta),
            "snr_required_expected_BF10": required_snr_for_D(math.log(10.0), delta),
            "snr_required_expected_BF100": required_snr_for_D(math.log(100.0), delta),
            "snr_required_sign_accuracy_90pct": required_snr_for_accuracy(0.90, delta),
            "snr_required_sign_accuracy_95pct": required_snr_for_accuracy(0.95, delta),
        }
        for label, snr in contexts.items():
            row[f"snr_{label}"] = snr
            row[f"expected_D_at_{label}"] = expected_D(snr, delta)
            row[f"sign_accuracy_at_{label}"] = sign_accuracy(snr, delta)
        rows.append(row)
    geometry = {
        "tau_physical_ln4": LN4,
        "tau_grid_fixed_t": TAU_GRID,
        "t_ref_ms": 1e3 * T_REF_S,
        "t_exact_native_grid_alignment_ms": 1e3 * T_ALIGN_S,
        "t_grid_branch_phase_alignment_ms": 1e3 * t_grid_align,
        "relative_tau_gap_percent": 100.0 * (LN4 - TAU_GRID) / LN4,
        "q_gap_microseconds_fixed_t": 1e6 * (0.5 * LN4 * T_REF_S - Q_GRID_S),
    }
    return pd.DataFrame(rows), geometry


def amplitude_scan() -> pd.DataFrame:
    f = np.linspace(50.0, 1024.0, 8192)
    amp = carrier_amplitude(f)
    t_grid_align = T_REF_S * LN4 / TAU_GRID
    exponents = np.unique(np.r_[np.geomspace(0.01, 40.0, 480), [0.25, 0.5, 1, 2, 4, 8, 10, 12, 20]])
    rows = []
    for a in exponents:
        rho_p = math.exp(-a * LN4)
        rho_g = math.exp(-a * TAU_GRID)
        hp = amp * transfer(f, LN4, T_REF_S, rho_p)
        hg_fixed = amp * transfer(f, TAU_GRID, T_REF_S, rho_g)
        hg_align = amp * transfer(f, TAU_GRID, t_grid_align, rho_g)
        d_fixed = stable_profile_mismatch(hp, hg_fixed)
        d_align = stable_profile_mismatch(hp, hg_align)
        rows.append({
            "amplitude_exponent_a": float(a),
            "rho_physical": rho_p,
            "rho_grid": rho_g,
            "relative_rho_difference": rho_g / rho_p - 1.0,
            "one_minus_M2_fixed_t": d_fixed,
            "one_minus_M2_phase_aligned": d_align,
            "snr90_fixed_t": required_snr_for_accuracy(0.90, d_fixed),
            "snr90_phase_aligned": required_snr_for_accuracy(0.90, d_align),
            "sign_accuracy_directwave_fixed_t": sign_accuracy(DIRECT_WAVE_NETWORK_SNR, d_fixed),
            "sign_accuracy_directwave_phase_aligned": sign_accuracy(DIRECT_WAVE_NETWORK_SNR, d_align),
        })
    out = pd.DataFrame(rows).sort_values("amplitude_exponent_a").reset_index(drop=True)
    return out


def prior_coordinate_rows() -> pd.DataFrame:
    # Infinite product-SNR limit: Z_tau proportional to p_t(s/tau)/|tau|.
    s0 = LN4 * T_REF_S
    tau_values = {"physical_ln4": LN4, "grid_branch": TAU_GRID}
    rows: list[dict[str, Any]] = []

    # Uniform t prior; choose broad support containing both transformed points.
    z_uniform = {k: 1.0 / v for k, v in tau_values.items()}
    bf_uniform = z_uniform["physical_ln4"] / z_uniform["grid_branch"]
    rows.append({
        "prior_family": "uniform_in_t_broad_support",
        "bf_physical_over_grid": bf_uniform,
        "log_bf": math.log(bf_uniform),
        "log10_bf": math.log10(bf_uniform),
        "interpretation": "Jacobian-only; slightly favors smaller tau grid branch",
    })

    # Log-uniform prior exactly cancels the branch Jacobian.
    rows.append({
        "prior_family": "log_uniform_in_t_broad_support",
        "bf_physical_over_grid": 1.0,
        "log_bf": 0.0,
        "log10_bf": 0.0,
        "interpretation": "exact neutrality in the product-only limit",
    })

    # Gaussian priors centered at the physical reference t; branch alternative
    # requires t=s0/tau. Scan widths to expose prior-driven evidence.
    t_phys = s0 / LN4
    t_grid = s0 / TAU_GRID
    for sigma_rel in np.geomspace(1e-5, 5e-2, 160):
        sig = sigma_rel * t_phys
        log_bf = math.log(TAU_GRID/LN4) + 0.5*((t_grid-t_phys)/sig)**2
        bf = math.exp(log_bf) if log_bf < 700.0 else float("inf")
        rows.append({
            "prior_family": "gaussian_t_centered_on_physical",
            "sigma_t_over_t": sigma_rel,
            "bf_physical_over_grid": bf,
            "log_bf": log_bf,
            "log10_bf": log_bf/math.log(10.0),
            "interpretation": "best-case product measurement; evidence supplied by t prior",
        })
    return pd.DataFrame(rows)


def prior_precision_target_rows() -> pd.DataFrame:
    rows = []
    for target in [3.0, 10.0, 100.0]:
        sigma_rel = gaussian_prior_sigma_rel_for_bf(target)
        rows.append({
            "target_bf_physical_over_grid": target,
            "max_sigma_t_over_t": sigma_rel,
            "max_sigma_t_over_t_percent": 100.0*sigma_rel,
            "geometry": "old fixed-t v65-v69 ln4 versus 9-sample comparator",
            "interpretation": "infinite product-SNR ceiling; evidence is supplied by the external t_DW prior",
        })
    return pd.DataFrame(rows)


def catalog_rank_rows(max_events: int = 32) -> pd.DataFrame:
    rows = []
    for n in range(1, max_events + 1):
        n_params = n + 1  # shared tau plus one free t_j per event
        jac_rank = n
        nullity = n_params - jac_rank
        rows.append({
            "n_events": n,
            "n_parameters_shared_tau_plus_event_times": n_params,
            "jacobian_rank_product_only": jac_rank,
            "nullity": nullity,
            "identifiable_tau_without_anchor": False,
            "null_vector_form": "(tau,-t1,...,-tN)",
        })
    return pd.DataFrame(rows)


def observable_completion_rows() -> pd.DataFrame:
    # Base observable s=tau*t. A second scalar g gives Jacobian determinant
    # Delta_g = t*d_t g - tau*d_tau g.
    rows = [
        {
            "candidate": "independent_t_DW_measurement",
            "second_observable_g": "t",
            "completion_determinant": "t",
            "rank_complete": True,
            "current_status": "mathematically sufficient; physical direct-wave mapping/model disputed",
            "required_gate": "joint/cross-fitted posterior with model-lane marginalization",
        },
        {
            "candidate": "echo_invariant",
            "second_observable_g": "kappa*Delta_t_echo = tau",
            "completion_determinant": "-tau",
            "rank_complete": True,
            "current_status": "sufficient if kappa is independently constrained and echo survives controls",
            "required_gate": "off-source calibration, source hygiene, independent kappa posterior",
        },
        {
            "candidate": "absolute_amplitude_law_fixed_normalization",
            "second_observable_g": "rho=r(tau), normalization fixed",
            "completion_determinant": "nonzero if r'(tau) != 0",
            "rank_complete": True,
            "current_status": "formally sufficient but numerically underpowered for rho=exp(-tau)",
            "required_gate": "absolute response calibration tighter than branch-induced amplitude shift",
        },
        {
            "candidate": "amplitude_law_free_multiplicative_C",
            "second_observable_g": "rho=C*r(tau), C free",
            "completion_determinant": "gauge restored via C'=C*r(tau)/r(tau')",
            "rank_complete": False,
            "current_status": "not sufficient for a single event or catalog with free global C",
            "required_gate": "external calibration/physical prior for C or a second nonfactorizable amplitude observable",
        },
        {
            "candidate": "nonproportional_second_delay_or_harmonic",
            "second_observable_g": "t*F2(tau) alongside t*F1(tau)",
            "completion_determinant": "t*(F1'F2-F1F2')",
            "rank_complete": True,
            "current_status": "sufficient only if F2/F1 varies with tau",
            "required_gate": "derive from causal HRF physics before fitting",
        },
        {
            "candidate": "second_pure_multiple_of_same_delay",
            "second_observable_g": "c*tau*t",
            "completion_determinant": "0",
            "rank_complete": False,
            "current_status": "same coordinate; more SNR but no new identifiability",
            "required_gate": "replace with nonproportional branch dependence",
        },
        {
            "candidate": "minimum_phase_reconstruction_from_same_transfer",
            "second_observable_g": "phase determined by same H(s)",
            "completion_determinant": "0 if only a function of s=tau*t",
            "rank_complete": False,
            "current_status": "valuable consistency test, not an independent anchor by itself",
            "required_gate": "show an additional tau-only or nonproduct prediction",
        },
        {
            "candidate": "multiple_detectors_same_astrophysical_transfer",
            "second_observable_g": "same s in H1/L1 with different antenna/noise",
            "completion_determinant": "0",
            "rank_complete": False,
            "current_status": "improves power and cross-checks noise, not parameter rank",
            "required_gate": "use detector split for cross-fitting, not as duplicate physical evidence",
        },
        {
            "candidate": "4k_16k_or_noncommensurate_resampling",
            "second_observable_g": "same physical H(s) under a different numerical operator",
            "completion_determinant": "0",
            "rank_complete": False,
            "current_status": "essential grid-artifact veto; not a physical branch anchor",
            "required_gate": "must survive, but cannot unlock tau alone",
        },
        {
            "candidate": "catalog_stacking_with_free_t_j",
            "second_observable_g": "s_j=tau*t_j for j=1..N",
            "completion_determinant": "one global scaling null remains",
            "rank_complete": False,
            "current_status": "N events do not identify shared tau without at least one anchor",
            "required_gate": "external t_j information or nonproduct channel",
        },
    ]
    return pd.DataFrame(rows)


def gate_status_rows(power: pd.DataFrame, inputs: pd.DataFrame) -> pd.DataFrame:
    p_const = power.loc[power.scenario == "constant_rho_fixed_t"].iloc[0]
    p_amp = power.loc[power.scenario == "rho_exp_minus_tau_phase_aligned"].iloc[0]
    official_ready = bool(inputs.loc[inputs.required == True, "present"].all())
    return pd.DataFrame([
        {
            "gate": "v67_sign_boundary",
            "criterion": "D>0 for equal-prior fixed point hypotheses",
            "status": "PASS_CONDITIONAL",
            "reason": "D=0 remains the natural conditional likelihood boundary",
        },
        {
            "gate": "single_delay_structural_identifiability",
            "criterion": "rank(tau,t_DW)=2",
            "status": "FAIL_EXACT",
            "reason": "H depends on tau and t_DW only through tau*t_DW; Fisher determinant is zero",
        },
        {
            "gate": "fixed_t_realistic_power",
            "criterion": "P(D>0)>=0.90 at a defensible branch-component SNR",
            "status": "FAIL_POWER",
            "reason": f"SNR90={float(p_const.snr_required_sign_accuracy_90pct):.1f}, far above the optimistic direct-wave context",
        },
        {
            "gate": "fixed_normalization_amplitude_completion",
            "criterion": "rank complete and P(D>0)>=0.90 at event scale",
            "status": "FAIL_POWER",
            "reason": f"rho=exp(-tau) completes rank only if absolutely calibrated; phase-aligned SNR90={float(p_amp.snr_required_sign_accuracy_90pct):.1f}",
        },
        {
            "gate": "official_input_intake",
            "criterion": "all required checksummed official files present",
            "status": "PASS" if official_ready else "BLOCKED_MISSING_INPUTS",
            "reason": f"{int(inputs.loc[inputs.required == True, 'present'].sum())}/{int((inputs.required == True).sum())} required files present",
        },
        {
            "gate": "real_physical_branch_interpretation",
            "criterion": "all upstream gates survive",
            "status": "LOCKED",
            "reason": "observable completion, realistic power, official-data execution, source hygiene, and systematics survival are not all established",
        },
    ])


def profile_sign_monte_carlo(power: pd.DataFrame, n_draws: int = MC_N,
                             seed: int = MC_SEED) -> pd.DataFrame:
    """Validate the Gaussian moment approximation for profile-likelihood sign.

    For one profiled complex amplitude, D=1/2(|z_p|^2-|z_g|^2).
    The reported analytic probability uses its exact first two moments and a
    Gaussian approximation.  This Monte Carlo checks the approximation at the
    SNR contexts used in the report.
    """
    rng = np.random.default_rng(seed)
    x = (rng.normal(size=n_draws) + 1j*rng.normal(size=n_draws))/math.sqrt(2.0)
    z = (rng.normal(size=n_draws) + 1j*rng.normal(size=n_draws))/math.sqrt(2.0)
    rows: list[dict[str, Any]] = []
    scenarios = ["constant_rho_fixed_t", "rho_exp_minus_tau_phase_aligned"]
    for scenario in scenarios:
        row = power.loc[power.scenario == scenario].iloc[0]
        delta = float(row.one_minus_M2)
        match = float(row.match_M)
        y = match*x + math.sqrt(max(delta, 0.0))*z
        snrs = [DIRECT_WAVE_NETWORK_SNR, 80.0, float(row.snr_required_sign_accuracy_90pct)]
        for snr in snrs:
            dstat = 0.5*(np.abs(snr+x)**2 - np.abs(snr*match+y)**2)
            p_mc = float(np.mean(dstat > 0.0))
            p_analytic = sign_accuracy(snr, delta)
            se = math.sqrt(max(p_mc*(1.0-p_mc), 1e-15)/n_draws)
            rows.append({
                "scenario": scenario,
                "snr": snr,
                "n_draws": n_draws,
                "seed": seed,
                "p_sign_monte_carlo": p_mc,
                "mc_standard_error": se,
                "p_sign_moment_gaussian": p_analytic,
                "absolute_difference": abs(p_mc-p_analytic),
                "difference_in_mc_standard_errors": (p_mc-p_analytic)/se,
            })
    return pd.DataFrame(rows)


def numerical_self_test(power: pd.DataFrame, mc: pd.DataFrame) -> dict[str, Any]:
    rng = np.random.default_rng(690)
    freq = np.sort(rng.uniform(30.0, 1500.0, 127))
    tau = 1.3921
    t = 0.00327
    rho = 0.19 + 0.07j
    a = 1.037

    h0 = transfer(freq, tau, t, rho)
    h1 = transfer(freq, a*tau, t/a, rho)
    product_gauge_residual = float(np.max(np.abs(h0-h1)))

    # Finite-difference derivative collinearity test.
    eps_tau = 1e-7*tau
    eps_t = 1e-7*t
    d_tau = (transfer(freq, tau+eps_tau, t, rho)-transfer(freq, tau-eps_tau, t, rho))/(2.0*eps_tau)
    d_t = (transfer(freq, tau, t+eps_t, rho)-transfer(freq, tau, t-eps_t, rho))/(2.0*eps_t)
    derivative_residual = float(np.linalg.norm(d_t-(tau/t)*d_tau)/np.linalg.norm(d_t))

    # Catalog Jacobian and its exact global scaling null vector.
    n = 8
    ts = rng.uniform(0.0025, 0.0040, n)
    jac = np.zeros((n, n+1))
    jac[:, 0] = ts
    for j in range(n):
        jac[j, j+1] = tau
    null = np.r_[tau, -ts]
    catalog_null_residual = float(np.linalg.norm(jac@null))
    catalog_rank = int(np.linalg.matrix_rank(jac))

    # Free multiplicative amplitude normalization restores the exact gauge.
    c0 = 0.73*np.exp(0.4j)
    tau2 = TAU_GRID
    t2 = tau*t/tau2
    r0 = math.exp(-tau)
    r2 = math.exp(-tau2)
    c2 = c0*r0/r2
    hf0 = 1.0 + c0*r0*np.exp(-1j*np.pi*freq*tau*t)
    hf2 = 1.0 + c2*r2*np.exp(-1j*np.pi*freq*tau2*t2)
    free_norm_gauge_residual = float(np.max(np.abs(hf0-hf2)))

    # MC moment approximation should agree within a conservative 5 sigma plus
    # an absolute 0.002 numerical allowance.
    mc_ok = bool(np.all(mc.absolute_difference <= 5.0*mc.mc_standard_error + 0.002))
    tests = {
        "product_gauge_max_abs_residual": product_gauge_residual,
        "product_gauge_pass": product_gauge_residual < 1e-12,
        "finite_difference_derivative_relative_residual": derivative_residual,
        "derivative_collinearity_pass": derivative_residual < 1e-6,
        "catalog_n_events": n,
        "catalog_jacobian_rank": catalog_rank,
        "catalog_expected_rank": n,
        "catalog_null_vector_residual": catalog_null_residual,
        "catalog_null_pass": catalog_rank == n and catalog_null_residual < 1e-12,
        "free_amplitude_normalization_gauge_max_abs_residual": free_norm_gauge_residual,
        "free_amplitude_normalization_gauge_pass": free_norm_gauge_residual < 1e-12,
        "profile_sign_monte_carlo_pass": mc_ok,
    }
    tests["all_pass"] = bool(all(v for k, v in tests.items() if k.endswith("_pass")))
    return tests


def input_manifest(input_dir: Path) -> pd.DataFrame:
    rows = []
    for item in OFFICIAL_FILES:
        p = input_dir / item["filename"]
        present = p.exists()
        actual_md5 = md5(p) if present and item["md5"] else None
        checksum_ok = (actual_md5 == item["md5"]) if actual_md5 and item["md5"] else None
        rows.append({**item,
                     "local_path": str(p),
                     "present": present,
                     "actual_size_bytes": p.stat().st_size if present else None,
                     "actual_md5": actual_md5,
                     "checksum_ok": checksum_ok})
    return pd.DataFrame(rows)


def plot_likelihood_ridge(out: Path) -> None:
    tau = np.linspace(1.355, 1.415, 600)
    t_ms = np.linspace(3.10, 3.27, 600)
    tt, tm = np.meshgrid(tau, t_ms)
    s0 = LN4 * T_REF_S
    sigma_rel = 2.0e-4  # diagrammatic, not an event posterior
    sigma_s = sigma_rel * s0
    logl = -0.5 * ((tt * (tm * 1e-3) - s0) / sigma_s) ** 2
    levels = [-50, -20, -8, -3, -1, -0.2]
    fig, ax = plt.subplots(figsize=(9.5, 6.3))
    cs = ax.contour(tt, tm, logl, levels=levels)
    ax.clabel(cs, inline=True, fontsize=8)
    ridge_t = 1e3 * s0 / tau
    ax.plot(tau, ridge_t, linewidth=2.0, label=r"exact ridge $t=s_0/\tau$")
    ax.scatter([LN4], [1e3*T_REF_S], s=65, marker="o", label=r"physical $(\ln4,t_{ref})$")
    ax.scatter([TAU_GRID], [1e3*T_REF_S], s=65, marker="s", label="9-sample comparator at fixed t")
    ax.scatter([TAU_GRID], [1e3*T_REF_S*LN4/TAU_GRID], s=75, marker="x", label="exact grid-branch counterpart")
    ax.set_xlabel(r"branch parameter $\tau$")
    ax.set_ylabel(r"nuisance timescale $t_{DW}$ [ms]")
    ax.set_title("Product-only likelihood ridge (geometry illustration)")
    ax.legend(loc="best", fontsize=8)
    ax.text(0.01, 0.01, "Illustrative relative product width 0.02%; not a GW250114 posterior.", transform=ax.transAxes, fontsize=8)
    fig.tight_layout()
    fig.savefig(out, dpi=180)
    plt.close(fig)


def plot_snr_power(power: pd.DataFrame, out: Path) -> None:
    snr = np.geomspace(5.0, 5000.0, 500)
    fig, ax = plt.subplots(figsize=(9.5, 6.3))
    keep = ["constant_rho_fixed_t", "rho_exp_minus_tau_phase_aligned"]
    for name in keep:
        row = power.loc[power.scenario == name].iloc[0]
        delta = float(row.one_minus_M2)
        ax.plot(snr, [sign_accuracy(x, delta) for x in snr], label=name.replace("_", " "))
    ax.axhline(0.90, linestyle="--", linewidth=1.2, label="90% sign accuracy")
    ax.axvline(DIRECT_WAVE_NETWORK_SNR, linestyle=":", linewidth=1.5, label="direct-wave network SNR 23.28")
    ax.axvline(80.0, linestyle="-.", linewidth=1.2, label="optimistic/full-event context 80")
    ax.set_xscale("log")
    ax.set_ylim(0.49, 1.01)
    ax.set_xlabel("effective branch-component network SNR")
    ax.set_ylabel(r"moment-matched $P(D>0)$")
    ax.set_title("Branch sign power after the v67 D=0 repair")
    ax.legend(fontsize=8, loc="best")
    fig.tight_layout()
    fig.savefig(out, dpi=180)
    plt.close(fig)


def plot_amplitude_scan(scan: pd.DataFrame, out: Path) -> None:
    fig, ax = plt.subplots(figsize=(9.5, 6.3))
    ymax = 1e9
    y_fixed = np.minimum(scan.snr90_fixed_t.to_numpy(), ymax)
    y_align = np.minimum(scan.snr90_phase_aligned.to_numpy(), ymax)
    ax.plot(scan.amplitude_exponent_a, y_fixed, label="fixed t")
    ax.plot(scan.amplitude_exponent_a, y_align, label="phase-aligned nuisance")
    for a in [1, 8, 10, 12, 20]:
        idx = int((scan.amplitude_exponent_a-a).abs().argmin())
        x = float(scan.iloc[idx].amplitude_exponent_a)
        y = min(float(scan.iloc[idx].snr90_phase_aligned), ymax)
        ax.scatter([x], [y], s=24)
        ax.annotate(f"a={a}", (x, y), xytext=(3, 4), textcoords="offset points", fontsize=7)
    ax.axhline(DIRECT_WAVE_NETWORK_SNR, linestyle="--", linewidth=1.0, label="direct-wave SNR 23.28")
    ax.axhline(80.0, linestyle="-.", linewidth=1.0, label="SNR 80 context")
    ax.set_yscale("log")
    ax.set_xscale("log")
    ax.set_ylim(15.0, 1.25*ymax)
    ax.set_xlabel(r"locked amplitude exponent $a$ in $\rho=e^{-a\tau}$")
    ax.set_ylabel("SNR required for 90% sign accuracy")
    ax.set_title("Fixed-normalization amplitude law does not restore event-scale power")
    ax.text(0.01, 0.01, r"Values above $10^9$ are clipped; exact values are in the CSV.",
            transform=ax.transAxes, fontsize=8)
    ax.legend(fontsize=8, loc="best")
    fig.tight_layout()
    fig.savefig(out, dpi=180)
    plt.close(fig)


def plot_prior_sensitivity(priors: pd.DataFrame, out: Path) -> None:
    q = priors[priors.prior_family == "gaussian_t_centered_on_physical"].copy()
    fig, ax = plt.subplots(figsize=(9.5, 6.3))
    yclip = 4.0
    ax.plot(100.0*q.sigma_t_over_t, np.minimum(q.log10_bf, yclip))
    ax.axhline(0.0, linestyle="--", linewidth=1.0, label="BF=1")
    ax.axhline(math.log10(3.0), linestyle=":", linewidth=0.9, label="BF=3")
    ax.axhline(1.0, linestyle="-.", linewidth=0.9, label="BF=10")
    ax.axhline(2.0, linestyle=(0, (5, 2)), linewidth=0.9, label="BF=100")
    for target in [3.0, 10.0, 100.0]:
        x = 100.0*gaussian_prior_sigma_rel_for_bf(target)
        ax.axvline(x, linestyle=":", linewidth=0.7)
    ax.set_xscale("log")
    ax.set_ylim(-0.05, yclip+0.15)
    ax.set_xlabel(r"Gaussian external $t_{DW}$ prior width [%]")
    ax.set_ylabel(r"$\log_{10} BF_{\ln4/grid}$ at infinite product SNR")
    ax.set_title("Product-only branch evidence is supplied by the timescale prior")
    ax.text(0.01, 0.01, r"Curve clipped at $\log_{10}BF=4$; vertical lines are exact BF=3,10,100 widths.",
            transform=ax.transAxes, fontsize=8)
    ax.legend(fontsize=8, loc="upper right")
    fig.tight_layout()
    fig.savefig(out, dpi=180)
    plt.close(fig)


def plot_fisher_completion(out: Path) -> pd.DataFrame:
    # Dimensionless Fisher illustration. Product observable y=tau*t has a
    # relative precision sigma_s/s; add an independent t prior.
    sigma_s_rel = 1e-3
    t = T_REF_S
    tau = LN4
    s = t * tau
    sig_s = sigma_s_rel * s
    widths = np.geomspace(1e-5, 5e-2, 300)
    rows = []
    for rel in widths:
        sig_t = rel * t
        j = np.array([t, tau], dtype=float)
        fisher = np.outer(j, j) / sig_s**2
        fisher[1, 1] += 1.0 / sig_t**2
        eig = np.linalg.eigvalsh(fisher)
        cov = np.linalg.inv(fisher)
        rel_tau = math.sqrt(float(cov[0, 0])) / tau
        rows.append({
            "sigma_t_over_t": rel,
            "small_eigenvalue": float(eig[0]),
            "large_eigenvalue": float(eig[1]),
            "eigenvalue_ratio": float(eig[0]/eig[1]),
            "sigma_tau_over_tau": rel_tau,
            "sigma_s_over_s_assumed": sigma_s_rel,
        })
    df = pd.DataFrame(rows)
    fig, ax = plt.subplots(figsize=(9.5, 6.3))
    ax.plot(100.0*df.sigma_t_over_t, 100.0*df.sigma_tau_over_tau, label=r"combined $\sigma_\tau/\tau$")
    gap_ref = abs(LN4-TAU_GRID)/LN4
    ax.axhline(100.0*gap_ref, linestyle="--", linewidth=1.0, label="ln4 vs fixed 9-sample gap")
    ax.axhline(100.0*gap_ref/3.0, linestyle=":", linewidth=1.0, label="one-third gap")
    ax.set_xscale("log")
    ax.set_yscale("log")
    ax.set_xlabel(r"independent $t_{DW}$ precision [%]")
    ax.set_ylabel(r"resulting $\tau$ precision [%]")
    ax.set_title("How an independent timescale anchor completes the Fisher rank")
    ax.legend(fontsize=8)
    ax.text(0.01, 0.01, r"Illustration assumes $\sigma_s/s=0.1\%$; not a GW250114 posterior.",
            transform=ax.transAxes, fontsize=8)
    fig.tight_layout()
    fig.savefig(out, dpi=180)
    plt.close(fig)
    return df


def write_text_outputs(outdir: Path, summary: dict[str, Any], power: pd.DataFrame,
                       amp_scan: pd.DataFrame, observable: pd.DataFrame,
                       inputs: pd.DataFrame, prior_targets: pd.DataFrame,
                       mc: pd.DataFrame, selftest: dict[str, Any],
                       gates: pd.DataFrame) -> None:
    p_const = power.loc[power.scenario == "constant_rho_fixed_t"].iloc[0]
    p_amp = power.loc[power.scenario == "rho_exp_minus_tau_phase_aligned"].iloc[0]
    a1 = amp_scan.iloc[(amp_scan.amplitude_exponent_a-1.0).abs().argmin()]
    required_present = int(inputs[inputs.required == True].present.sum())
    required_total = int((inputs.required == True).sum())
    bf3_width = float(prior_targets.loc[prior_targets.target_bf_physical_over_grid == 3.0,
                                        "max_sigma_t_over_t_percent"].iloc[0])
    bf10_width = float(prior_targets.loc[prior_targets.target_bf_physical_over_grid == 10.0,
                                         "max_sigma_t_over_t_percent"].iloc[0])
    bf100_width = float(prior_targets.loc[prior_targets.target_bf_physical_over_grid == 100.0,
                                          "max_sigma_t_over_t_percent"].iloc[0])
    mc_max_abs = float(mc.absolute_difference.max())

    report = f"""# GW250114 HRF v69 — Exact single-delay nonidentifiability theorem and observable-completion gate

**Date:** {DATE}  
**Status:** methods/admission-control only; **not a detection or discovery claim**.

## Executive result

v69 unifies the two v68 findings and strengthens them into an exact theorem.

For the current transfer with `rho` fixed with respect to `tau` and `t_DW`,

```text
H(f; tau, t_DW, rho) = 1 + rho exp[-i pi f tau t_DW],
```

the data depend on `tau` and `t_DW` only through `s=tau*t_DW`. The waveform derivatives obey

```text
partial_t H = (tau/t_DW) partial_tau H,
```

so the `(tau,t_DW)` Fisher block has determinant exactly zero for every carrier, detector network, PSD, sample rate, and SNR. Infinite SNR narrows the product but does not select a point along the ridge.

This structural lock is separate from the finite-power lock. Even if `t_DW` is frozen, the v65 carrier gives

- `M = {float(p_const.match_M):.12f}`,
- `1-M^2 = {float(p_const.one_minus_M2):.9e}`,
- direct-wave network SNR context `sqrt(15.8^2+17.1^2) = {DIRECT_WAVE_NETWORK_SNR:.6f}`,
- `E[D] = {float(p_const['expected_D_at_directwave_network_23p282']):.6f}`,
- `P(D>0) ~= {float(p_const['sign_accuracy_at_directwave_network_23p282']):.6f}`,
- SNR for 90% sign accuracy `= {float(p_const.snr_required_sign_accuracy_90pct):.1f}`,
- SNR for expected BF=10 `= {float(p_const.snr_required_expected_BF10):.1f}`.

Thus the current point statistic is both structurally nonidentifiable when the timescale is free and severely underpowered when it is fixed. The direct-wave SNR used here is already an optimistic ceiling for the HRF branch component; the branch-modulation SNR cannot exceed the SNR of the full direct-wave component.

The analytic sign probabilities use the exact first two moments of the one-complex-amplitude profile statistic followed by a Gaussian moment approximation. A `{MC_N:,}`-draw complex-noise Monte Carlo reproduces those probabilities with maximum absolute discrepancy `{mc_max_abs:.4g}` across the audited scenarios and SNR points.

## The exact rank theorem

Let a detector-conditioned carrier be `c_k(f)` in detector `k`, with `rho` independent of `tau` and `t`, and let

```text
h_k(f;tau,t) = c_k(f) [1 + rho exp(-i pi f tau t)].
```

Define `u_k(f)=-i pi f c_k(f) rho exp(-i pi f tau t)`. Then

```text
partial_tau h_k = t u_k,
partial_t   h_k = tau u_k.
```

The network Fisher block is therefore an outer product,

```text
Gamma_(tau,t) = A [[t^2, t tau], [t tau, tau^2]],   A >= 0,
```

and

```text
det Gamma_(tau,t) = 0.
```

The null direction is the infinitesimal scaling `(delta tau, delta t) proportional to (tau,-t)`, corresponding to the exact finite transformation

```text
(tau,t) -> (a tau, t/a).
```

This is a model theorem, not a numerical coincidence.

## Catalog-stacking theorem

For `N` events with a shared branch parameter `tau` and free event times `t_j`, the product-only observables are `s_j=tau*t_j`. The Jacobian has `N` rows and `N+1` columns and always retains the null vector

```text
(tau,-t_1,...,-t_N).
```

Therefore adding events improves detection of the products but does **not** identify `tau` unless at least one event has an independent timescale anchor or another nonproduct observable. This corrects the earlier idea that rescaled-frequency stacking alone could identify the lattice branch.

## Marginal evidence is prior-driven on the ridge

In the infinite product-SNR limit,

```text
Z(tau_i) proportional to p_t(s/tau_i)/|tau_i|.
```

A broad uniform prior in `t` gives a small Jacobian preference for the smaller grid branch; a broad log-uniform prior gives exactly BF=1. A narrow Gaussian prior can create a large BF, but that evidence is supplied by the external timescale prior. In the old fixed-t geometry, the exact infinite-product-SNR prior-width ceilings are:

- BF >= 3: `sigma_t/t <= {bf3_width:.6f}%`;
- BF >= 10: `sigma_t/t <= {bf10_width:.6f}%`;
- BF >= 100: `sigma_t/t <= {bf100_width:.6f}%`.

These are not event posteriors. They quantify how strong an external timescale constraint would have to be before product-only branch evidence becomes appreciable.

## Amplitude-law completion audit

A fixed, physically calibrated amplitude law can break the rank defect. For the minimal lock

```text
rho(tau)=exp(-tau),
```

the exact phase-aligned branches have

- `1-M^2 = {float(p_amp.one_minus_M2):.9e}`,
- `P(D>0 | SNR={DIRECT_WAVE_NETWORK_SNR:.3f}) ~= {float(p_amp['sign_accuracy_at_directwave_network_23p282']):.6f}`,
- SNR for 90% sign accuracy `= {float(p_amp.snr_required_sign_accuracy_90pct):.1f}`.

So this natural internal completion removes the exact equality but is even more underpowered after the nuisance timescale aligns the phases.

Moreover, a law of the form `rho=C*r(tau)` does **not** identify `tau` if the multiplicative normalization `C` is free: changing the branch can be exactly compensated by

```text
C' = C r(tau)/r(tau').
```

Absolute amplitude and phase calibration, or an additional nonfactorizable observable, is required.

At `a=1` in `rho=exp(-a tau)`, the phase-aligned SNR90 is approximately `{float(a1.snr90_phase_aligned):.1f}`. For the older small-reflectivity rungs `a>=8`, the absolute modulation becomes so small that the required SNR grows dramatically.

## Observable-completion criterion

Take the product observable `s=tau*t` and any second scalar prediction `g(tau,t)`. Local identifiability requires

```text
Delta_g = det [[partial_tau s, partial_t s],
               [partial_tau g, partial_t g]]
        = t partial_t g - tau partial_tau g != 0.
```

The emitted scorecard applies this criterion. Genuine completions include:

1. an independently measured `t_DW` posterior;
2. an echo invariant `kappa Delta t_echo=tau` with independent `kappa`;
3. an absolutely calibrated amplitude law;
4. a second delay/harmonic with nonproportional `tau` dependence.

More detectors, more bins, 4/16-kHz resampling, a second pure multiple of the same delay, minimum-phase reconstruction of the same transfer, and catalog stacking with free event times do not remove the rank defect. They remain useful detection/systematics tests. An "independent timescale" can come from the same strain only when it is encoded through a genuinely different waveform feature, such as a time-domain envelope, and is fitted jointly rather than reused as a fixed plug-in estimate.

## Updated real-data protocol

```text
Nature direct-wave release + official remnant posterior intake
-> freeze Kerr-linked, free/evolving-transient, and standard-GR lanes
-> estimate nuisance timescale in a joint or detector-cross-fitted analysis
-> require an observable-completion determinant distinct from zero
-> source-hygiene eta_perp gate
-> realistic-SNR injections
-> sign-locked D=0 branch test
-> 4k/16k and noncommensurate operator-grid veto
-> waveform-family and detector leave-one-out survival
-> physical interpretation only if every gate passes
```

## Input status

Required official inputs present: `{required_present}/{required_total}`. The current runtime therefore cannot execute the draw-level/direct-wave posterior or detector likelihood.

## Honest status after v69

- v67's `D=0` boundary remains correct for fixed point hypotheses.
- v68's product-coordinate warning is now an exact Fisher-rank theorem.
- v68's finite-SNR concern is reproduced and incorporated.
- All numerical gauge, catalog-rank, free-normalization, and sign-power self-tests pass: `{selftest['all_pass']}`.
- The natural fixed-normalization amplitude lock is not powerful enough at GW250114-relevant SNR under the current carrier.
- The original three-channel triangulation is now understood as a mathematical identifiability requirement, not optional corroboration.
- Real `ln(4)`, `g=4`, area-quantization, or quantum-horizon interpretation remains locked.
- No Zenodo update is recommended until an official-input observable-completion run exists.
"""
    (outdir / "GW250114_V69_EXACT_IDENTIFIABILITY_AND_OBSERVABLE_COMPLETION.md").write_text(report)

    proof = r"""# GW250114 HRF v69 theorem and proof

## Theorem 1 — Single-delay product gauge

Let a network waveform have detector components

\[
h_k(f;\tau,t,\rho)=c_k(f)\left[1+\rho e^{-i\pi f\tau t}\right],
\]

where each carrier \(c_k\), the noise inner products, and the fixed complex coefficient \(\rho\) are otherwise arbitrary, with \(\rho\) independent of \(\tau\) and \(t\). Then \(\tau\) and \(t\) are not separately identifiable from these data.

### Proof

Set

\[
u_k(f)=-i\pi f c_k(f)\rho e^{-i\pi f\tau t}.
\]

Then

\[
\partial_\tau h_k=t u_k,\qquad \partial_t h_k=\tau u_k.
\]

The derivative vectors are exactly collinear in every detector. Any network Fisher matrix formed by summing detector inner products therefore has

\[
\Gamma_{\tau t}=A
\begin{pmatrix}
t^2&t\tau\\
t\tau&\tau^2
\end{pmatrix},\qquad A\ge0,
\]

and determinant zero. Equivalently, the finite transformation

\[
(\tau,t)\mapsto(a\tau,t/a)
\]

leaves every waveform sample unchanged. QED.

## Corollary 1 — Infinite SNR does not select the branch

As SNR tends to infinity, the likelihood can collapse onto \(s=\tau t=s_0\), but it remains constant along that curve. Branch evidence after marginalizing \(t\) is therefore supplied by the nuisance prior and Jacobian:

\[
Z(\tau_i)\propto \frac{p_t(s_0/\tau_i)}{|\tau_i|}.
\]

For a Gaussian prior centered on the physical-branch time \(t_p\), the exact
infinite-product-SNR branch ratio is

\[
\mathrm{BF}_{p/g}=\frac{\tau_g}{\tau_p}
\exp\!\left[\frac{(t_g-t_p)^2}{2\sigma_t^2}\right].
\]

This expression makes explicit that any product-only branch preference is a
statement about the nuisance prior, not new likelihood curvature transverse to
the product ridge.

## Theorem 2 — Catalog stacking retains one null direction

For \(N\) events with shared \(\tau\), event times \(t_j\), and product observables \(s_j=\tau t_j\), the Jacobian has null vector

\[
v=(\tau,-t_1,\ldots,-t_N).
\]

Thus its rank is at most \(N\) for \(N+1\) parameters. No number of product-only events identifies the shared \(\tau\) without an anchor. QED.

## Theorem 3 — Observable-completion criterion

Add a second scalar prediction \(g(\tau,t)\). The map \((\tau,t)\mapsto(s,g)\), with \(s=\tau t\), is locally invertible iff

\[
\Delta_g=t\,\partial_tg-\tau\,\partial_\tau g\ne0.
\]

This follows immediately from the inverse-function theorem.

## Corollary 2 — A free amplitude normalization restores the gauge

Suppose

\[
H=1+C r(\tau)e^{-i\pi f\tau t}
\]

with free multiplicative \(C\). For any \(\tau'\), choose

\[
t'=\frac{\tau t}{\tau'},\qquad C'=C\frac{r(\tau)}{r(\tau')}.
\]

Then \(H(f;\tau',t',C')=H(f;\tau,t,C)\) exactly. Therefore a branch-dependent amplitude law is not an identifying observable unless its absolute normalization is constrained or another nonfactorizable prediction is added.

## Practical interpretation

The theorem does not rule out horizon-response physics. It states the minimum information content the measurement must contain. A valid physical claim requires either an independent timescale, an independently calibrated branch amplitude, an echo/QNM channel that measures \(\tau\) differently, or a richer transfer with nonproportional branch dependence.
"""
    (outdir / "GW250114_V69_THEOREM_AND_PROOF.md").write_text(proof)

    cert = f"""# GW250114 v69 one-page identifiability certificate

**Certificate:** negative admission-control result for the current single-delay transfer.  
**Claim status:** no detection or physical branch interpretation certified.

## Exact result

For `H=1+rho exp(-i pi f tau t_DW)` with `rho` fixed independently of `tau` and `t_DW`, the waveform depends on `tau` and `t_DW` only through `tau*t_DW`. The network Fisher determinant in those two parameters is exactly zero and the transformation `(tau,t)->(a tau,t/a)` leaves the signal unchanged.

## Finite-power result

With `t_DW=3.183821 ms` frozen and the v65 carrier:

- `M={float(p_const.match_M):.12f}`;
- `1-M^2={float(p_const.one_minus_M2):.9e}`;
- at the optimistic full-direct-wave network SNR `{DIRECT_WAVE_NETWORK_SNR:.3f}`, `P(correct sign)={float(p_const['sign_accuracy_at_directwave_network_23p282']):.4f}`;
- 90% sign accuracy requires SNR `{float(p_const.snr_required_sign_accuracy_90pct):.1f}`.

A fixed-normalization `rho=exp(-tau)` law breaks exact equality but, after phase alignment, requires SNR `{float(p_amp.snr_required_sign_accuracy_90pct):.1f}` for 90% sign accuracy. If its normalization is free, the exact gauge returns.

At infinite product SNR, an external Gaussian `t_DW` prior would need width `<= {bf10_width:.6f}%` to supply BF>=10 for the physical branch in the old fixed-t geometry. This is a prior-resolution target, not evidence from the strain.

## Certificate statement

> The present single-delay branch statistic cannot identify `ln(4)` from GW250114 at event-relevant SNR, and it cannot identify `tau` at any SNR while `t_DW` remains free. More events or resampling alone do not repair this. A physical interpretation requires an independent timescale, an absolutely calibrated branch-amplitude law, an echo/QNM channel with nonproduct dependence, or another derived observable satisfying `t g_t - tau g_tau != 0`.

## Decision

`ln(4)`, `g=4`, area-quantization, and quantum-horizon interpretations remain **LOCKED**. No new Zenodo version is recommended before the official direct-wave/posterior data pass an observable-completion analysis.
"""
    (outdir / "GW250114_V69_ONE_PAGE_IDENTIFIABILITY_CERTIFICATE.md").write_text(cert)

    runbook = """# GW250114 HRF v69 runbook

## Reproduce

```bash
python gw250114_v69_exact_identifiability.py \
  --v65-score-table reference_inputs/GW250114_V65_score_table.csv \
  --input-dir official_inputs \
  --outdir v69_outputs
```

Python requirements: numpy, pandas, scipy, matplotlib.

## Read first

1. `GW250114_V69_ONE_PAGE_IDENTIFIABILITY_CERTIFICATE.md`
2. `GW250114_V69_EXACT_IDENTIFIABILITY_AND_OBSERVABLE_COMPLETION.md`
3. `GW250114_V69_observable_completion_matrix.csv`
4. `GW250114_V69_point_power_context.csv`
5. `GW250114_V69_gate_status.csv`
6. `GW250114_V69_NUMERICAL_SELF_TEST.json`

## Interpretation rules

- Do not use a fixed-timescale `D>0` as a physical certificate.
- Do not count H1/L1, 4/16 kHz, or multiple bins as independent branch coordinates.
- Do not use catalog stacking to infer a shared `tau` unless at least one nonproduct anchor is included.
- If a branch-amplitude law contains a free normalization, test its exact reparameterization before claiming rank completion.
- Preserve the v67 `D=0` boundary only inside a fully specified point-hypothesis or marginalized model comparison.
"""
    (outdir / "GW250114_V69_RUNBOOK.md").write_text(runbook)

    next_task = """# GW250114 HRF v69 next task

## Highest-value execution

Use the official Nature direct-wave release and NRSur7dq4 posterior to build a **joint or detector-cross-fitted nuisance anchor**:

1. extract segmented direct-wave frequency/damping posteriors rather than assuming one constant horizon-linked decay time;
2. run three frozen lanes: Kerr-linked, free/evolving transient, and standard GR/QNM;
3. estimate the nuisance timescale in H1 and test the branch in L1, then swap detectors;
4. compute the full joint evidence so the timescale uncertainty and its correlation with the branch statistic are propagated;
5. require an observable-completion determinant distinct from zero before interpreting `D_marg`;
6. repeat at 4 kHz and 16 kHz only as an operator/grid veto, not as independent evidence.

## Immediate stop condition

Stop the single-event physical branch lane if every defensible model has either:

- a product-gauge/null Fisher direction;
- 90%-accuracy required SNR far above the recovered branch-component SNR; or
- branch evidence that changes materially under the nuisance prior, waveform family, detector split, or direct-wave model.

A negative identifiability result is publishable methods progress; it is not a failed experiment.
"""
    (outdir / "GW250114_V69_NEXT_TASK.md").write_text(next_task)

    decision_ladder = """# GW250114 HRF v69 decision ladder

```text
canonical v65-v68 reproduction
-> exact single-delay rank audit
-> realistic branch-component SNR/power audit
-> official Nature direct-wave + LVK posterior intake
-> frozen Kerr-linked / free-evolving / standard-GR model lanes
-> joint or detector-cross-fitted nuisance-timescale inference
-> observable-completion determinant t*g_t - tau*g_tau != 0
-> source-hygiene eta_perp gate
-> source-only/off-source detection calibration
-> matched branch controls with conditional D=0 boundary
-> real on-source marginalized branch evidence
-> 4 kHz / 16 kHz / noncommensurate operator-grid veto
-> waveform-family and detector leave-one-out survival
-> GR-residual and absolute-amplitude diagnostics
-> physical interpretation only if every gate passes
```

## Locked shortcuts

- A fixed plug-in `t_DW` estimate is not a substitute for a joint posterior.
- H1/L1 duplication, extra frequency bins, and resampling do not add a new physical coordinate.
- Product-only catalog stacking retains one global scale null direction.
- A branch-dependent amplitude law with free multiplicative normalization is still gauge-degenerate.
"""
    (outdir / "GW250114_V69_DECISION_LADDER.md").write_text(decision_ladder)

    release_notes = f"""# GW250114 HRF v69 release notes

## What changed from v68

1. Upgraded the product-coordinate warning to an exact network Fisher-rank theorem.
2. Proved that product-only catalog stacking retains one null direction for any event count.
3. Added the general observable-completion determinant `t*g_t - tau*g_tau`.
4. Reproduced the fixed-timescale branch mismatch and translated it to realistic-SNR sign power.
5. Audited a fixed-normalization amplitude law and proved that a free normalization restores the gauge.
6. Added exact prior-width targets: BF10 requires `sigma_t/t <= {bf10_width:.6f}%` in the old geometry at infinite product SNR.
7. Added a `{MC_N:,}`-draw sign-power Monte Carlo and numerical gauge/rank self-tests.
8. Added a gate-status scorecard and official-input manifest.

## Decision

This is a methods/admission-control advance, not a black-hole discovery. The real physical branch remains locked pending an observable-complete official-data analysis. A new Zenodo release is not recommended yet.
"""
    (outdir / "GW250114_V69_RELEASE_NOTES.md").write_text(release_notes)

    official_inputs_note = """# Official inputs for the next execution

The v69 theorem and synthetic-power audit run without external binaries. The real-data lane requires:

- `GW250114_horizon_signatures.zip` from Zenodo record 20017347;
- `posterior_samples_NRSur7dq4.h5` from Zenodo record 16877102;
- H1 and L1 4096-second, 4-kHz GWOSC strain files for GW250114.

The three other waveform-posterior files in the manifest are optional for the first run and required for the later waveform-family systematics gate.

Place downloaded files in `official_inputs/`, run the script, and require checksum matches where checksums are provided. The current package was generated with 0/4 required files present because the execution environment could not complete the external downloads.
"""
    (outdir / "GW250114_V69_OFFICIAL_INPUTS.md").write_text(official_inputs_note)

    fetch = r'''#!/usr/bin/env bash
set -euo pipefail

DEST="${1:-official_inputs}"
mkdir -p "$DEST"

fetch() {
  local url="$1"
  local name="$2"
  echo "Fetching $name"
  curl -L --fail --retry 5 --retry-delay 5 -o "$DEST/$name.part" "$url"
  mv "$DEST/$name.part" "$DEST/$name"
}

fetch "https://zenodo.org/records/20017347/files/GW250114_horizon_signatures.zip?download=1" \
      "GW250114_horizon_signatures.zip"
fetch "https://zenodo.org/records/16877102/files/posterior_samples_NRSur7dq4.h5?download=1" \
      "posterior_samples_NRSur7dq4.h5"
fetch "https://gwosc.org/archive/data/O4b_4KHZ_R1/1420820480/H-H1_GWOSC_O4b_4KHZ_R1-1420877824-4096.hdf5" \
      "H-H1_GWOSC_O4b_4KHZ_R1-1420877824-4096.hdf5"
fetch "https://gwosc.org/archive/data/O4b_4KHZ_R1/1420820480/L-L1_GWOSC_O4b_4KHZ_R1-1420877824-4096.hdf5" \
      "L-L1_GWOSC_O4b_4KHZ_R1-1420877824-4096.hdf5"

echo "Expected MD5 checksums for the two Zenodo files:"
echo "4874fef35088209c9fa4073f15a27a78  $DEST/GW250114_horizon_signatures.zip"
echo "9b115931b66439a1d5649a2b7b7aa143  $DEST/posterior_samples_NRSur7dq4.h5"
command -v md5sum >/dev/null && md5sum \
  "$DEST/GW250114_horizon_signatures.zip" \
  "$DEST/posterior_samples_NRSur7dq4.h5" || true
'''
    fetch_path = outdir / "GW250114_V69_FETCH_OFFICIAL_INPUTS.sh"
    fetch_path.write_text(fetch)
    fetch_path.chmod(0o755)

    sources = """# Sources and provenance

Primary external anchors used by v69:

- GWOSC GW250114 event page and open strain products: DOI 10.7935/1g4j-2028.
- LVK GW250114 discovery data release: DOI 10.5281/zenodo.16877102.
- Lu et al., Nature 655, 71-75 (2026), `GW250114 reveals signatures of post-merger black-hole horizon`.
- Lu et al. companion data release: DOI 10.5281/zenodo.20017347.
- Kankani & McWilliams, arXiv:2607.02380v1 (2 July 2026), `The Direct Wave is Not a Meaningful Test of Horizon Properties`.

Internal provenance:

- v65 score table from the canonical user-supplied v68 master bundle.
- v67 sign threshold and v68 product-coordinate calculations are reproduced rather than assumed.

No external binary data were present in the runtime used to generate this package.
"""
    (outdir / "SOURCES.md").write_text(sources)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--outdir", type=Path, default=Path("v69_outputs"))
    ap.add_argument("--v65-score-table", type=Path, default=None)
    ap.add_argument("--input-dir", type=Path, default=Path("official_inputs"))
    args = ap.parse_args()
    outdir = args.outdir
    outdir.mkdir(parents=True, exist_ok=True)
    args.input_dir.mkdir(parents=True, exist_ok=True)

    power, geometry = point_power_rows()
    amp = amplitude_scan()
    priors = prior_coordinate_rows()
    prior_targets = prior_precision_target_rows()
    catalog = catalog_rank_rows()
    observable = observable_completion_rows()
    inputs = input_manifest(args.input_dir)
    synthetic = synthetic_snr_audit(args.v65_score_table)
    gates = gate_status_rows(power, inputs)
    mc = profile_sign_monte_carlo(power)
    selftest = numerical_self_test(power, mc)

    power.to_csv(outdir / "GW250114_V69_point_power_context.csv", index=False)
    amp.to_csv(outdir / "GW250114_V69_amplitude_lock_scan.csv", index=False)
    priors.to_csv(outdir / "GW250114_V69_prior_coordinate_sensitivity.csv", index=False)
    prior_targets.to_csv(outdir / "GW250114_V69_prior_precision_targets.csv", index=False)
    catalog.to_csv(outdir / "GW250114_V69_catalog_rank_audit.csv", index=False)
    observable.to_csv(outdir / "GW250114_V69_observable_completion_matrix.csv", index=False)
    inputs.to_csv(outdir / "GW250114_V69_official_input_manifest.csv", index=False)
    gates.to_csv(outdir / "GW250114_V69_gate_status.csv", index=False)
    mc.to_csv(outdir / "GW250114_V69_sign_power_monte_carlo.csv", index=False)
    (outdir / "GW250114_V69_NUMERICAL_SELF_TEST.json").write_text(
        json.dumps(selftest, indent=2, sort_keys=True, default=float)
    )

    fisher = plot_fisher_completion(outdir / "GW250114_V69_fisher_completion.png")
    fisher.to_csv(outdir / "GW250114_V69_fisher_completion_curve.csv", index=False)
    plot_likelihood_ridge(outdir / "GW250114_V69_product_likelihood_ridge.png")
    plot_snr_power(power, outdir / "GW250114_V69_sign_power_context.png")
    plot_amplitude_scan(amp, outdir / "GW250114_V69_amplitude_lock_power.png")
    plot_prior_sensitivity(priors, outdir / "GW250114_V69_prior_driven_evidence.png")

    p_const = power.loc[power.scenario == "constant_rho_fixed_t"].iloc[0]
    p_amp = power.loc[power.scenario == "rho_exp_minus_tau_phase_aligned"].iloc[0]
    precision_targets = {
        f"max_sigma_t_over_t_for_BF_ge_{int(row.target_bf_physical_over_grid)}": float(row.max_sigma_t_over_t)
        for _, row in prior_targets.iterrows()
    }

    summary = {
        "version": VERSION,
        "date": DATE,
        "status": STATUS,
        "exact_theorems": {
            "single_event_product_gauge": True,
            "fisher_determinant_tau_t": 0.0,
            "catalog_product_only_nullity": 1,
            "observable_completion_condition": "t*d_t(g)-tau*d_tau(g) != 0",
            "free_amplitude_normalization_restores_gauge": True,
        },
        "geometry": geometry,
        "direct_wave_snr": {
            "H1": DIRECT_WAVE_SNR_H1,
            "L1": DIRECT_WAVE_SNR_L1,
            "network": DIRECT_WAVE_NETWORK_SNR,
        },
        "constant_rho_fixed_t": p_const.to_dict(),
        "fixed_normalization_amplitude_lock_phase_aligned": p_amp.to_dict(),
        "synthetic_control_audit": synthetic,
        "profile_sign_monte_carlo": {
            "n_draws_per_scenario": MC_N,
            "seed": MC_SEED,
            "max_absolute_probability_difference": float(mc.absolute_difference.max()),
        },
        "numerical_self_test_all_pass": bool(selftest["all_pass"]),
        "prior_precision_targets": precision_targets,
        "official_required_present": int(inputs[inputs.required == True].present.sum()),
        "official_required_total": int((inputs.required == True).sum()),
        "verdict": "LOCKED_OBSERVABLE_COMPLETION_AND_REALISTIC_POWER_REQUIRED",
    }
    (outdir / "GW250114_V69_summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True, default=float))
    write_text_outputs(outdir, summary, power, amp, observable, inputs,
                       prior_targets, mc, selftest, gates)

    # Requirements and README are generated inside outputs for standalone use.
    (outdir / "requirements.txt").write_text("numpy\npandas\nscipy\nmatplotlib\n")
    readme = f"""# HRF v69 standalone output

Version: `{VERSION}`  
Status: methods-only; no detection claim.

Run `python gw250114_v69_exact_identifiability.py --help` from the package root. The core result is the exact product-gauge theorem plus the observable-completion scorecard.

Required official inputs present during this run: `{summary['official_required_present']}/{summary['official_required_total']}`.
"""
    (outdir / "README.md").write_text(readme)

    # Manifest last, excluding itself.
    files = []
    for p in sorted(outdir.iterdir()):
        if p.is_file() and p.name != "GW250114_V69_manifest.json":
            files.append({"name": p.name, "size_bytes": p.stat().st_size, "sha256": sha256(p)})
    manifest = {
        "version": VERSION,
        "date": DATE,
        "status": STATUS,
        "files": files,
        "summary_sha256": sha256(outdir / "GW250114_V69_summary.json"),
    }
    (outdir / "GW250114_V69_manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True))
    print(json.dumps(summary, indent=2, sort_keys=True, default=float))


if __name__ == "__main__":
    main()
