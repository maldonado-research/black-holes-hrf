# GW250114 HRF v70 decision ladder

```text
v69 canonical theorem and package replay
-> fail-closed discovery-v1 official binary intake
-> 4-kHz native-grid and 16-kHz Nature-replay prerequisites
-> four-family remnant mass-spin covariance propagation
-> exact independent-Gaussian nuisance-anchor BF/sign benchmark
-> released effective-rate grid normalization and summary
-> effective-rate-to-horizon mapping audit
-> same-strain double-counting and overlap audit
-> detector-separated cross-fit availability audit
-> release-code likelihood-mixture firewall
-> observable-completion local-rank and global-alias gates
-> STOP: no standalone completion admitted; joint covariance unavailable
-> physical interpretation remains locked
```

## Locked shortcuts

- A same-event Kerr remnant posterior is not an independent direct-wave timescale posterior.
- Effective `kappa_hat` is not horizon `kappa` when the trajectory factor is free.
- Seven overlapping windows are not seven independent anchors.
- A network cache cannot substitute for detector cross-fitting.
- Arithmetic averaging of log likelihoods is not nuisance marginalization.
- Valid files and a conditionally nonzero rank candidate are not enough; the physical mapping, covariance-complete ratio precision, and discrete global alias gate must pass.
