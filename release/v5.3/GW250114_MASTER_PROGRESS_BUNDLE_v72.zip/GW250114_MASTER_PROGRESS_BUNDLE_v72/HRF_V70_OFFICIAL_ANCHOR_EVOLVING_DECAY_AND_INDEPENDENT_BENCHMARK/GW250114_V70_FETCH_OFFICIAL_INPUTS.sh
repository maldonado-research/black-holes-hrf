#!/usr/bin/env bash
set -euo pipefail

DEST="${1:-official_inputs}"
mkdir -p "$DEST"

fetch() {
  local url="$1"
  local name="$2"
  echo "Fetching $name"
  curl -L --fail --retry 8 --retry-all-errors --retry-delay 3 \
    -o "$DEST/$name.part" "$url"
  mv "$DEST/$name.part" "$DEST/$name"
}

fetch "https://zenodo.org/api/records/20017347/files/GW250114_horizon_signatures.zip/content" \
  "GW250114_horizon_signatures.zip"

for name in \
  posterior_samples_NRSur7dq4.h5 \
  posterior_samples_PhenomXO4a.h5 \
  posterior_samples_PhenomXPHM.h5 \
  posterior_samples_SEOBNRv5PHM.h5; do
  fetch "https://zenodo.org/api/records/16877102/files/$name/content" "$name"
done

fetch "https://gwosc.org/archive/data/O4b_4KHZ_R1/1420820480/H-H1_GWOSC_O4b_4KHZ_R1-1420877824-4096.hdf5" \
  "H-H1_GWOSC_O4b_4KHZ_R1-1420877824-4096.hdf5"
fetch "https://gwosc.org/archive/data/O4b_4KHZ_R1/1420820480/L-L1_GWOSC_O4b_4KHZ_R1-1420877824-4096.hdf5" \
  "L-L1_GWOSC_O4b_4KHZ_R1-1420877824-4096.hdf5"
fetch "https://gwosc.org/archive/data/O4b_16KHZ_R1/1420820480/H-H1_GWOSC_O4b_16KHZ_R1-1420877824-4096.hdf5" \
  "H-H1_GWOSC_O4b_16KHZ_R1-1420877824-4096.hdf5"
fetch "https://gwosc.org/archive/data/O4b_16KHZ_R1/1420820480/L-L1_GWOSC_O4b_16KHZ_R1-1420877824-4096.hdf5" \
  "L-L1_GWOSC_O4b_16KHZ_R1-1420877824-4096.hdf5"

cat > "$DEST/zenodo_md5.txt" <<'EOF'
4874fef35088209c9fa4073f15a27a78  GW250114_horizon_signatures.zip
9b115931b66439a1d5649a2b7b7aa143  posterior_samples_NRSur7dq4.h5
cf690b8ea60c2d0f469bd5f7960119c6  posterior_samples_PhenomXO4a.h5
62991eb44428c1f0e4fe9bd173b9f1b6  posterior_samples_PhenomXPHM.h5
74ee4e88c189c7f76d2735b7999683fc  posterior_samples_SEOBNRv5PHM.h5
EOF

(cd "$DEST" && md5sum -c zenodo_md5.txt)
echo "Zenodo checksums pass. Run the v70 Python validator for ZIP/HDF5/strain schema checks."
