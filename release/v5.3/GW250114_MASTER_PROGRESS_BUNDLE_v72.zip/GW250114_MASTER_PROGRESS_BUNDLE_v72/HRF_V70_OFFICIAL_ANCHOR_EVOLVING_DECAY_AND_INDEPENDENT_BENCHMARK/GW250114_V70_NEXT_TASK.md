# GW250114 HRF v70 next task

## Highest-value continuation

Build either one covariance-complete joint observable-completion likelihood or a genuinely detector-separated cross-fit from the official 16-kHz strain.

1. Pin discovery-v1 strain, posterior files, calibration data, PSDs, and the embedded `qnm_filter` commit.
2. Correct the released figure-5 likelihood mixture to weighted `logsumexp`; remove or justify the apparent second posterior weighting.
3. Summarize the baseline network grids, then generate H1-only and L1-only effective-rate surfaces from raw strain.
4. For H1 anchor -> L1 branch and the swap, infer remnant/QNM/direct-wave nuisances detector-specifically; do not import the released H1+L1 network posterior into the held-out detector.
5. Fit effective `kappa_hat(t)`, trajectory `beta_traj(t)`, horizon `kappa`, QNM subtraction, remnant draws, calibration, and HRF `(tau,t_DW)` in one declared covariance model.
6. Compute the augmented Jacobian gauge derivative and smallest singular value.
7. Require global branch separation, not only local rank.
8. Compute the covariance-complete effective fractional branch uncertainty `(tau^2 I_eff)^(-1/2)`, with `I_eff=t^T V_tau^(-1)t`, or the equivalent discrete-branch Mahalanobis separation. Compare that quantity—not a marginal posterior width—with the applicable preregistered threshold.
9. Repeat with 4-kHz data only as the preregistered operator/grid veto and with GWTC-5.0 v2 only as a separately labeled systematics lane.

## Kill condition

Stop the single-event physical branch lane if any defensible Kerr-linked, evolving-transient, or standard-GR construction:

- retains a null or near-null gauge direction;
- requires an unconstrained trajectory-to-horizon map;
- cannot cross-fit or form a single joint likelihood without double counting;
- cannot reach the preregistered branch separation after the full product–anchor covariance and common systematic floor are included;
- changes materially across waveform family, detector direction, release version, or nuisance prior.

A documented negative result remains valid scientific progress.
