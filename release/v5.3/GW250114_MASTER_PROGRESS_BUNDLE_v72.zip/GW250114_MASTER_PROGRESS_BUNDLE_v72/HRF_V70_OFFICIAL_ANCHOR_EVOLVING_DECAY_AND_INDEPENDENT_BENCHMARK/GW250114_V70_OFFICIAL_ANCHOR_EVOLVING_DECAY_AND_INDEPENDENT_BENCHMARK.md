# GW250114 HRF v70 — Official anchor, evolving decay, and independent-anchor benchmark gate

**Date:** 2026-07-11  
**Status:** methods/admission-control only; **not a detection or discovery claim**.

## Executive decision

v70 resolves the v69 official-input blocker and reaches an honest negative gate.

All nine frozen official inputs passed identity, integrity, and schema checks: the Nature companion ZIP; four LVK posterior HDF5 files; and H1/L1 GWOSC strain at both 4 kHz and 16 kHz. The analysis then propagated every official remnant posterior through the project’s Kerr-linked timescale convention and normalized/summarized all seven released direct-wave frequency/damping likelihood grids directly from the validated ZIP.

The released information contains plausible **conditional rank-completion candidates**, but the products as delivered do not provide a currently admissible standalone nonproduct anchor for the HRF branch coordinate. Covariance-complete joint precision has not been evaluated. The physical branch remains locked.

## 1. Fail-closed official intake

v69’s input gate checked filename presence but did not require a matching checksum or valid file structure. v70 repairs this.

The validator requires:

- publisher MD5 equality and published byte length for the Nature ZIP and all four Zenodo posterior files;
- frozen v70 SHA-256 equality and exact byte length for the four GWOSC strain products;
- ZIP CRC and mandatory-member checks;
- a unique posterior dataset containing draw-level `final_mass` and `final_spin`;
- HDF5-open success for strain;
- exact sample count, sample spacing, detector metadata, GPS start, and duration.

All nine files pass. The lane is pinned to the GWOSC `O4_Discovery_Papers/GW250114_082203/v1` release used by the Nature companion and LVK discovery package. A future GWTC-5.0 v2 substitution must be treated as a separate systematics lane.

The two 16-kHz strain files are required for an exact Nature-code replay. The v69 4-kHz-only manifest was incomplete for that purpose. The 4-kHz products remain the native-grid/operator veto lane.

v70 validates the raw strain and analyzes the released posterior/cache products. It does **not** claim to have rerun the full `qnm_filter`/NRSur pipeline from raw strain.

## 2. Full official Kerr-linked anchor propagation

For each official posterior draw, v70 applies only the already-declared project diagnostic map

\[
\kappa(M_f,\chi_f)
=
\frac{\sqrt{1-\chi_f^2}}
{2M_f t_\odot\left(1+\sqrt{1-\chi_f^2}\right)},
\qquad
t_K=\frac{2}{\kappa},
\]

where `M_f` is detector-frame final mass and \(t_\odot\) is one solar mass in seconds.

This is a Kerr-linked project coordinate, not an independent direct-wave measurement and not an assumption that the horizon interpretation is correct.

| Waveform family | Median `t_K` (ms) | Posterior `sigma_t/t_ref` | Standalone width / geometric-BF10 benchmark |
|---|---:|---:|---:|
| NRSur7dq4 | 3.161007 | 1.1822% | 5.82 |
| PhenomXO4a | 3.115440 | 1.5591% | 7.67 |
| PhenomXPHM | 3.173448 | 1.3229% | 6.51 |
| SEOBNRv5PHM | 3.136396 | 1.4088% | 6.93 |

These are **posterior-width diagnostics**, not independent measurement-likelihood standard deviations. The arrays include the original parameter-estimation prior and same-strain information. Reuse requires the original prior and a joint or genuinely cross-fitted likelihood. The reported transformed-coordinate probabilities are posterior mass under this diagnostic map, not posterior probabilities for the `ln(4)` model.

For NRSur7dq4, the mass–spin correlation is `0.929145`; the full covariance broadens the earlier independent-marginal proxy. The exact `ln(4)`/nine-sample alignment time, `3.169984221 ms`, lies at the ordinary `59.73` percentile of the NRSur distribution. It is not in a discriminating tail.

With equal weight for each waveform family, the mixture has:

- median `3.14887 ms`;
- standard deviation `0.04872 ms`;
- conventional standard-deviation/mean width `1.5483%` and `sigma_t/t_ref=1.5303%`;
- 5–95% interval `3.06330–3.22302 ms`.

The family medians themselves span `3.11544–3.17345 ms`, a `1.843%` spread. That is `4.22` times the `0.43649%` timescale shift that lets the old neighboring branch match the same product. This is a declared conservative **sensitivity diagnostic**, not a calibrated incompatibility test between the four parameter-estimation posteriors.

Every waveform family fails the standalone independent-Gaussian width screen. None of these same-event posterior marginals is admissible as an external anchor. Covariance-complete joint product/anchor ratio precision remains unevaluated.

## 3. Exact independent-Gaussian anchor benchmark

For the old fixed v65–v69 branches,

\[
\tau_p=\ln 4,
\qquad
\tau_g=1.3802695723157803,
\qquad
R=\frac{\tau_p}{\tau_g}=1.0043649363319673.
\]

If the product is known exactly and an independent Gaussian timescale anchor is centered on the physical branch with fractional width \(\sigma_{\rm rel}=\sigma_t/t_p\), a broad flat-`t` ridge prior gives

\[
\ln \mathrm{BF}_{p/g}
\sim
N\!\left(c+\frac{d^2}{2},d^2\right),
\qquad
c=\ln\frac{\tau_g}{\tau_p},
\qquad
d=\frac{R-1}{\sigma_{\rm rel}}.
\]

This makes the terminology precise: \(\exp(E\ln\mathrm{BF})\) is a geometric-mean/median scale, not \(E[\mathrm{BF}]\).

The exact-product, independent-Gaussian benchmark requirements are:

| Requirement | Maximum `sigma_t/t` |
|---|---:|
| `exp(E log BF) >= 10` | 0.203210% |
| `exp(E log BF) >= 100` | 0.143759% |
| `P(BF > 1) >= 90%` | 0.170074% |
| `P(BF > 1) >= 95%` | 0.132578% |
| `P(BF > 10) >= 90%` | 0.115389% |

Using the NRSur posterior `sigma_t/t_ref=1.182%` as a deliberately Gaussianized counterfactual gives only about `56.9%` probability of the correct BF sign under this independent-anchor benchmark. This is **not event evidence** and not a universal ceiling on a same-data joint analysis. Under zero product–anchor covariance, finite product error weakens the benchmark; unknown same-event covariance can improve or worsen ratio precision and prevents converting the released marginal width into a GW250114 branch probability.

## 4. Released direct-wave grids

The Nature archive contains seven `85 x 40` network log-likelihood grids for start times `-9M` through `-3M`. They cover frequency `160–238 Hz` and effective damping rate `50–890 s^-1`.

Under the release-native uniform frequency/effective-rate grid measure, the `-7M` surface gives:

- MAP and marginal-median effective rate `450 s^-1`;
- central 90% rate interval `400–520 s^-1`;
- effective decay-time median `2.222 ms`;
- central 90% decay-time interval `1.923–2.500 ms`.

The paper treats `-9M` and `-8M` as exploratory early windows. Across all seven cached surfaces the relative decay-time widths are `6.56–17.88%`; across the supported `-7M` through `-3M` search regime they are `8.15–17.88%`, or about `40–88` times the independent-Gaussian geometric-BF10 benchmark. The central rate also evolves materially with the window.

These grids do not directly measure the project coordinate `t_K=2/kappa`. In the authors’ trajectory model,

\[
\widehat\kappa(t)=\frac{2\beta_{\rm traj}(t)}{1+\beta_{\rm traj}(t)}\,\kappa.
\]

Recovering horizon \(\kappa\) requires a trajectory/screening model for \(\beta_{\rm traj}(t)\). Leaving that mapping free retains a nuisance direction, so the released effective rate is only a conditional rank candidate.

The grids also use the same H1/L1 strain and are network-only. They cannot be reused as an external prior without double-counting, cannot implement detector cross-fitting, and cannot be multiplied across the highly overlapping 0.2-second windows.

The proper status is:

```text
CONDITIONAL_RANK_CANDIDATE_NOT_ADMITTED
JOINT_RATIO_PRECISION_NOT_EVALUATED
```

## 5. Release-code firewall

The baseline seven figure-4 grids are admitted as released diagnostics. The figure-5 robustness contours are not yet admitted quantitatively because:

1. the released code arithmetically averages log-likelihood arrays; a Bayesian mixture requires `logsumexp` with declared weights;
2. it appears to reweight already-posterior samples again using `exp(log_likelihood+log_prior)`, producing an effective sample size of roughly `28.7/19990` unless an undocumented residual weight is intended;
3. the cached amplitude/time-offset MCMC flattens all `32 x 5000` rows without a released burn-in or convergence gate and does not sample frequency, damping, `kappa`, or `t_DW`.

These findings do not invalidate the v69 product-gauge theorem or the baseline released grids. They require correction before the robustness surfaces enter HRF evidence.

## 6. v69 semantic and numerical repairs

v70 preserves the correct v69 theorem and repairs eight implementation/wording issues:

- official validation now fails closed;
- “expected BF” is retired unless an actual marginalized evidence model is defined;
- the exact phase-aligned constant-amplitude gauge is set to zero mismatch and infinite required SNR;
- the exact 512-bin v65 base-carrier point-template mismatch is separated from v69’s 8192-bin continuum surrogate;
- the surrogate SNR is labeled full-template SNR, not branch-component SNR;
- the unwhitened carrier calculation is explicitly not a real detector-PSD likelihood;
- official binaries are parsed rather than merely inventoried;
- 16-kHz Nature-replay inputs are added.

The exact 512-bin v65 base-carrier point-template geometry gives

\[
1-M^2=3.17892812113\times10^{-6},
\qquad
\rho_{90}^{\rm moment\text{-}Gaussian}\simeq1016.51,
\]

instead of the 8192-bin surrogate’s approximate `1001.58`. The mismatch is an exact replay of that base-carrier geometry; the sign-power SNR uses the v69 Gaussian moment approximation. Neither is the 96-carrier/control likelihood or a PSD-weighted GW250114 result.

## 7. Final gate decision

| Gate | v70 result |
|---|---|
| Official binary integrity | Pass, 9/9 |
| Raw Nature pipeline replay | Not executed; released caches audited |
| Exact v69 product-gauge theorem | Exact fail retained |
| Kerr-linked standalone-anchor width screen | Fail in all four waveform families |
| Joint product/anchor ratio precision | Not evaluated; covariance unavailable |
| Waveform-family shift sensitivity | Conservative tolerance fail; not incompatibility evidence |
| Released effective-rate rank candidate | Conditional candidate only; free mapping/jointness not admitted |
| Detector cross-fit from cache | Blocked; network-only |
| Figure-5 robustness marginalization | Blocked pending correction |
| Real PSD-weighted HRF likelihood | Stopped upstream |
| `ln(4)`, `g=4`, area quantization, quantum horizon | Locked |

This is useful progress: the official data lane has been executed far enough to show that the currently released products do not, by themselves, perform the mathematical job required by v69.

## Honest conclusion

- No black-hole or quantum-horizon discovery claim.
- No evidence that `ln(4)` is selected by GW250114.
- No reason to reinterpret the old native-grid preference as physical.
- No recommendation for another Zenodo publication yet.
- The next legitimate step is either one covariance-complete joint analysis or a detector-separated 16-kHz cross-fit with detector-specific remnant/QNM/direct-wave nuisances and no network-posterior leakage into the held-out detector.
