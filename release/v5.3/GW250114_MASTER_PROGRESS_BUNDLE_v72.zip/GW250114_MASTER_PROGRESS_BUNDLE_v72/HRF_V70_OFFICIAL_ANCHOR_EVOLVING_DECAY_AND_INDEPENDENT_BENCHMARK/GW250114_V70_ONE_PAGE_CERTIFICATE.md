# GW250114 HRF v70 — One-page official-input certificate

**Claim class:** methods/admission control only. No detection, area-quantization, or quantum-horizon claim.

## What passed

- Nature companion archive: publisher MD5, exact size, ZIP CRC, and required members pass.
- Four official LVK posterior HDF5 files: publisher MD5 and draw schema pass.
- H1/L1 4-kHz and 16-kHz GWOSC strain: exact size, HDF5 schema, detector, sample spacing, sample count, duration, and GPS start pass.
- Total: `9/9` official inputs validated.
- Seven released direct-wave frequency/damping grids normalized and summarized directly from the validated ZIP.
- Full mass–spin covariance propagated for all four waveform families.
- Full raw-strain `qnm_filter`/NRSur pipeline replay: not executed.

## What the official posteriors say

For the project diagnostic `t_K=2/kappa(M_f,chi_f)`:

| Family | Median (ms) | Posterior `sigma_t/t_ref` |
|---|---:|---:|
| NRSur7dq4 | 3.161007 | 1.1822% |
| PhenomXO4a | 3.115440 | 1.5591% |
| PhenomXPHM | 3.173448 | 1.3229% |
| SEOBNRv5PHM | 3.136396 | 1.4088% |

Standalone exact-product, independent-Gaussian old-geometry benchmarks:

- geometric-mean BF10: `<=0.203210%`;
- 90% correct BF sign: `<=0.170074%`;
- 90% probability BF>10: `<=0.115389%`.

All four families fail that standalone width screen. Their median spread is `1.843%`, `4.22x` the old neighboring-branch shift under a declared conservative sensitivity tolerance. These are same-event posterior diagnostics, not independent likelihood errors or an incompatibility test. Joint product–anchor ratio precision is not evaluated because the covariance is not released.

## What the direct-wave cache can and cannot do

At `-7M`, the network cache gives effective rate `450 s^-1` with central 90% `400–520 s^-1`, or decay time `2.222 ms` with `1.923–2.500 ms`.

But it measures evolving effective `kappa_hat`, not horizon `kappa`:

```text
kappa_hat = [2 beta_traj/(1+beta_traj)] kappa.
```

It is also network-only and uses the same strain. The cache cannot provide an independent prior or H1/L1 cross-fit.

## v70 verdict

```text
OFFICIAL INPUTS: PASS
RAW NATURE PIPELINE REPLAY: NOT EXECUTED; RELEASED CACHES AUDITED
V69 PRODUCT GAUGE: EXACT FAIL RETAINED
KERR-LINKED STANDALONE WIDTH SCREEN: FAIL AS INDEPENDENT ANCHOR
JOINT PRODUCT/ANCHOR RATIO PRECISION: NOT EVALUATED
WAVEFORM-FAMILY SHIFT SENSITIVITY: CONSERVATIVE TOLERANCE FAIL
DIRECT-WAVE OBSERVABLE: CONDITIONAL RANK CANDIDATE, NOT ADMITTED
DETECTOR CROSSFIT: BLOCKED BY NETWORK-ONLY CACHE
REAL PSD-WEIGHTED HRF LIKELIHOOD: STOPPED UPSTREAM
PHYSICAL INTERPRETATION: LOCKED
```

No Zenodo update is recommended yet. The next valid route is one covariance-complete joint model or a detector-separated 16-kHz cross-fit with detector-specific remnant/QNM/direct-wave inference and no network-posterior leakage into the held-out detector.
