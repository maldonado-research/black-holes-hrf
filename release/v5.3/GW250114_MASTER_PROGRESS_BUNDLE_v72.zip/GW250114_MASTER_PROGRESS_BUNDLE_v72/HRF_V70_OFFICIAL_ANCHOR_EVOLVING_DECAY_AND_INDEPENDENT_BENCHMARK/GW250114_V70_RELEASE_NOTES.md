# HRF v70 release notes

## Added

- Fail-closed validation of nine official binaries.
- Both 16-kHz GWOSC files required by the Nature replay.
- Full draw-level Kerr-linked coordinate propagation for four waveform families.
- Equal-family mixture and waveform-family spread audit.
- Direct normalization and summary of seven released direct-wave effective-rate grids from the validated ZIP.
- Exact-product, independent-Gaussian nuisance-anchor BF/sign benchmarks.
- Multi-event gauge-quotient completion theorem.
- Second-delay/harmonic completion theorem.
- Official completion-candidate matrix and gate scorecard.
- Release-code audit for likelihood mixing, posterior weighting, MCMC admission, and source-version pinning.

## Corrected from v69

- Input presence no longer implies integrity.
- “Expected BF” terminology retired.
- Exact gauge residual set analytically to zero.
- Exact 512-bin v65 base-carrier point-template mismatch separated from the 8192-bin surrogate; sign-power SNR labeled as a moment-Gaussian approximation.
- Full-template SNR labeling restored.
- Synthetic carrier power explicitly separated from a detector-PSD likelihood.
- Official binaries now parsed.
- 16-kHz replay requirement added.

## Decision

Official-input intake passes. No released product is admitted as a standalone completion; covariance-complete joint ratio precision remains unevaluated. Physical interpretation remains locked, and no new Zenodo release is recommended.
