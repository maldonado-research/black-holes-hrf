# GW250114 HRF v70 runbook

## Environment

- Python `3.12.13`
- `numpy==2.5.1`
- `h5py==3.16.0`
- `matplotlib==3.10.8`

Install with:

```bash
python -m pip install -r requirements.txt
```

## Fetch and stage inputs

```bash
bash GW250114_V70_FETCH_OFFICIAL_INPUTS.sh official_inputs
```

The analysis is pinned to GWOSC `O4_Discovery_Papers/GW250114_082203/v1`. Do not silently substitute GWTC-5.0 v2.

## Execute

```bash
python gw250114_v70_official_anchor_gate.py \
  --input-dir official_inputs \
  --outdir reproduced_outputs \
  --strict
```

Strict mode exits nonzero when a required or supplied input fails integrity/schema validation or when a numerical self-test fails.

## Interpretation rules

- Treat the `t_K=2/kappa(M_f,chi_f)` arrays as same-event posterior-width diagnostics, not independent likelihood errors.
- Do not identify released effective `kappa_hat` with horizon `kappa` without the trajectory/screening nuisance.
- Do not reuse the network grid as an external prior and then analyze the same H1/L1 strain.
- Do not multiply the seven heavily overlapping start-time windows as independent evidence; keep `-9M/-8M` exploratory and `-7M..-3M` as the supported search regime.
- Do not call `exp(E log BF)` an expected Bayes factor.
- Do not call the synthetic carrier SNR a branch-component SNR.
- Do not use the figure-5 robustness contours quantitatively until the likelihood mixture and posterior weighting are repaired.
- Stop before a physical branch interpretation when no completion is admitted or covariance-complete joint ratio precision is unavailable.
- For a joint fit, evaluate `V_tau=S+tau^2 T-tau(C+C^T)` or equivalent Mahalanobis branch separation; do not compare a marginal posterior width directly with an independent-anchor threshold.

## Files to inspect

1. `GW250114_V70_summary.json`
2. `GW250114_V70_SELF_TEST.json`
3. `GW250114_V70_official_input_validation.csv`
4. `GW250114_V70_kerr_anchor_by_waveform.csv`
5. `GW250114_V70_directwave_evolution.csv`
6. `GW250114_V70_exact_anchor_targets.csv`
7. `GW250114_V70_gate_status.csv`
8. `GW250114_V70_release_code_audit.csv`
