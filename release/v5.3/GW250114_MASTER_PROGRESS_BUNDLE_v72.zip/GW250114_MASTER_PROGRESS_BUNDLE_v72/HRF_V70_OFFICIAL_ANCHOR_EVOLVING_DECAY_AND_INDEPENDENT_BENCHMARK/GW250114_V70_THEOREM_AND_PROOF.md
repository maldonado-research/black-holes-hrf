# GW250114 HRF v70 theorem and proof

## Theorem 1 — Multi-event observable completion

Assume \(\tau\ne0\), a regular product Jacobian, and no unmodeled nuisance parameters in the added observables. For `N` events with shared branch parameter \(\tau\), free event times \(t_j\), and product observables

\[
s_j=\tau t_j,
\]

the product Jacobian has rank \(N\) and the exact null vector

\[
v=(\tau,-t_1,\ldots,-t_N).
\]

For any added observables \(g_a(\tau,t_1,\ldots,t_N)\), define their gauge-direction derivatives

\[
q_a
=
\tau\,\partial_\tau g_a
-
\sum_{j=1}^N t_j\,\partial_{t_j}g_a.
\]

Because the product block has nullity one, the augmented map is locally identifiable if and only if

\[
\boxed{\exists a:\ q_a\ne0.}
\]

For one event, \(q_a\) is the negative of v69’s \(\Delta_g=t\partial_tg-\tau\partial_\tau g\), so the conditions are identical.

### Proof

The rows of the product Jacobian annihilate \(v\). Adding a row \(\nabla g_a\) removes the unique null direction exactly when \(\nabla g_a\cdot v=q_a\ne0\). QED.

Along the exact-product ridge \(t_j=s_j/\tau\),

\[
\left.\frac{d g_a}{d\tau}\right|_{\mathbf s}
=
\frac{q_a}{\tau}.
\]

If \(K\) is the positive-definite conditional covariance of the completion observables after exact product conditioning, its maximum local information is

\[
\mathcal I_{\tau,\mathrm{completion}}
=
\frac{1}{\tau^2}\mathbf q^T K^{-1}\mathbf q,
\]

and the local Cramér–Rao inequality for regular estimators and fixed covariance is

\[
\frac{\mathrm{Var}(\hat\tau)}{\tau^2}
\ge
\frac{1}{\mathbf q^T K^{-1}\mathbf q}.
\]

Local rank is necessary but not sufficient for two discrete branches. The global alias gate also requires

\[
\mathbf g\!\left(\tau_p,\frac{\mathbf s}{\tau_p}\right)
\ne
\mathbf g\!\left(\tau_g,\frac{\mathbf s}{\tau_g}\right).
\]

## Theorem 2 — Exact Gaussian product-plus-anchor evidence

Let

\[
\mathbf y=
\begin{pmatrix}\hat{\mathbf s}\\\hat{\mathbf t}\end{pmatrix},
\qquad
E[\mathbf y\mid\tau,\mathbf t]
=
\begin{pmatrix}\tau\mathbf t\\\mathbf t\end{pmatrix},
\]

with fixed covariance

\[
\Sigma=
\begin{pmatrix}S&C\\C^T&T\end{pmatrix}.
\]

Define

\[
\mathbf r_\tau=\hat{\mathbf s}-\tau\hat{\mathbf t},
\qquad
V_\tau=S+\tau^2T-\tau(C+C^T).
\]

After integrating the event times over \(\mathbb R^N\) with a common flat measure—or over a common positive-time prior whose boundaries are negligible on the likelihood support—

\[
\boxed{
Z(\tau)\propto
|V_\tau|^{-1/2}
\exp\!\left[-\frac12\mathbf r_\tau^T V_\tau^{-1}\mathbf r_\tau\right].
}
\]

### Proof sketch

The residual \(\hat{\mathbf s}-\tau\hat{\mathbf t}\) eliminates the linear nuisance mean \(\mathbf t\). Its covariance is exactly \(V_\tau\). Gaussian integration over the nuisance coordinate supplies the determinant and quadratic form shown above. QED.

The nuisance-profiled Fisher information is

\[
\mathcal I_{\tau,\mathrm{eff}}
=
\mathbf t^T V_\tau^{-1}\mathbf t.
\]

For independent event pairs, define fractional product error \(\alpha_j\), fractional anchor error \(b_j\), and their correlation \(\rho_j\). Then

\[
q_j^2
=
\alpha_j^2+b_j^2-2\rho_j\alpha_j b_j,
\]

and

\[
\boxed{
\frac{\mathrm{Var}(\hat\tau)}{\tau^2}
\ge
\left(\sum_jq_j^{-2}\right)^{-1}.
}
\]

For one independent anchor, \(\sigma_\tau/\tau\ge\sqrt{\alpha^2+b^2}\). Infinite product SNR leaves the hard independent-anchor bound \(\sigma_\tau/\tau\ge b\). A nonzero product–anchor covariance can improve or worsen ratio precision and must be included through \(V_\tau\).

## Corollary 1 — Exact infinite-product anchor distribution

For one exact product and independent Gaussian timescale anchor, let

\[
R=\frac{\tau_p}{\tau_g},
\qquad
\sigma_{\rm rel}=\frac{\sigma_t}{t_p},
\qquad
d=\frac{R-1}{\sigma_{\rm rel}},
\qquad
c=\ln\frac{\tau_g}{\tau_p}.
\]

With a broad flat-`t` ridge prior,

\[
\boxed{
\ell\equiv\ln\mathrm{BF}_{p/g}
\sim
N\!\left(c+\frac{d^2}{2},d^2\right).
}
\]

Therefore

\[
P(\mathrm{BF}>B)
=
\Phi\!\left(
\frac{c+d^2/2-\ln B}{d}
\right).
\]

For GW250114’s old comparator,

\[
\tau_p=1.3862943611198906,
\quad
\tau_g=1.3802695723157803,
\quad
R-1=0.0043649363319673.
\]

Solving the exact expressions gives:

| Requirement | Maximum `sigma_t/t_p` |
|---|---:|
| `exp(E log BF) >= 3` | 0.293887770% |
| `exp(E log BF) >= 10` | 0.203209832% |
| `exp(E log BF) >= 100` | 0.143758919% |
| `P(BF > 1) >= 90%` | 0.170073684% |
| `P(BF > 1) >= 95%` | 0.132578016% |
| `P(BF > 10) >= 90%` | 0.115388961% |

A log-uniform ridge prior cancels the small Jacobian term \(c\). This prior-coordinate dependence must be declared; it is not new data.

## Theorem 3 — Second-delay and harmonic completion

For two delays sharing one physical timescale,

\[
d_1=t\phi_1(\tau),
\qquad
d_2=t\phi_2(\tau),
\]

the Jacobian determinant is

\[
\det\frac{\partial(d_1,d_2)}{\partial(\tau,t)}
=
t\left[\phi_1'(\tau)\phi_2(\tau)-\phi_1(\tau)\phi_2'(\tau)\right].
\]

Thus

\[
\boxed{
\text{local completion}
\iff
\frac{d}{d\tau}\left(\frac{\phi_2}{\phi_1}\right)\ne0.
}
\]

For the two actual discrete branches, the stronger global condition is

\[
\frac{\phi_2(\tau_p)}{\phi_1(\tau_p)}
\ne
\frac{\phi_2(\tau_g)}{\phi_1(\tau_g)}.
\]

Consequently:

- a fixed harmonic or echo order \(n\tau t\) does not complete the rank;
- an irrational but fixed multiple also does not complete it;
- \(d_2=\tau^q t\) completes locally if \(q\ne1\);
- two free event times generally restore underidentifiability unless their relation is constrained;
- unknown phase offsets, cycle aliases, and free amplitude calibrations must be included in the rank test.

## Application to the v70 official candidate

The released segmented grids infer an effective evolving decay rate \(\widehat\kappa\). The authors’ model relates it to horizon \(\kappa\) through

\[
\widehat\kappa
=
\frac{2\beta_{\rm traj}}{1+\beta_{\rm traj}}\kappa.
\]

If \(\beta_{\rm traj}\) is free, the map from \(\widehat\kappa\) to \(\kappa\) and `t_K=2/kappa` is not unique. If the same network strain is reused without a joint likelihood, the candidate also double-counts information. The released cache provides no detector-separated covariance for a cross-fit.

The v70 result is therefore a **conditional rank candidate**, not completed identifiability. Its marginal posterior width fails the standalone independent-Gaussian screen, while covariance-complete joint ratio precision remains unevaluated.
