# HRF v70 — Official anchor, evolving decay, and independent-anchor benchmark gate

**Project:** GW250114 Quantized Horizon Response / branch-control program  
**Version:** v70  
**Date:** 2026-07-11  
**Status:** methods and admission control only; **no detection or discovery claim**.

## Result

v70 executes the official-input task that was blocked in v69. It validates the Nature companion archive, all four official LVK waveform-posterior files, and both 4-kHz and 16-kHz H1/L1 GWOSC strain products. All nine inputs pass fail-closed integrity and schema checks.

The official data do not unlock the physical branch:

- the exact v69 single-delay product gauge remains;
- the project’s Kerr-linked coordinate `t_K=2/kappa(M_f,chi_f)` has posterior `sigma_t/t_ref=1.18–1.56%` across the four waveform families, versus `0.203%` for the old-geometry standalone independent-Gaussian geometric-BF10 screen and `0.170%` for 90% correct sign;
- the equal-family robustness mixture has conventional `sigma/mean=1.548%` (`sigma/t_ref=1.530%`); it is not calibrated model-averaged evidence;
- waveform-family medians span `3.11544–3.17345 ms`, a spread `4.22` times the old neighboring-branch timescale shift;
- the released direct-wave grids constrain an evolving effective damping rate, not horizon `kappa`; they are network-only, use the same strain, and have `8.15–17.88%` relative decay-time widths in the supported `-7M` to `-3M` regime;
- the released cache cannot perform H1-to-L1 or L1-to-H1 cross-fitting.

The outcome is a documented official-input negative gate:

```text
CONDITIONAL_RANK_CANDIDATE_NOT_ADMITTED
JOINT_RATIO_PRECISION_NOT_EVALUATED
PHYSICAL_INTERPRETATION_LOCKED
```

## Read first

1. `GW250114_V70_ONE_PAGE_CERTIFICATE.md`
2. `GW250114_V70_OFFICIAL_ANCHOR_EVOLVING_DECAY_AND_INDEPENDENT_BENCHMARK.md`
3. `GW250114_V70_THEOREM_AND_PROOF.md`
4. `GW250114_V70_gate_status.csv`
5. `GW250114_V70_kerr_anchor_by_waveform.csv`
6. `GW250114_V70_directwave_evolution.csv`
7. `GW250114_V70_v69_correction_register.csv`

## Reproduce

Download the official binaries with `GW250114_V70_FETCH_OFFICIAL_INPUTS.sh`, then run. The seven grids are read directly from the checksum-validated ZIP:

```bash
python gw250114_v70_official_anchor_gate.py \
  --input-dir official_inputs \
  --outdir reproduced_outputs \
  --strict
```

Pinned Python dependencies are in `requirements.txt`. Official binaries are intentionally not included in this package.

## Decision

The official posterior widths are same-event diagnostics, not independent likelihood errors; joint product/anchor covariance remains unavailable. No real `ln(4)`, `g=4`, area-quantization, black-hole microstate, or quantum-horizon inference is admitted. Another Zenodo update is not recommended from this result alone.
