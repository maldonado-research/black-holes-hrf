# Reference-only triage

The attached ToE, HDBLAST, antimatter, and dark-sector chat archives were not used as physical inputs to v70.

v70 imports no cosmological, flavor, dark-sector, FTL, PTA, or cross-project parameter relation. The canonical scientific parent is the supplied v69 HRF/GW250114 bundle. Cross-project materials remain reference-only unless a future task states and tests an explicit black-hole observable consequence.
