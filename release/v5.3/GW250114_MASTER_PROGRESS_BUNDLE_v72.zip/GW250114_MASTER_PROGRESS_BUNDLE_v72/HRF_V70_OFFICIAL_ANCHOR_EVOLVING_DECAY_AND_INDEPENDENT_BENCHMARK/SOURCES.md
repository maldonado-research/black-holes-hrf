# Sources frozen for HRF v70

## Primary public releases

- Lu, Ma, Piccinni, Chen, and Sun, “GW250114 reveals signatures of post-merger black-hole horizon,” *Nature* (2026): https://www.nature.com/articles/s41586-026-10696-0
- Nature data/code companion, Zenodo record 20017347: https://zenodo.org/records/20017347
- Author preprint and supplement, arXiv:2510.01001v3: https://arxiv.org/abs/2510.01001v3
- LVK GW250114 discovery figure/data release, Zenodo record 16877102: https://zenodo.org/records/16877102
- GWOSC discovery-v1 event page: https://gwosc.org/eventapi/html/O4_Discovery_Papers/GW250114_082203/v1/
- GWOSC discovery-v1 event JSON: https://gwosc.org/eventapi/json/O4_Discovery_Papers/GW250114_082203/v1/

## Model firewall reference

- Kankani and McWilliams, “The Direct Wave is Not a Meaningful Test of Horizon Properties,” arXiv:2607.02380v1: https://arxiv.org/abs/2607.02380v1

## Frozen provenance

- Nature ZIP publisher MD5: `4874fef35088209c9fa4073f15a27a78`
- NRSur7dq4 publisher MD5: `9b115931b66439a1d5649a2b7b7aa143`
- PhenomXO4a publisher MD5: `cf690b8ea60c2d0f469bd5f7960119c6`
- PhenomXPHM publisher MD5: `62991eb44428c1f0e4fe9bd173b9f1b6`
- SEOBNRv5PHM publisher MD5: `74ee4e88c189c7f76d2735b7999683fc`
- Embedded `qnm_filter` commit: `55f14436d4ea510b71754b95da9701009e8a1c12`
- GWOSC source lane: `O4_Discovery_Papers/GW250114_082203/v1`

The package includes derived summaries and local reproducibility hashes, not the official binaries.
