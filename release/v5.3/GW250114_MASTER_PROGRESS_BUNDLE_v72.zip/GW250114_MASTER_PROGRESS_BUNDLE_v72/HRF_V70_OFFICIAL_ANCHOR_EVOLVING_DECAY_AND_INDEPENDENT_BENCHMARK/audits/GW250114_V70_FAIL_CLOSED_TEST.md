# GW250114 HRF v70 fail-closed test

The validator was replayed with a corrupt same-name Nature companion file while all other inputs remained valid.

- Corrupt file actual MD5: `cd236dbaf617579d7756bd6d8d650739`
- Required publisher MD5: `4874fef35088209c9fa4073f15a27a78`
- ZIP result: invalid
- Validator status: `FAIL_INTEGRITY_OR_SCHEMA`
- Strict-mode exit code: `2`
- Downstream posterior/direct-wave analysis executed: `False`

This repairs v69’s filename-presence fail-open behavior.

A second replay omitted `posterior_samples_PhenomXO4a.h5`. Because all four waveform families are required for v70’s four-family claim, strict mode again exited `2`, emitted only the validation table and blocked summary, and ran no downstream anchor/grid analysis.
