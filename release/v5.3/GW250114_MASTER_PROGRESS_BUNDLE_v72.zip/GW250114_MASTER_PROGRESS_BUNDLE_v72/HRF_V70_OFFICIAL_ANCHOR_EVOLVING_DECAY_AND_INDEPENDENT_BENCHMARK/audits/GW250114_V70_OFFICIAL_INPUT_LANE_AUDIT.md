# GW250114 v70 official-input lane audit

Date: 2026-07-11  
Scope: read-only inspection of the v69 fetch manifest and public primary-source releases. No canonical v69 file was modified.

## Final-package scope addendum

The final v70 generator tightens this exploratory audit in four ways:

- it reads every analyzed grid member directly from the checksum-validated ZIP;
- it treats `-9M/-8M` as exploratory and uses `-7M..-3M` for the supported width screen;
- it treats remnant-derived `t_K` spreads as same-event posterior-width diagnostics, not independent likelihood errors or universal power ceilings;
- it renames the trajectory variable `beta_traj` and requires detector-specific nuisance inference before calling an H1/L1 split genuinely cross-fitted.

Accordingly, the final status is `CONDITIONAL_RANK_CANDIDATE_NOT_ADMITTED / JOINT_RATIO_PRECISION_NOT_EVALUATED`, not a proof that every possible covariance-complete joint analysis must fail.

## Decision

The public lane is accessible. The four files named by the v69 manifest were retrieved, and v70 expanded the fail-closed intake to all nine inputs: the Nature ZIP, all four LVK posterior files, and both detectors at 4 kHz and 16 kHz. Every publisher-supplied Zenodo MD5 matched, and all four GWOSC products are valid 4096-second HDF5 strain files.

However, the Nature companion analysis is configured around the 16-kHz GWOSC files, not the two 4-kHz files in the v69 manifest. The 16-kHz H1/L1 URLs also work and the retrieved files validate as HDF5. A v70 reproduction intake should therefore include both 16-kHz files as required inputs; keep 4 kHz as the resampling/operator check.

The companion archive does expose seven segmented frequency/damping **network log-likelihood grids**, but not detector-separated or draw-level segmented posterior samples. These grids can reproduce the paper's two-dimensional contours under the stated uniform priors. They do not, by themselves, provide a defensible nonproduct measurement of the HRF nuisance timescale `t_DW=2/kappa`.

## Verified public files

The Zenodo MD5 values below are publisher-supplied and matched locally. GWOSC does not publish a checksum in its event JSON or HTTP headers; its MD5/SHA-256 values below are local reproducibility hashes for the exact retrieved bytes.

| File | Bytes | MD5 | SHA-256 | Result |
|---|---:|---|---|---|
| `GW250114_horizon_signatures.zip` | 53,049,832 | `4874fef35088209c9fa4073f15a27a78` | `752eb33b21ee1a332ad7282eb5ddee695d6cc1ec2859120c779e17fbfcd7c862` | official MD5 match; ZIP test passes |
| `posterior_samples_NRSur7dq4.h5` | 26,958,665 | `9b115931b66439a1d5649a2b7b7aa143` | `55b4a47c2c71580e9ef0cd1ff9fa9d32e64813657e9ea31f32e24cda53922d62` | official MD5 match; HDF5 opens |
| `posterior_samples_PhenomXO4a.h5` | 26,797,216 | `cf690b8ea60c2d0f469bd5f7960119c6` | `dc35655ff0cecc932b9c95e7e675bc9a43a31e2ac5dbb57f07b6a59f0efa92e7` | official MD5 match; HDF5 opens |
| `posterior_samples_PhenomXPHM.h5` | 26,799,792 | `62991eb44428c1f0e4fe9bd173b9f1b6` | `cb1b40416360587b12e52cd2a0e99bf9b9c38917db8f0fece08a0d47c8f04585` | official MD5 match; HDF5 opens |
| `posterior_samples_SEOBNRv5PHM.h5` | 26,798,088 | `74ee4e88c189c7f76d2735b7999683fc` | `c7da6eb05f255bf7af3c4c03b3bce1af9d755e6b7e955f6c9d438f086b3ec125` | official MD5 match; HDF5 opens |
| H1 4 kHz HDF5 | 40,961,487 | `f0f6c16c419282a26fa7a57810f715ac` | `db0b394ff10573f0e86b484adc59f176307c53fdc5f5ba5109a898f712674889` | local hash; HDF5 opens |
| L1 4 kHz HDF5 | 40,678,340 | `bea4dcf16e5dd9d64e425d66f97d5cc6` | `d95a6ebf274800f48fd966caf9198d6e2f91928d50d339c0c592defee06e82c1` | local hash; HDF5 opens |
| H1 16 kHz HDF5 | 162,063,585 | `e5816e8bf0284065c6732f27079ca74a` | `23e20dda953d2ede852f4991c018b0f1128f35f2cec7153d835a312be363d19d` | local hash; HDF5 opens |
| L1 16 kHz HDF5 | 160,795,119 | `96ebfa3f9b1f0ca54aba1c04f5a85ac8` | `355dbcaece2b63b5ded9aa353e34b59a672edfd7845b0aa1b9bf73c5439bb825` | local hash; HDF5 opens |

Each 4-kHz file contains `strain/Strain` with 16,777,216 float64 samples and spacing 1/4096 s. Each 16-kHz file contains 67,108,864 samples and spacing 1/16384 s. All report GPS start 1420877824 and duration 4096 s.

One initial parallel H1 transfer was truncated and failed the HDF5 stored-EOF check; a clean sequential retry produced the verified bytes above. v70 should require expected byte length plus an HDF5-open/shape check after download, not just successful HTTP status.

## Exact public routes

- Nature companion archive: `https://zenodo.org/api/records/20017347/files/GW250114_horizon_signatures.zip/content`
- NRSur7dq4 posterior: `https://zenodo.org/api/records/16877102/files/posterior_samples_NRSur7dq4.h5/content`
- GWOSC event JSON: `https://gwosc.org/eventapi/json/O4_Discovery_Papers/GW250114_082203/v1/`
- H1/L1 4-kHz and 16-kHz URLs are exactly those listed in that JSON. The v69 URLs are valid.

The current GWOSC portal exposes two entries for this event: `O4_Discovery_Papers` v1 and `GWTC-5.0` v2. The Nature companion code and Zenodo 16877102 posterior are tied to the discovery-era v1 analysis. v70 should pin that lane and must not silently substitute GWTC-5.0 v2 parameter products; a v2 comparison, if desired, belongs in a separately labeled systematics lane.

## Companion archive contents relevant to v70

The ZIP has 199 extracted files (247 ZIP entries including directories). Its embedded `qnm_filter` source resolves to commit `55f14436d4ea510b71754b95da9701009e8a1c12`.

Key products are:

- `fig_4/data/late_times/DW_ftau_{-9,...,-3}M.h5`: seven 85 x 40 network log-likelihood grids.
- Each grid spans frequency 160--238 Hz in 2-Hz steps and damping rate 50--890 s^-1 in 10-s^-1 steps; the paper states uniform priors over 160--240 Hz and 0.05--0.9 ms^-1.
- Each HDF5 stores `likelihood_data` plus `time`, joint-credible threshold, grid bounds/resolution, QNM filter model, and one NRSur maximum-likelihood point. It does not store detector-specific surfaces, posterior draws, per-draw remnant/QNM nuisance values, or cross-window covariance.
- `fig_5/likelihood_*.npy`: five cached -7M robustness surfaces (baseline, 0.5-s segment, 16-kHz analysis, sky timing, and remnant variation).
- `fig_2_6/data/samples.npy`: 160,000 x 3 samples for `(A_x,A_y,delta t)` only. There is no sampled frequency, damping rate, surface gravity, or `t_DW` coordinate.
- `fig_2_6/data/sample_SNRs.npy`: 160,000 x 4 per-sample H1/L1 optimal and matched-filter SNR values.
- `fig_3_10_11/omegaG.mat`, `phase.mat`, and `time.dat`: a deterministic analytic direct-wave trajectory for a fixed remnant choice, not a posterior over that trajectory.
- `open_data/` is empty. The scripts download strain and the PE posterior at first run.

The scripts expect the posterior at local path `../open_data/content` and expect 16-kHz strain under local filenames containing `O4b3Disc_16KHZ_R1`. Merely placing the v69-standard filenames in `official_inputs/` will not make the Nature scripts consume them. A v70 staging wrapper should pass explicit `posterior_file` and `strain_files` paths or create an isolated adapter layout.

## Normalized released segmented likelihoods

Normalizing each cached grid with its stated uniform frequency/damping-rate prior gives the following marginal summaries. These are derived diagnostics from released cache products, not additional independent measurements.

| Start | MAP `(f, rate)` | Median decay time | Central 90% decay-time interval |
|---:|---|---:|---:|
| -9 M | (210 Hz, 400 s^-1) | 2.500 ms | 2.222--2.778 ms |
| -8 M | (200 Hz, 420 s^-1) | 2.381 ms | 2.128--2.632 ms |
| -7 M | (200 Hz, 450 s^-1) | 2.222 ms | 1.923--2.500 ms |
| -6 M | (198 Hz, 490 s^-1) | 2.000 ms | 1.695--2.381 ms |
| -5 M | (200 Hz, 540 s^-1) | 1.786 ms | 1.389--2.273 ms |
| -4 M | (190 Hz, 490 s^-1) | 1.961 ms | 1.471--2.564 ms |
| -3 M | (204 Hz, 510 s^-1) | 1.852 ms | 1.370--2.500 ms |

At -7M the damping-rate marginal is 450 s^-1 with a central 90% interval of 400--520 s^-1. Even a Gaussianized interpretation is at the several-percent one-sigma level, versus the approximately 0.203% relative `t_DW` precision target for the old-geometry BF >= 10 in v69. The time windows are also almost completely overlapping: adjacent starts differ by about one remnant mass, roughly 0.335 ms, while each segment is 0.2 s. The seven grids must not be multiplied as independent evidence.

## Exact NRSur posterior propagation

The official NRSur file has one PE group, `bilby-NRSur7dq4_prod-reweighted`. Its structured `posterior_samples` dataset has 19,990 rows and 135 fields, including draw-level final mass/spin, sky/timing, calibration, likelihood/prior, and detector quantities. It also carries H1/L1 PSD and calibration-envelope data. It contains no direct-wave parameters.

Treating the published posterior rows as equal-weight posterior draws and propagating the project's diagnostic Kerr mapping

`kappa = sqrt(1-chi^2) / [2 M (1+sqrt(1-chi^2))]`, `t_DW = 2/kappa`,

gives:

- correlation `corr(M_f^det, chi_f) = 0.929145`;
- `t_DW` median `3.161007 ms`;
- 16--84% interval `3.124854--3.198303 ms`;
- 5--95% interval `3.095530--3.220771 ms`;
- standard deviation `0.037640 ms`, or `1.19101%` of the posterior mean and `1.18224%` of the frozen old-branch reference time;
- exact native 9-sample/ln(4) alignment `3.169984221 ms` is at the 59.73rd percentile;
- the companion code's MAP remnant `(67.927991 M_sun, 0.672509229)` maps to `t_DW=3.146632 ms`.

The full draw covariance therefore gives a `sigma_t/T_ref` width of `1.18224%`, which is `5.8178` times the `0.203210%` independent-Gaussian geometric-BF10 benchmark. This is a same-event Kerr-model posterior-width diagnostic, not an independent likelihood error, a direct measurement of `t_DW`, or a universal ceiling on covariance-complete joint inference.

## Why the segmented release is not yet the required nonproduct anchor

1. **It measures a different quantity.** The grids infer a window-averaged effective damping rate of a constant damped sinusoid. The authors' Supplement Eq. S21b gives `kappa_hat(t)=2 beta/(1+beta) * kappa`. Recovering horizon `kappa`, and hence `t_DW=2/kappa`, requires a trajectory/radial-velocity and screening model. With that nuisance free, the grid is not a direct `t_DW` observation.
2. **It uses the same strain.** Treating a network grid as an external prior and then reusing H1/L1 for the branch likelihood double-counts data. The valid routes are one joint likelihood or a genuinely detector-cross-fitted construction.
3. **The cached surfaces are network-only.** The paper combines H1 and L1 incoherently. There are no H1-only or L1-only grids, so the cache cannot implement H1-anchor/L1-branch and swapped cross-fits.
4. **No joint nuisance covariance is released.** The grids are not joint with remnant mass/spin, QNM subtraction, analytic-template amplitude/time shift, calibration, or the HRF branch coordinate.
5. **The measured scale is far too broad.** The -7M effective damping posterior is at the order-ten-percent 90% level, while v69 needs sub-percent and often sub-0.1-percent scale resolution.
6. **The model is explicitly approximate and evolving.** The paper calls each result an average over a 0.2-s window and says more accurate evolving templates are needed for high-precision analysis.

Conclusion: the archive provides a useful observable-completion **candidate and replay target**, not a completed independent anchor. Final status is `CONDITIONAL_RANK_CANDIDATE_NOT_ADMITTED / JOINT_RATIO_PRECISION_NOT_EVALUATED`.

## Code-level audit blockers before quantitative reuse

- In `fig_5/checking_analysis.py`, the purported sky/remnant marginalization averages log-likelihood arrays arithmetically (`sum(logL_i/N)`). A likelihood mixture requires `logsumexp(logL_i) - log N` (with appropriate weights). The released operation is a geometric-mean likelihood, not Bayesian marginalization.
- The same script samples the already published `posterior_samples` rows with probabilities proportional to `exp(log_likelihood+log_prior)`. The file contains no residual weight field and is presented as posterior samples. This extra weighting has effective sample size about 28.7 out of 19,990 and appears to double-weight the posterior unless the release documents otherwise.
- No random seed is set for the 200-draw robustness loops.
- The 160,000 direct-wave MCMC rows equal 32 walkers x 5,000 steps, and the release code flattens the full chain without a burn-in discard or convergence diagnostic. These samples do not constrain frequency/damping in any case.

The baseline seven `fig_4` grids are not invalidated by the `fig_5` marginalization issue, but the red/purple robustness contours should be independently recomputed before they enter a v70 gate.

## Recommended v70 intake

1. Freeze Zenodo record IDs, file byte lengths, publisher MD5 values, local SHA-256 values, the GWOSC event JSON, and qnm_filter commit.
2. Require the two 16-kHz files for the Nature replay; retain 4 kHz only as the preregistered numerical-operator check.
3. Add HDF5-open, dataset-shape, GPS-start, duration, and sample-spacing validation to the fetch gate.
4. First replay the cached network contours exactly under their stated uniform priors.
5. Correct and replay the sky/remnant marginalization before using those contours.
6. Build detector-separated likelihoods from raw 16-kHz strain; do not multiply overlapping start-time windows.
7. Treat effective `kappa_hat(t)`, horizon `kappa`, trajectory parameters, QNM subtraction, and HRF `(tau,t_DW)` jointly. Carry Kerr-linked, free/evolving-transient, and standard-GR lanes.
8. Require an explicit nonzero observable-completion determinant and compare the recovered `t_DW` precision with the v69 targets before any branch evidence is computed.
9. If a defensible joint/cross-fit cannot be built, record the official-data outcome as a negative observable-completion result.

## Primary public sources

- Nature article and data/code statement: https://www.nature.com/articles/s41586-026-10696-0
- Nature companion record: https://zenodo.org/records/20017347
- LVK discovery release: https://zenodo.org/records/16877102
- GWOSC discovery event page: https://gwosc.org/eventapi/html/O4_Discovery_Papers/GW250114_082203/v1/
- GWOSC event JSON: https://gwosc.org/eventapi/json/O4_Discovery_Papers/GW250114_082203/v1/
- Author preprint: https://arxiv.org/abs/2510.01001
