# GW250114 HRF v70 reproducibility audit

Audit replay: `2026-07-11`, after the final independent-anchor benchmark relabeling.

- Independent full generator runs: `2`
- Generated files per run: `16`
- Same filename set: `True`
- Run-to-run bit-for-bit identity: `True`
- Included generated outputs equal replay outputs: `True`
- Differences: `[]`
- Final benchmark output: `GW250114_V70_anchor_independent_benchmark.csv`

Both runs used the same nine identity/checksum/schema-validated official inputs, read the seven grids directly from the validated Nature ZIP, and used the pinned runtime with `SOURCE_DATE_EPOCH=1783785600`.

The official binaries are not part of the package. Their frozen hashes and structural checks are recorded in `GW250114_V70_official_input_validation.csv`.
