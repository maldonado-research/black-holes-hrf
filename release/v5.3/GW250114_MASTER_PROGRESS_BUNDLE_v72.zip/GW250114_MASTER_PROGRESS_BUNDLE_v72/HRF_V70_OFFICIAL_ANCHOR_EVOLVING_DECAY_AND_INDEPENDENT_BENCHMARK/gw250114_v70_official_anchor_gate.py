#!/usr/bin/env python3
"""GW250114 HRF v70 official-anchor and evolving-decay gate.

This is a methods/admission-control analysis.  It does not claim a detection,
area quantization, a quantum horizon, or a failure of general relativity.

The script does four things:

1. validates the official Nature companion archive, LVK posterior files, and
   GWOSC H1/L1 strain files with fail-closed checksum/schema checks;
2. propagates the full final-mass/final-spin covariance through the project's
   Kerr-linked convention t_K=2/kappa for all four official waveform families;
3. audits the cached, network-only direct-wave frequency/damping grids without
   treating their effective damping rate as an independent horizon anchor; and
4. emits exact independent-Gaussian anchor benchmarks and a v69 semantic-correction
   register.

Official binaries are read in place and are not copied into the output.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import math
import re
import zipfile
from pathlib import Path
from typing import Any, Iterable

import h5py
import matplotlib.pyplot as plt
import numpy as np


VERSION = "GW250114_HRF_v70"
DATE = "2026-07-11"
STATUS = "METHODS_ONLY_NO_DETECTION"

LN4 = float(math.log(4.0))
FS_NATIVE_HZ = 4096.0
GRID_INDEX = 9.0
T_REF_S = 0.003183821
TAU_GRID_OLD = 2.0 * GRID_INDEX / (FS_NATIVE_HZ * T_REF_S)
TAU_GAP = LN4 - TAU_GRID_OLD
T_ALIGN_S = 2.0 * GRID_INDEX / (FS_NATIVE_HZ * LN4)
T_GRID_FOR_OLD_PRODUCT_S = T_REF_S * LN4 / TAU_GRID_OLD
T_SHIFT_REL = T_GRID_FOR_OLD_PRODUCT_S / T_REF_S - 1.0
MTSUN_S = 4.9254909476412675e-6

def compute_anchor_targets() -> dict[str, float]:
    """Exact-product, independent-Gaussian anchor targets."""
    delta = LN4 / TAU_GRID_OLD - 1.0
    c = math.log(TAU_GRID_OLD / LN4)

    def geometric_bf(target: float) -> float:
        d = math.sqrt(2.0 * (math.log(target) - c))
        return delta / d

    def probability_threshold(bf: float, z: float) -> float:
        d = z + math.sqrt(z * z - 2.0 * (c - math.log(bf)))
        return delta / d

    return {
        "geometric_mean_bf3": geometric_bf(3.0),
        "geometric_mean_bf10": geometric_bf(10.0),
        "geometric_mean_bf100": geometric_bf(100.0),
        "p_bf_gt_1_90pct": probability_threshold(1.0, 1.2815515655446004),
        "p_bf_gt_1_95pct": probability_threshold(1.0, 1.6448536269514722),
        "p_bf_gt_10_90pct": probability_threshold(10.0, 1.2815515655446004),
    }


ANCHOR_TARGETS = compute_anchor_targets()

POSTERIOR_MD5 = {
    "posterior_samples_NRSur7dq4.h5": "9b115931b66439a1d5649a2b7b7aa143",
    "posterior_samples_PhenomXO4a.h5": "cf690b8ea60c2d0f469bd5f7960119c6",
    "posterior_samples_PhenomXPHM.h5": "62991eb44428c1f0e4fe9bd173b9f1b6",
    "posterior_samples_SEOBNRv5PHM.h5": "74ee4e88c189c7f76d2735b7999683fc",
}

POSTERIOR_SIZE = {
    "posterior_samples_NRSur7dq4.h5": 26_958_665,
    "posterior_samples_PhenomXO4a.h5": 26_797_216,
    "posterior_samples_PhenomXPHM.h5": 26_799_792,
    "posterior_samples_SEOBNRv5PHM.h5": 26_798_088,
}

FAMILY_LABEL = {
    "posterior_samples_NRSur7dq4.h5": "NRSur7dq4",
    "posterior_samples_PhenomXO4a.h5": "PhenomXO4a",
    "posterior_samples_PhenomXPHM.h5": "PhenomXPHM",
    "posterior_samples_SEOBNRv5PHM.h5": "SEOBNRv5PHM",
}

HORIZON_ARCHIVE = "GW250114_horizon_signatures.zip"
HORIZON_MD5 = "4874fef35088209c9fa4073f15a27a78"
HORIZON_SIZE = 53_049_832
H1_STRAIN = "H-H1_GWOSC_O4b_4KHZ_R1-1420877824-4096.hdf5"
L1_STRAIN = "L-L1_GWOSC_O4b_4KHZ_R1-1420877824-4096.hdf5"
H1_STRAIN_16K = "H-H1_GWOSC_O4b_16KHZ_R1-1420877824-4096.hdf5"
L1_STRAIN_16K = "L-L1_GWOSC_O4b_16KHZ_R1-1420877824-4096.hdf5"
STRAIN_SPEC = {
    H1_STRAIN: {
        "detector": "H1", "size": 40_961_487, "sample_rate": 4096.0,
        "points": 16_777_216, "role": "v69 native-grid/operator check",
        "sha256": "db0b394ff10573f0e86b484adc59f176307c53fdc5f5ba5109a898f712674889",
    },
    L1_STRAIN: {
        "detector": "L1", "size": 40_678_340, "sample_rate": 4096.0,
        "points": 16_777_216, "role": "v69 native-grid/operator check",
        "sha256": "d95a6ebf274800f48fd966caf9198d6e2f91928d50d339c0c592defee06e82c1",
    },
    H1_STRAIN_16K: {
        "detector": "H1", "size": 162_063_585, "sample_rate": 16_384.0,
        "points": 67_108_864, "role": "required for exact Nature companion replay",
        "sha256": "23e20dda953d2ede852f4991c018b0f1128f35f2cec7153d835a312be363d19d",
    },
    L1_STRAIN_16K: {
        "detector": "L1", "size": 160_795_119, "sample_rate": 16_384.0,
        "points": 67_108_864, "role": "required for exact Nature companion replay",
        "sha256": "355dbcaece2b63b5ded9aa353e34b59a672edfd7845b0aa1b9bf73c5439bb825",
    },
}


def file_hash(path: Path, algorithm: str) -> str:
    h = hashlib.new(algorithm)
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        path.write_text("")
        return
    fields: list[str] = []
    for row in rows:
        for key in row:
            if key not in fields:
                fields.append(key)
    with path.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def weighted_quantile(values: np.ndarray, weights: np.ndarray,
                      probs: Iterable[float]) -> np.ndarray:
    values = np.asarray(values, dtype=float)
    weights = np.asarray(weights, dtype=float)
    order = np.argsort(values)
    x = values[order]
    w = weights[order]
    total = float(np.sum(w))
    if not np.isfinite(total) or total <= 0:
        raise ValueError("invalid weights")
    w = w / total
    # Use probability mass at grid-cell centers.  The usual right-edge CDF
    # creates a full-bin bias for the coarse released damping-rate grid and is
    # not invariant under a monotone decreasing transformation such as 1/rate.
    cdf = np.cumsum(w) - 0.5 * w
    return np.interp(np.asarray(list(probs), dtype=float), cdf, x,
                     left=x[0], right=x[-1])


def stable_weights(log_values: np.ndarray) -> np.ndarray:
    log_values = np.asarray(log_values, dtype=float)
    shifted = log_values - np.nanmax(log_values)
    weights = np.exp(shifted)
    weights /= np.sum(weights)
    return weights


def discrete_weighted_quantile(values: np.ndarray, weights: np.ndarray,
                               probs: Iterable[float]) -> np.ndarray:
    """Right-continuous quantiles on the released finite grid."""
    values = np.asarray(values, dtype=float)
    weights = np.asarray(weights, dtype=float)
    order = np.argsort(values)
    x = values[order]
    w = weights[order]
    cdf = np.cumsum(w) / np.sum(w)
    indices = np.searchsorted(cdf, np.asarray(list(probs), dtype=float), side="left")
    return x[np.clip(indices, 0, len(x) - 1)]


def validate_horizon_archive(path: Path) -> dict[str, Any]:
    row: dict[str, Any] = {
        "input_class": "direct_wave_companion",
        "filename": HORIZON_ARCHIVE,
        "required_for_core_gate": True,
        "present": path.is_file(),
        "expected_size_bytes": HORIZON_SIZE,
        "expected_md5": HORIZON_MD5,
    }
    if not path.is_file():
        row.update(status="FAIL_MISSING", schema_ok=False, checksum_ok=False)
        return row
    row["actual_size_bytes"] = path.stat().st_size
    row["actual_md5"] = file_hash(path, "md5")
    row["sha256"] = file_hash(path, "sha256")
    row["checksum_ok"] = row["actual_md5"] == HORIZON_MD5
    row["size_ok"] = row["actual_size_bytes"] == HORIZON_SIZE
    mandatory = {
        "GW250114_horizon_signatures/README.md",
        "GW250114_horizon_signatures/fig_2_6/data/samples.npy",
        "GW250114_horizon_signatures/fig_2_6/data/samples_log_prob.npy",
        "GW250114_horizon_signatures/fig_2_6/data/sample_SNRs.npy",
        *{
            f"GW250114_horizon_signatures/fig_4/data/late_times/DW_ftau_{x:.1f}M.h5"
            for x in range(-9, -2)
        },
    }
    try:
        with zipfile.ZipFile(path) as archive:
            names = set(archive.namelist())
            row["zip_member_count"] = len(names)
            row["zip_crc_ok"] = archive.testzip() is None
            row["mandatory_members_present"] = mandatory.issubset(names)
            row["schema_ok"] = bool(row["zip_crc_ok"] and row["mandatory_members_present"])
    except Exception as exc:  # fail closed
        row["zip_error"] = f"{type(exc).__name__}: {exc}"
        row["schema_ok"] = False
    passed = bool(row.get("checksum_ok") and row.get("size_ok") and row.get("schema_ok"))
    row["status"] = "PASS" if passed else "FAIL_INTEGRITY_OR_SCHEMA"
    return row


def posterior_dataset(file: h5py.File) -> tuple[str, h5py.Dataset]:
    candidates: list[tuple[str, h5py.Dataset]] = []
    for root_name in file.keys():
        root = file[root_name]
        if isinstance(root, h5py.Group) and "posterior_samples" in root:
            item = root["posterior_samples"]
            if isinstance(item, h5py.Dataset):
                candidates.append((f"{root_name}/posterior_samples", item))
    if len(candidates) != 1:
        raise ValueError(f"expected one posterior_samples dataset; found {len(candidates)}")
    return candidates[0]


def validate_posterior(path: Path, required: bool) -> dict[str, Any]:
    expected = POSTERIOR_MD5[path.name]
    row: dict[str, Any] = {
        "input_class": "waveform_posterior",
        "filename": path.name,
        "waveform_family": FAMILY_LABEL[path.name],
        "required_for_core_gate": required,
        "present": path.is_file(),
        "expected_md5": expected,
        "expected_size_bytes": POSTERIOR_SIZE[path.name],
    }
    if not path.is_file():
        row.update(status="FAIL_MISSING", checksum_ok=False, schema_ok=False)
        return row
    row["actual_size_bytes"] = path.stat().st_size
    row["size_ok"] = row["actual_size_bytes"] == POSTERIOR_SIZE[path.name]
    row["actual_md5"] = file_hash(path, "md5")
    row["sha256"] = file_hash(path, "sha256")
    row["checksum_ok"] = row["actual_md5"] == expected
    try:
        with h5py.File(path, "r") as file:
            dataset_path, dataset = posterior_dataset(file)
            fields = set(dataset.dtype.names or ())
            row["dataset_path"] = dataset_path
            row["posterior_draws"] = int(dataset.shape[0])
            row["has_final_mass"] = "final_mass" in fields
            row["has_final_spin"] = "final_spin" in fields
            row["schema_ok"] = bool(
                dataset.ndim == 1
                and dataset.shape[0] >= 1000
                and row["has_final_mass"]
                and row["has_final_spin"]
            )
    except Exception as exc:
        row["hdf5_error"] = f"{type(exc).__name__}: {exc}"
        row["schema_ok"] = False
    passed = bool(row.get("checksum_ok") and row.get("size_ok") and row.get("schema_ok"))
    row["status"] = "PASS" if passed else "FAIL_INTEGRITY_OR_SCHEMA"
    return row


def decode_scalar(value: Any) -> str:
    if isinstance(value, bytes):
        return value.decode(errors="replace")
    if isinstance(value, np.ndarray) and value.shape == ():
        return decode_scalar(value.item())
    return str(value)


def validate_strain(path: Path, spec: dict[str, Any]) -> dict[str, Any]:
    detector = str(spec["detector"])
    sample_rate = float(spec["sample_rate"])
    points = int(spec["points"])
    row: dict[str, Any] = {
        "input_class": "gwosc_strain",
        "filename": path.name,
        "detector": detector,
        "required_for_core_gate": True,
        "analysis_role": spec["role"],
        "present": path.is_file(),
        "expected_size_bytes": int(spec["size"]),
        "expected_sha256": str(spec["sha256"]),
        "expected_sample_rate_hz": sample_rate,
    }
    if not path.is_file():
        row.update(status="FAIL_MISSING", schema_ok=False, checksum_ok=None)
        return row
    row["actual_size_bytes"] = path.stat().st_size
    row["size_ok"] = row["actual_size_bytes"] == int(spec["size"])
    row["sha256"] = file_hash(path, "sha256")
    row["checksum_ok"] = row["sha256"] == str(spec["sha256"])
    try:
        with h5py.File(path, "r") as file:
            dataset = file["strain/Strain"]
            detector_value = decode_scalar(file["meta/Detector"][()])
            meta_duration = int(file["meta/Duration"][()])
            meta_gps_start = int(file["meta/GPSstart"][()])
            spacing = float(dataset.attrs["Xspacing"])
            start = int(dataset.attrs["Xstart"])
            row.update(
                detector_metadata=detector_value,
                strain_points=int(dataset.shape[0]),
                sample_spacing_s=spacing,
                sample_rate_hz=1.0 / spacing,
                gps_start=start,
                meta_duration_s=meta_duration,
                meta_gps_start=meta_gps_start,
            )
            row["schema_ok"] = bool(
                dataset.shape == (points,)
                and abs(spacing - 1.0 / sample_rate) < 1e-15
                and start == 1_420_877_824
                and meta_gps_start == 1_420_877_824
                and meta_duration == 4096
                and detector in detector_value
            )
    except Exception as exc:
        row["hdf5_error"] = f"{type(exc).__name__}: {exc}"
        row["schema_ok"] = False
    passed = bool(row.get("checksum_ok") and row.get("size_ok") and row.get("schema_ok"))
    row["status"] = "PASS" if passed else "FAIL_INTEGRITY_OR_SCHEMA"
    return row


def validate_inputs(input_dir: Path) -> list[dict[str, Any]]:
    rows = [validate_horizon_archive(input_dir / HORIZON_ARCHIVE)]
    for name in POSTERIOR_MD5:
        rows.append(validate_posterior(
            input_dir / name,
            required=True,
        ))
    for filename, spec in STRAIN_SPEC.items():
        rows.append(validate_strain(input_dir / filename, spec))
    return rows


def kerr_project_timescale(final_mass: np.ndarray, final_spin: np.ndarray) -> np.ndarray:
    """Project convention t_K=2/kappa using detector-frame final mass."""
    mass = np.asarray(final_mass, dtype=float)
    spin = np.asarray(final_spin, dtype=float)
    root = np.sqrt(np.maximum(1.0 - spin * spin, 0.0))
    if np.any(root <= 0.0):
        raise ValueError("non-subextremal final spin required")
    return 4.0 * mass * MTSUN_S * (1.0 + root) / root


def posterior_anchor_summary(input_dir: Path) -> tuple[list[dict[str, Any]], dict[str, np.ndarray]]:
    rows: list[dict[str, Any]] = []
    arrays: dict[str, np.ndarray] = {}
    for name in POSTERIOR_MD5:
        path = input_dir / name
        with h5py.File(path, "r") as file:
            _, dataset = posterior_dataset(file)
            draws = dataset[:]
        mass = np.asarray(draws["final_mass"], dtype=float)
        spin = np.asarray(draws["final_spin"], dtype=float)
        t_k = kerr_project_timescale(mass, spin)
        tau_9 = 2.0 * GRID_INDEX / (FS_NATIVE_HZ * t_k)
        family = FAMILY_LABEL[name]
        arrays[family] = t_k
        tq = np.quantile(t_k, [0.05, 0.16, 0.50, 0.84, 0.95])
        qq = np.quantile(tau_9, [0.05, 0.50, 0.95])
        sigma_t = float(np.std(t_k, ddof=1))
        rel = sigma_t / float(np.mean(t_k))
        sigma_over_t_ref = sigma_t / T_REF_S
        rows.append({
            "waveform_family": family,
            "n_draws": len(t_k),
            "mass_median_msun_detector_frame": float(np.median(mass)),
            "spin_median": float(np.median(spin)),
            "mass_spin_correlation": float(np.corrcoef(mass, spin)[0, 1]),
            "t_k_mean_ms": float(np.mean(t_k) * 1e3),
            "t_k_std_ms": float(np.std(t_k, ddof=1) * 1e3),
            "t_k_relative_std": rel,
            "t_k_relative_std_percent": 100.0 * rel,
            "t_k_sigma_over_old_physical_t_ref": sigma_over_t_ref,
            "t_k_sigma_over_old_physical_t_ref_percent": 100.0 * sigma_over_t_ref,
            "t_k_q05_ms": float(tq[0] * 1e3),
            "t_k_q16_ms": float(tq[1] * 1e3),
            "t_k_median_ms": float(tq[2] * 1e3),
            "t_k_q84_ms": float(tq[3] * 1e3),
            "t_k_q95_ms": float(tq[4] * 1e3),
            "exact_9sample_alignment_t_ms": T_ALIGN_S * 1e3,
            "alignment_percentile": float(np.mean(t_k <= T_ALIGN_S)),
            "tau_9_q05": float(qq[0]),
            "tau_9_median": float(qq[1]),
            "tau_9_q95": float(qq[2]),
            "p_abs_tau_9_minus_ln4_lt_0p001": float(np.mean(np.abs(tau_9 - LN4) < 0.001)),
            "p_abs_tau_9_minus_ln4_lt_old_gap": float(np.mean(np.abs(tau_9 - LN4) < abs(TAU_GAP))),
            "independent_gaussian_width_screen_over_geometric_bf10_target": sigma_over_t_ref / ANCHOR_TARGETS["geometric_mean_bf10"],
            "independent_gaussian_width_screen_over_90pct_sign_target": sigma_over_t_ref / ANCHOR_TARGETS["p_bf_gt_1_90pct"],
            "independent_gaussian_width_screen_geometric_bf10": "FAIL_AS_STANDALONE_INDEPENDENT_ANCHOR" if sigma_over_t_ref > ANCHOR_TARGETS["geometric_mean_bf10"] else "PASS",
            "independent_gaussian_width_screen_90pct_sign": "FAIL_AS_STANDALONE_INDEPENDENT_ANCHOR" if sigma_over_t_ref > ANCHOR_TARGETS["p_bf_gt_1_90pct"] else "PASS",
            "joint_ratio_precision": "NOT_EVALUATED_MISSING_PRODUCT_ANCHOR_COVARIANCE",
            "interpretation": "same-event posterior-width diagnostic; not an independent likelihood standard deviation or direct-wave measurement",
        })
    return rows, arrays


def mixture_summary(arrays: dict[str, np.ndarray]) -> dict[str, Any]:
    values = np.concatenate(list(arrays.values()))
    weights = np.concatenate([
        np.full(len(x), 1.0 / (len(arrays) * len(x)), dtype=float)
        for x in arrays.values()
    ])
    q = weighted_quantile(values, weights, [0.05, 0.16, 0.50, 0.84, 0.95])
    mean = float(np.sum(values * weights))
    var = float(np.sum(weights * (values - mean) ** 2))
    medians = {name: float(np.median(x)) for name, x in arrays.items()}
    spread = max(medians.values()) - min(medians.values())
    sigma = math.sqrt(var)
    rel = sigma / mean
    sigma_over_t_ref = sigma / T_REF_S
    return {
        "mixture_rule": "equal waveform-family weight; posterior draws equal within family",
        "n_families": len(arrays),
        "n_total_draws": int(sum(len(x) for x in arrays.values())),
        "t_k_mean_ms": mean * 1e3,
        "t_k_std_ms": math.sqrt(var) * 1e3,
        "t_k_relative_std": rel,
        "t_k_relative_std_percent": 100.0 * rel,
        "t_k_sigma_over_old_physical_t_ref": sigma_over_t_ref,
        "t_k_sigma_over_old_physical_t_ref_percent": 100.0 * sigma_over_t_ref,
        "t_k_q05_ms": float(q[0] * 1e3),
        "t_k_q16_ms": float(q[1] * 1e3),
        "t_k_median_ms": float(q[2] * 1e3),
        "t_k_q84_ms": float(q[3] * 1e3),
        "t_k_q95_ms": float(q[4] * 1e3),
        "family_median_min_ms": min(medians.values()) * 1e3,
        "family_median_max_ms": max(medians.values()) * 1e3,
        "family_median_spread_ms": spread * 1e3,
        "family_median_spread_percent_of_mean": 100.0 * spread / mean,
        "family_median_spread_over_old_branch_shift": (spread / mean) / T_SHIFT_REL,
        "family_shift_sensitivity_status": "SENSITIVITY_FAIL_UNDER_V70_SHIFT_TOLERANCE",
        "independent_gaussian_width_screen_over_geometric_bf10_target": sigma_over_t_ref / ANCHOR_TARGETS["geometric_mean_bf10"],
        "independent_gaussian_width_screen_over_90pct_sign_target": sigma_over_t_ref / ANCHOR_TARGETS["p_bf_gt_1_90pct"],
        "standalone_independent_anchor_status": "FAIL_AS_STANDALONE_INDEPENDENT_ANCHOR",
        "joint_ratio_precision": "NOT_EVALUATED_MISSING_PRODUCT_ANCHOR_COVARIANCE",
        "mixture_interpretation": "equal-family robustness diagnostic; not calibrated model-averaged evidence",
    }


def directwave_grid_summary(archive_path: Path) -> list[dict[str, Any]]:
    prefix = "GW250114_horizon_signatures/fig_4/data/late_times/"
    with zipfile.ZipFile(archive_path) as archive:
        members = sorted(
            [name for name in archive.namelist()
             if name.startswith(prefix) and re.search(r"DW_ftau_-?\d+(?:\.\d+)?M\.h5$", name)],
            key=lambda name: float(re.search(r"(-?\d+(?:\.\d+)?)M", name).group(1)),
        )
    if len(members) != 7:
        raise ValueError(f"expected seven cached late-time grids in validated ZIP; found {len(members)}")
    rows: list[dict[str, Any]] = []
    with zipfile.ZipFile(archive_path) as archive:
        payloads = [(member, archive.read(member)) for member in members]
    for member, payload in payloads:
        with h5py.File(io.BytesIO(payload), "r") as file:
            dataset = file["likelihood_data"]
            logl = dataset[:]
            attrs = dict(dataset.attrs)
        rates = np.arange(
            float(attrs["invTau_bounds"][0]),
            float(attrs["invTau_bounds"][1]) + 1e-10,
            float(attrs["delta_invTau"]),
        )
        freqs = np.arange(
            float(attrs["hz_bounds"][0]),
            float(attrs["hz_bounds"][1]) + 1e-10,
            float(attrs["delta_hz"]),
        )
        if logl.shape != (len(rates), len(freqs)):
            raise ValueError(f"grid shape mismatch in {member}")
        weights = stable_weights(logl)
        rate_weights = np.sum(weights, axis=1)
        freq_weights = np.sum(weights, axis=0)
        damping_time = 1.0 / rates
        naive_project_time = 2.0 / rates
        rq = discrete_weighted_quantile(rates, rate_weights, [0.05, 0.16, 0.50, 0.84, 0.95])
        # For monotone-decreasing transforms, reverse the rate quantiles.  This
        # preserves the exact release-grid convention (for example, the -7 M
        # central 90% rate interval 400--520 /s becomes 1.923--2.500 ms).
        dq = 1.0 / rq[::-1]
        pq = 2.0 / rq[::-1]
        fq = discrete_weighted_quantile(freqs, freq_weights, [0.05, 0.50, 0.95])
        rate_mean = float(np.sum(rate_weights * rates))
        rate_std = float(np.sqrt(np.sum(rate_weights * (rates - rate_mean) ** 2)))
        d_mean = float(np.sum(rate_weights * damping_time))
        d_std = float(np.sqrt(np.sum(rate_weights * (damping_time - d_mean) ** 2)))
        maximum = np.unravel_index(np.argmax(logl), logl.shape)
        rows.append({
            "zip_member": member,
            "zip_member_sha256": hashlib.sha256(payload).hexdigest(),
            "start_time_M": float(attrs["time"]),
            "map_frequency_hz": float(freqs[maximum[1]]),
            "map_effective_damping_rate_per_s": float(rates[maximum[0]]),
            "frequency_q05_hz": float(fq[0]),
            "frequency_median_hz": float(fq[1]),
            "frequency_q95_hz": float(fq[2]),
            "effective_rate_q05_per_s": float(rq[0]),
            "effective_rate_q16_per_s": float(rq[1]),
            "effective_rate_median_per_s": float(rq[2]),
            "effective_rate_q84_per_s": float(rq[3]),
            "effective_rate_q95_per_s": float(rq[4]),
            "effective_rate_relative_std": rate_std / rate_mean,
            "effective_damping_time_q05_ms": float(dq[0] * 1e3),
            "effective_damping_time_q16_ms": float(dq[1] * 1e3),
            "effective_damping_time_median_ms": float(dq[2] * 1e3),
            "effective_damping_time_q84_ms": float(dq[3] * 1e3),
            "effective_damping_time_q95_ms": float(dq[4] * 1e3),
            "effective_damping_time_relative_std": d_std / d_mean,
            "naive_2_over_rate_q05_ms": float(pq[0] * 1e3),
            "naive_2_over_rate_median_ms": float(pq[2] * 1e3),
            "naive_2_over_rate_q95_ms": float(pq[4] * 1e3),
            "relative_width_proxy_over_independent_gaussian_geometric_bf10_target": (d_std / d_mean) / ANCHOR_TARGETS["geometric_mean_bf10"],
            "released_grid_measure": "equal cached grid-cell weight (uniform in frequency and effective damping rate)",
            "paper_regime": "SUPPORTED_SEARCH_REGIME" if float(attrs["time"]) >= -7.0 else "EXPLORATORY_EARLY_WINDOW",
            "detector_scope": "network H1+L1 only",
            "crossfit_available_from_cache": False,
            "horizon_anchor_available": False,
            "reason_not_anchor": "effective evolving rate is not horizon kappa; mapping needs trajectory beta_traj and same-strain reuse needs a joint likelihood",
        })
    return rows


def exact_anchor_targets() -> list[dict[str, Any]]:
    labels = {
        "geometric_mean_bf3": "exp(E log BF)>=3",
        "geometric_mean_bf10": "exp(E log BF)>=10",
        "geometric_mean_bf100": "exp(E log BF)>=100",
        "p_bf_gt_1_90pct": "P(BF>1)>=90%",
        "p_bf_gt_1_95pct": "P(BF>1)>=95%",
        "p_bf_gt_10_90pct": "P(BF>10)>=90%",
    }
    return [{
        "requirement": labels[key],
        "max_sigma_t_over_t": value,
        "max_sigma_t_over_t_percent": 100.0 * value,
        "max_sigma_t_microseconds_at_t_ref": value * T_REF_S * 1e6,
        "limit": "exact-product, independent Gaussian anchor centered on physical branch; old fixed v65-v69 geometry",
    } for key, value in ANCHOR_TARGETS.items()]


def anchor_power_examples() -> list[dict[str, Any]]:
    """Exact infinite-product Gaussian-anchor distribution.

    For a broad flat-t ridge prior, log BF is normal with mean
    c + d^2/2 and variance d^2, where c=log(tau_g/tau_p) and
    d=(tau_p/tau_g-1)/sigma_rel.
    """
    c = math.log(TAU_GRID_OLD / LN4)
    rminus1 = LN4 / TAU_GRID_OLD - 1.0
    rows = []
    for sigma_rel in [0.02, 0.015, 0.011822375705173773, 0.01, 0.005, 0.003, 0.002, 0.0017, 0.0015, 0.001]:
        d = rminus1 / sigma_rel
        mean_logbf = c + 0.5 * d * d
        p_positive = 0.5 * (1.0 + math.erf(mean_logbf / (d * math.sqrt(2.0))))
        rows.append({
            "anchor_sigma_t_over_t": sigma_rel,
            "anchor_sigma_percent": 100.0 * sigma_rel,
            "mean_log_bf": mean_logbf,
            "geometric_mean_bf": math.exp(mean_logbf) if mean_logbf < 700 else float("inf"),
            "p_bf_gt_1": p_positive,
            "note": "prior-coordinate-sensitive exact-product independent-Gaussian benchmark; not GW250114 evidence",
        })
    return rows


def stable_profile_mismatch(a: np.ndarray, b: np.ndarray) -> float:
    scale = np.vdot(b, a) / float(np.vdot(b, b).real)
    residual = a - scale * b
    return float(np.vdot(residual, residual).real / np.vdot(a, a).real)


def carrier(freq: np.ndarray, detector: str) -> np.ndarray:
    amplitude = (freq / 100.0) ** (-7.0 / 6.0) * np.exp(-(freq / 900.0) ** 2)
    phase = 0.019 * freq + 1.1e-5 * freq ** 2
    if detector == "L1":
        phase = phase + 0.63 + 2.0 * np.pi * freq * 0.0069
    return amplitude * np.exp(1j * phase)


def transfer(freq: np.ndarray, tau: float, t_s: float = T_REF_S,
             rho: float = 0.25) -> np.ndarray:
    return 1.0 + rho * np.exp(-1j * np.pi * freq * tau * t_s)


def snr_for_sign(delta: float, probability: float) -> float:
    if delta <= 0:
        return float("inf")
    # Inverse normal values needed by this package only.
    z = {0.90: 1.2815515655446004, 0.95: 1.6448536269514722}[probability]
    y = (z * z + math.sqrt(z ** 4 + 2.0 * delta * z * z)) / delta
    return math.sqrt(y)


def power_semantic_repair() -> list[dict[str, Any]]:
    rows = []
    for nfreq, label in [(512, "v65 512-bin base-carrier point-template geometry"), (8192, "v69 continuum surrogate")]:
        freq = np.linspace(50.0, 1024.0, nfreq)
        hp = np.r_[carrier(freq, "H1") * transfer(freq, LN4),
                   carrier(freq, "L1") * transfer(freq, LN4)]
        hg = np.r_[carrier(freq, "H1") * transfer(freq, TAU_GRID_OLD),
                   carrier(freq, "L1") * transfer(freq, TAU_GRID_OLD)]
        delta = stable_profile_mismatch(hp, hg)
        rows.append({
            "scenario": label,
            "frequency_bins_per_detector": nfreq,
            "one_minus_match_squared": delta,
            "match": math.sqrt(1.0 - delta),
            "approx_moment_gaussian_full_template_snr_for_90pct_profile_sign": snr_for_sign(delta, 0.90),
            "scope": "unwhitened analytic synthetic carrier; not a PSD-weighted GW250114 likelihood",
        })
    rows.append({
        "scenario": "constant-rho exact phase alignment",
        "frequency_bins_per_detector": "any",
        "one_minus_match_squared": 0.0,
        "match": 1.0,
        "approx_moment_gaussian_full_template_snr_for_90pct_profile_sign": "infinity",
        "scope": "analytic equality; floating residuals must be snapped to zero",
    })
    return rows


def correction_register() -> list[dict[str, Any]]:
    return [
        {
            "issue": "official input gate used filename presence only",
            "v70_repair": "fail closed on MD5 where published, exact size, ZIP CRC/members, and HDF5 schema",
            "impact": "prevents corrupt same-name files from passing",
        },
        {
            "issue": "expected BF terminology",
            "v70_repair": "rename to mean profile log-likelihood or geometric-mean BF only under an explicit marginalized model",
            "impact": "profiling is not Bayesian marginal evidence and exp(E log BF) is not E(BF)",
        },
        {
            "issue": "phase-aligned exact gauge retained floating residual",
            "v70_repair": "set analytic mismatch to zero and required SNR to infinity",
            "impact": "preserves the exact theorem numerically",
        },
        {
            "issue": "8192-bin surrogate described as v65 geometry",
            "v70_repair": "report the exact 512-bin v65 base-carrier point-template mismatch separately from the continuum surrogate",
            "impact": "changes the approximate moment-Gaussian illustrative SNR90 from 1001.58 to 1016.51",
        },
        {
            "issue": "SNR called branch-component SNR",
            "v70_repair": "label it full normalized template SNR in the surrogate statistic",
            "impact": "avoids an uncalibrated component-SNR interpretation",
        },
        {
            "issue": "power audit omitted detector PSD and posterior carrier mixture",
            "v70_repair": "label as an oracle/synthetic carrier bound; real PSD-weighted likelihood remains pending",
            "impact": "prevents event-scale overinterpretation of the quoted number",
        },
        {
            "issue": "official script inventoried but did not parse binaries",
            "v70_repair": "parse and validate every supplied official file; analyze released posteriors and cached grids",
            "impact": "turns intake into an executed official-input gate",
        },
        {
            "issue": "v69 manifest listed only 4-kHz strain for the Nature replay",
            "v70_repair": "require and validate both official 16-kHz products; retain 4 kHz as the native-grid/operator lane",
            "impact": "the released Nature scripts are configured around 16-kHz input and an 8192-Hz analysis rate",
        },
    ]


def posterior_double_weighting_diagnostic(input_dir: Path) -> dict[str, float]:
    path = input_dir / "posterior_samples_NRSur7dq4.h5"
    with h5py.File(path, "r") as file:
        _, dataset = posterior_dataset(file)
        log_weight = np.asarray(dataset["log_likelihood"], dtype=float)
        log_weight += np.asarray(dataset["log_prior"], dtype=float)
    weights = stable_weights(log_weight)
    return {
        "n_posterior_rows": float(len(weights)),
        "effective_sample_size_if_reweighted": float(1.0 / np.sum(weights * weights)),
        "maximum_second_weight": float(np.max(weights)),
    }


def release_code_audit(input_dir: Path) -> list[dict[str, Any]]:
    diagnostic = posterior_double_weighting_diagnostic(input_dir)
    return [
        {
            "component": "fig_5 sky/remnant robustness mixture",
            "released_operation": "arithmetic mean of log-likelihood arrays",
            "required_operation": "logsumexp of likelihoods minus log sample count, with declared weights",
            "status": "BLOCKED_RECOMPUTE",
            "impact": "released result is a geometric-mean likelihood, not Bayesian marginalization",
        },
        {
            "component": "fig_5 remnant posterior resampling",
            "released_operation": "posterior rows sampled again with weights proportional to exp(log_likelihood+log_prior)",
            "required_operation": "use posterior rows with their documented posterior weights or prove residual importance weights",
            "status": "BLOCKED_DOCUMENT_OR_RECOMPUTE",
            "impact": "appears to double-weight an already posterior-sampled file",
            "computed_rows": int(diagnostic["n_posterior_rows"]),
            "computed_effective_sample_size_if_reweighted": diagnostic["effective_sample_size_if_reweighted"],
            "computed_maximum_second_weight": diagnostic["maximum_second_weight"],
        },
        {
            "component": "fig_2_6 direct-wave amplitude/time MCMC cache",
            "released_operation": "full 32x5000 flattened chain with no released burn-in/convergence gate",
            "required_operation": "document burn-in, autocorrelation/convergence, and deterministic seed",
            "status": "NOT_ADMITTED_AS_FREQUENCY_OR_DAMPING_POSTERIOR",
            "impact": "cache contains only amplitude and time offset, not frequency, damping rate, kappa, or t_DW",
        },
        {
            "component": "GWOSC release provenance",
            "released_operation": "Nature/Zenodo analysis tied to O4 Discovery Papers v1",
            "required_operation": "pin v1; treat GWTC-5.0 v2 substitution as a separate systematics lane",
            "status": "PINNED_V1",
            "impact": "prevents silent data-release drift",
        },
    ]


def official_completion_candidates() -> list[dict[str, Any]]:
    return [
        {
            "candidate": "Kerr-linked remnant coordinate t_K=2/kappa(M_f,chi_f)",
            "conditional_local_rank_candidate": True,
            "actual_free_nuisance_rank_complete": False,
            "standalone_independent_width_screen_pass": False,
            "joint_ratio_precision_evaluated": False,
            "global_structural_alias_separated": None,
            "status": "CONDITIONAL_RANK_CANDIDATE_NOT_ADMITTED",
            "blocker": "physical t_DW=t_K identification/calibration is conditional; same-event posterior covariance with the HRF product is unavailable",
        },
        {
            "candidate": "released segmented effective damping rate kappa_hat",
            "conditional_local_rank_candidate": True,
            "actual_free_nuisance_rank_complete": False,
            "standalone_independent_width_screen_pass": False,
            "joint_ratio_precision_evaluated": False,
            "global_structural_alias_separated": None,
            "status": "CONDITIONAL_RANK_CANDIDATE_NOT_ADMITTED",
            "blocker": "network-only same-strain grids; kappa_hat-to-kappa map has free trajectory beta_traj; supported -7M..-3M widths are 8.15--17.88%",
        },
        {
            "candidate": "H1 anchor -> L1 branch and swapped cross-fit",
            "conditional_local_rank_candidate": True,
            "actual_free_nuisance_rank_complete": None,
            "standalone_independent_width_screen_pass": None,
            "joint_ratio_precision_evaluated": False,
            "global_structural_alias_separated": None,
            "status": "BLOCKED_CACHE_NETWORK_ONLY",
            "blocker": "must rebuild detector-specific remnant/QNM/direct-wave nuisances from 16-kHz strain with no network-posterior leakage into the held-out detector",
        },
        {
            "candidate": "additional fixed harmonic or echo order n*tau*t",
            "conditional_local_rank_candidate": False,
            "actual_free_nuisance_rank_complete": False,
            "standalone_independent_width_screen_pass": None,
            "joint_ratio_precision_evaluated": False,
            "global_structural_alias_separated": False,
            "status": "EXACT_FAIL",
            "blocker": "delay ratio is constant in tau and retains the product gauge",
        },
        {
            "candidate": "second delay t*phi_2(tau) with nonconstant phi_2/phi_1",
            "conditional_local_rank_candidate": True,
            "actual_free_nuisance_rank_complete": None,
            "standalone_independent_width_screen_pass": None,
            "joint_ratio_precision_evaluated": False,
            "global_structural_alias_separated": None,
            "status": "THEORY_ROUTE_NOT_OBSERVED",
            "blocker": "requires a calibrated nonproportional observable and covariance",
        },
    ]


def gate_status_rows(required_ok: bool, all_inputs_ok: bool) -> list[dict[str, Any]]:
    return [
        {"gate": "official_binary_intake", "status": "PASS" if required_ok else "FAIL",
         "reason": "fail-closed checksum, byte-length, ZIP, and HDF5 schema validation"},
        {"gate": "exact_Nature_replay_inputs", "status": "PASS" if all_inputs_ok else "FAIL",
         "reason": "16-kHz H1/L1 required; 4 kHz retained as native-grid/operator lane"},
        {"gate": "raw_Nature_pipeline_replay", "status": "NOT_EXECUTED",
         "reason": "v70 parses released posteriors/caches and validates strain; it does not rerun qnm_filter/NRSur from raw strain"},
        {"gate": "single_delay_structural_identification", "status": "EXACT_FAIL",
         "reason": "v69 product gauge retained"},
        {"gate": "Kerr_linked_standalone_anchor_width_screen", "status": "FAIL_AS_STANDALONE_INDEPENDENT_ANCHOR",
         "reason": "all four same-event posterior-width proxies exceed the independent-Gaussian benchmark; joint product-anchor covariance is unavailable"},
        {"gate": "waveform_family_shift_sensitivity", "status": "SENSITIVITY_FAIL_UNDER_V70_SHIFT_TOLERANCE",
         "reason": "family median spread is 4.22 times the old branch shift; this is a conservative sensitivity diagnostic, not an incompatibility test"},
        {"gate": "released_directwave_observable_completion", "status": "CONDITIONAL_RANK_CANDIDATE_NOT_ADMITTED",
         "reason": "effective kappa_hat is network-only, same-strain, evolving, and retains free beta_traj in the horizon map"},
        {"gate": "detector_crossfit_from_release_cache", "status": "BLOCKED",
         "reason": "no H1-only or L1-only cached likelihood surfaces"},
        {"gate": "fig5_robustness_marginalization", "status": "BLOCKED_RECOMPUTE",
         "reason": "released arithmetic log-likelihood average is not a likelihood marginalization"},
        {"gate": "joint_product_anchor_ratio_precision", "status": "NOT_EVALUATED",
         "reason": "released products lack the covariance needed for V_tau and effective branch information"},
        {"gate": "real_PSD_weighted_HRF_likelihood", "status": "STOPPED_UPSTREAM",
         "reason": "no released standalone anchor is admitted and covariance-complete joint precision is not available"},
        {"gate": "physical_ln4_g4_area_quantization", "status": "LOCKED",
         "reason": "all upstream gates have not passed"},
    ]


def plot_anchor_posteriors(path: Path, arrays: dict[str, np.ndarray]) -> None:
    fig, ax = plt.subplots(figsize=(8.4, 5.2))
    bins = np.linspace(2.98, 3.30, 90)
    for family, values in arrays.items():
        ax.hist(values * 1e3, bins=bins, density=True, histtype="step", linewidth=1.7, label=family)
    ax.axvline(T_ALIGN_S * 1e3, color="black", linestyle="--", linewidth=1.4,
               label="exact ln(4)/9-sample alignment")
    ax.set_xlabel(r"Kerr-linked project coordinate $t_K=2/\kappa$ [ms]")
    ax.set_ylabel("posterior density")
    ax.set_title("Official GW250114 remnant posteriors: scale-anchor width")
    ax.legend(frameon=False, fontsize=8)
    ax.text(0.01, 0.01, "Same-event diagnostic; not an independent direct-wave anchor.",
            transform=ax.transAxes, fontsize=8)
    fig.tight_layout()
    fig.savefig(path, dpi=180)
    plt.close(fig)


def plot_directwave_evolution(path: Path, rows: list[dict[str, Any]]) -> None:
    rows = sorted(rows, key=lambda row: row["start_time_M"])
    x = np.array([row["start_time_M"] for row in rows])
    med = np.array([row["effective_rate_median_per_s"] for row in rows])
    lo = np.array([row["effective_rate_q05_per_s"] for row in rows])
    hi = np.array([row["effective_rate_q95_per_s"] for row in rows])
    fig, ax = plt.subplots(figsize=(8.4, 5.2))
    ax.axvspan(-9.3, -7.5, color="gray", alpha=0.10, label="exploratory -9M/-8M")
    ax.fill_between(x, lo, hi, alpha=0.25, color="#4C78A8", label="central 90% cached-grid mass")
    ax.plot(x, med, marker="o", color="#1f4e79", label="median effective rate")
    ax.set_xlabel(r"analysis start time [$M_f^{det}$]")
    ax.set_ylabel(r"effective damping rate [s$^{-1}$]")
    ax.set_title("Released network direct-wave grids evolve with start time")
    ax.legend(frameon=False)
    ax.text(0.01, 0.01, "Network-only likelihood grids; effective rate is not an independent horizon kappa.",
            transform=ax.transAxes, fontsize=8)
    fig.tight_layout()
    fig.savefig(path, dpi=180)
    plt.close(fig)


def plot_precision_budget(path: Path, anchor_rows: list[dict[str, Any]],
                          directwave_rows: list[dict[str, Any]]) -> None:
    labels = [row["waveform_family"] for row in anchor_rows]
    values = [100.0 * row["t_k_sigma_over_old_physical_t_ref"] for row in anchor_rows]
    supported = [row for row in directwave_rows if row["paper_regime"] == "SUPPORTED_SEARCH_REGIME"]
    labels.append("best supported effective-rate\nwidth proxy")
    values.append(100.0 * min(row["effective_damping_time_relative_std"] for row in supported))
    x = np.arange(len(labels))
    fig, ax = plt.subplots(figsize=(9.0, 5.3))
    ax.bar(x, values, color=["#4C78A8"] * 4 + ["#F58518"])
    ax.axhline(100.0 * ANCHOR_TARGETS["geometric_mean_bf10"], color="black", linestyle="--",
               label="independent-Gaussian geometric-BF10 screen")
    ax.axhline(100.0 * ANCHOR_TARGETS["p_bf_gt_1_90pct"], color="#B22222", linestyle=":",
               label="independent-Gaussian 90% sign screen")
    ax.set_yscale("log")
    ax.set_ylabel("relative width [%] (log scale)")
    ax.set_xticks(x, labels, rotation=15, ha="right")
    ax.set_title("No released product passes the standalone independent-anchor width screen")
    ax.legend(frameon=False, fontsize=8)
    ax.text(0.01, 0.01, "Effective-rate bar is diagnostic only; the horizon mapping is not admitted.",
            transform=ax.transAxes, fontsize=8)
    fig.tight_layout()
    fig.savefig(path, dpi=180)
    plt.close(fig)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input-dir", type=Path, required=True,
                        help="directory containing the official ZIP, posterior HDF5 files, and strain HDF5 files")
    parser.add_argument("--outdir", type=Path, required=True)
    parser.add_argument("--strict", action="store_true",
                        help="exit nonzero unless every required and supplied systematics input passes")
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)

    validation = validate_inputs(args.input_dir)
    required_ok = all(row["status"] == "PASS" for row in validation if row["required_for_core_gate"])
    supplied_ok = all(row["status"] == "PASS" for row in validation if row["present"])
    all_inputs_ok = all(row["status"] == "PASS" for row in validation)
    write_csv(args.outdir / "GW250114_V70_official_input_validation.csv", validation)

    if not required_ok:
        summary = {
            "version": VERSION,
            "date": DATE,
            "status": STATUS,
            "official_required_integrity_pass": False,
            "verdict": "BLOCKED_FAIL_CLOSED_OFFICIAL_INPUT_INTEGRITY",
        }
        (args.outdir / "GW250114_V70_summary.json").write_text(
            json.dumps(summary, indent=2, sort_keys=True) + "\n"
        )
        if args.strict:
            raise SystemExit(2)
        print(json.dumps(summary, indent=2, sort_keys=True))
        return

    anchor_rows, anchor_arrays = posterior_anchor_summary(args.input_dir)
    mixture = mixture_summary(anchor_arrays)
    directwave_rows = directwave_grid_summary(args.input_dir / HORIZON_ARCHIVE)
    targets = exact_anchor_targets()
    power = anchor_power_examples()
    repairs = correction_register()
    code_audit = release_code_audit(args.input_dir)
    candidates = official_completion_candidates()
    gates = gate_status_rows(required_ok, all_inputs_ok)
    semantic_power = power_semantic_repair()

    write_csv(args.outdir / "GW250114_V70_kerr_anchor_by_waveform.csv", anchor_rows)
    write_csv(args.outdir / "GW250114_V70_kerr_anchor_mixture.csv", [mixture])
    write_csv(args.outdir / "GW250114_V70_directwave_evolution.csv", directwave_rows)
    write_csv(args.outdir / "GW250114_V70_exact_anchor_targets.csv", targets)
    write_csv(args.outdir / "GW250114_V70_anchor_independent_benchmark.csv", power)
    write_csv(args.outdir / "GW250114_V70_v69_correction_register.csv", repairs)
    write_csv(args.outdir / "GW250114_V70_release_code_audit.csv", code_audit)
    write_csv(args.outdir / "GW250114_V70_official_completion_candidates.csv", candidates)
    write_csv(args.outdir / "GW250114_V70_gate_status.csv", gates)
    write_csv(args.outdir / "GW250114_V70_power_semantic_repair.csv", semantic_power)

    plot_anchor_posteriors(args.outdir / "GW250114_V70_kerr_anchor_posteriors.png", anchor_arrays)
    plot_directwave_evolution(args.outdir / "GW250114_V70_directwave_evolution.png", directwave_rows)
    plot_precision_budget(args.outdir / "GW250114_V70_precision_budget.png", anchor_rows, directwave_rows)

    min_anchor = min(row["t_k_sigma_over_old_physical_t_ref"] for row in anchor_rows)
    max_anchor = max(row["t_k_sigma_over_old_physical_t_ref"] for row in anchor_rows)
    supported_directwave_rows = [
        row for row in directwave_rows if row["paper_regime"] == "SUPPORTED_SEARCH_REGIME"
    ]
    min_direct_all = min(row["effective_damping_time_relative_std"] for row in directwave_rows)
    max_direct_all = max(row["effective_damping_time_relative_std"] for row in directwave_rows)
    min_direct_supported = min(row["effective_damping_time_relative_std"] for row in supported_directwave_rows)
    max_direct_supported = max(row["effective_damping_time_relative_std"] for row in supported_directwave_rows)
    direct_medians = [row["effective_rate_median_per_s"] for row in directwave_rows]
    supported_direct_medians = [row["effective_rate_median_per_s"] for row in supported_directwave_rows]
    exact_v65 = next(row for row in semantic_power if row["scenario"].startswith("v65 512-bin"))
    summary = {
        "version": VERSION,
        "date": DATE,
        "status": STATUS,
        "official_required_integrity_pass": required_ok,
        "official_supplied_integrity_pass": supplied_ok,
        "official_all_nine_inputs_pass": len(validation) == 9 and all_inputs_ok,
        "official_input_count_pass": sum(row["status"] == "PASS" for row in validation),
        "official_input_count_total": len(validation),
        "official_release_pin": "GWOSC O4_Discovery_Papers GW250114_082203 v1",
        "nature_replay_16khz_required": True,
        "kerr_linked_project_coordinate": {
            "definition": "t_K=2/kappa=4 M_f t_sun (1+sqrt(1-chi_f^2))/sqrt(1-chi_f^2)",
            "waveform_family_sigma_over_old_physical_t_ref_min": min_anchor,
            "waveform_family_sigma_over_old_physical_t_ref_max": max_anchor,
            "equal_family_mixture": mixture,
            "bf10_precision_target": ANCHOR_TARGETS["geometric_mean_bf10"],
            "p_bf_gt_1_90pct_precision_target": ANCHOR_TARGETS["p_bf_gt_1_90pct"],
            "all_waveform_families_fail_standalone_independent_width_screen": all(
                row["independent_gaussian_width_screen_geometric_bf10"] == "FAIL_AS_STANDALONE_INDEPENDENT_ANCHOR"
                for row in anchor_rows
            ),
            "joint_product_anchor_ratio_precision": "NOT_EVALUATED_MISSING_COVARIANCE",
        },
        "released_direct_wave_grids": {
            "n_start_times": len(directwave_rows),
            "start_time_range_M": [min(row["start_time_M"] for row in directwave_rows), max(row["start_time_M"] for row in directwave_rows)],
            "all_seven_including_exploratory_relative_std_min": min_direct_all,
            "all_seven_including_exploratory_relative_std_max": max_direct_all,
            "supported_minus7M_to_minus3M_relative_std_min": min_direct_supported,
            "supported_minus7M_to_minus3M_relative_std_max": max_direct_supported,
            "all_seven_effective_rate_median_min_per_s": min(direct_medians),
            "all_seven_effective_rate_median_max_per_s": max(direct_medians),
            "supported_minus7M_to_minus3M_effective_rate_median_min_per_s": min(supported_direct_medians),
            "supported_minus7M_to_minus3M_effective_rate_median_max_per_s": max(supported_direct_medians),
            "network_only": True,
            "crossfit_available_from_cache": False,
            "usable_as_independent_horizon_anchor": False,
            "conditional_rank_candidate_only": True,
        },
        "v69_semantic_repairs": {
            "correction_count": len(repairs),
            "v65_512bin_base_carrier_one_minus_match_squared": exact_v65["one_minus_match_squared"],
            "v65_512bin_base_carrier_approx_moment_gaussian_full_template_snr90": exact_v65["approx_moment_gaussian_full_template_snr_for_90pct_profile_sign"],
            "exact_gauge_mismatch": 0.0,
            "expected_bf_term_retired": True,
        },
        "release_code_audit": {
            "finding_count": len(code_audit),
            "fig5_robustness_marginalization_admitted": False,
            "baseline_fig4_network_grids_admitted_as_diagnostics": True,
            "computed_apparent_second_weighting_ess": code_audit[1]["computed_effective_sample_size_if_reweighted"],
        },
        "gate_decision": {
            "official_intake": "PASS",
            "single_delay_structural_identifiability": "EXACT_FAIL_RETAINED_FROM_V69",
            "kerr_linked_standalone_anchor_width_screen": "FAIL_AS_STANDALONE_INDEPENDENT_ANCHOR",
            "joint_product_anchor_ratio_precision": "NOT_EVALUATED_MISSING_COVARIANCE",
            "waveform_family_shift_sensitivity": "SENSITIVITY_FAIL_UNDER_V70_SHIFT_TOLERANCE",
            "released_directwave_anchor": "CONDITIONAL_RANK_CANDIDATE_NOT_ADMITTED",
            "released_cache_detector_crossfit": "BLOCKED_NETWORK_ONLY",
            "raw_Nature_pipeline_replay": "NOT_EXECUTED_CACHED_PRODUCTS_AUDITED",
            "real_psd_weighted_hrf_likelihood": "NOT_EXECUTED_UPSTREAM_GATE_FAILED",
            "physical_interpretation": "LOCKED",
        },
        "verdict": "OFFICIAL_PRODUCTS_NO_ADMISSIBLE_STANDALONE_COMPLETION_JOINT_NOT_EVALUATED",
    }
    (args.outdir / "GW250114_V70_summary.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True, default=float) + "\n"
    )

    selftest = {
        "all_required_inputs_pass": required_ok,
        "all_nine_inputs_pass": len(validation) == 9 and all_inputs_ok,
        "four_waveform_families_analyzed": len(anchor_rows) == 4,
        "seven_directwave_grids_analyzed": len(directwave_rows) == 7,
        "all_kerr_standalone_width_proxies_exceed_bf10_target": all(
            row["t_k_sigma_over_old_physical_t_ref"] > ANCHOR_TARGETS["geometric_mean_bf10"] for row in anchor_rows
        ),
        "directwave_cache_network_only": all(not row["crossfit_available_from_cache"] for row in directwave_rows),
        "directwave_members_read_from_validated_zip": all(row["zip_member_sha256"] for row in directwave_rows),
        "supported_directwave_regime_has_five_windows": len(supported_directwave_rows) == 5,
        "computed_anchor_targets_match_frozen_values": all([
            abs(ANCHOR_TARGETS["geometric_mean_bf10"] - 0.002032098315872674) < 1e-15,
            abs(ANCHOR_TARGETS["geometric_mean_bf100"] - 0.0014375891911995765) < 1e-15,
            abs(ANCHOR_TARGETS["p_bf_gt_1_90pct"] - 0.00170073684) < 5e-12,
            abs(ANCHOR_TARGETS["p_bf_gt_10_90pct"] - 0.00115388961) < 5e-12,
        ]),
        "exact_gauge_zero": semantic_power[-1]["one_minus_match_squared"] == 0.0,
        "exact_v65_delta_reproduced": abs(
            exact_v65["one_minus_match_squared"] - 3.178928121129632e-6
        ) < 1e-16,
    }
    selftest["all_pass"] = all(selftest.values())
    (args.outdir / "GW250114_V70_SELF_TEST.json").write_text(
        json.dumps(selftest, indent=2, sort_keys=True) + "\n"
    )

    if args.strict and not (required_ok and supplied_ok and selftest["all_pass"]):
        raise SystemExit(3)
    print(json.dumps(summary, indent=2, sort_keys=True, default=float))


if __name__ == "__main__":
    main()
