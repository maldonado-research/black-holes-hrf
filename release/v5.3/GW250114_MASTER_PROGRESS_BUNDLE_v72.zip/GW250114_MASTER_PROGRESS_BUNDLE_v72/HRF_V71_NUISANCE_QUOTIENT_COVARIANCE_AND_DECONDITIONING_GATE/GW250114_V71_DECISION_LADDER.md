# GW250114 HRF v71 decision ladder

```text
v70 canonical parent and official-product identity
-> nuisance-quotient local completion q not in Col(B)
-> global nuisance-image separation for every alias
-> likelihood-only covariance feasibility and bias floor
-> calibrated standard-GR/no-extra-HRF detection under a nonregular null
-> detector-specific remnant/direct-wave inference without network leakage
-> generative carrier/onset/taper/amplitude/noise contract
-> joint product-anchor covariance and trajectory/calibration stress set
-> ln(4) versus composite lattice and continuous-tau alternatives
-> detector/waveform/sample-rate/PSD robustness
-> physical interpretation only if every gate passes
```

## Current stop

```text
released detector likelihood bookkeeping reconstructed
-> STOP: direct-wave walker-as-chain convergence-admission screen and reweight support fail
-> STOP: audited CBC network-to-detector direct-importance support and semantics fail
-> STOP: nuisance-quotient/global completion not established
-> STOP: nonregular null not calibrated
-> physical interpretation locked
```

## Locked shortcuts

- A nonzero nominal branch derivative is not completion when a free nuisance can mimic it.
- Same-strain covariance is not automatically helpful; its loading and full matrix must be measured.
- Importance reweighting cannot create support absent from its proposal sample; the released samples fail the declared direct-importance diagnostics here.
- H1-to-L1 and L1-to-H1 directions are correlated diagnostics, not two independent detections.
- `D>0` between two points is not HRF detection and not a composite-alternative test.
- A standard-GR direct wave is part of the null, not evidence for an extra HRF copy.
