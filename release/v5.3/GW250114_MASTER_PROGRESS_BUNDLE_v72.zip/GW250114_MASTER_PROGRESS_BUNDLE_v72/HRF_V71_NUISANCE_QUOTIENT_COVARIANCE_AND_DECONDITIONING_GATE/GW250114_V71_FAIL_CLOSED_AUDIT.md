# GW250114 HRF v71 — Fail-closed input audit

**Date:** 2026-07-11  
**Result:** `PASS_4_OF_4`  
**Scope:** strict input admission only. These tests do not validate the scientific model, posterior convergence, detector deconditioning, or physical interpretation.

Final generator SHA-256: `2ed63a04a26b8cc79975a45dad30e2cda72d5c271d595d0586c2d12e24d6edb1`.

## Frozen command form

Each case used the same strict generator entry point and the pinned local numerical environment:

```bash
PYTHONPATH=/workspace/scratch/457417472402/vendor_h5py \
MPLCONFIGDIR=/tmp/mpl_v71_fail \
SOURCE_DATE_EPOCH=1783785600 \
python v71_build/HRF_V71_NUISANCE_QUOTIENT_COVARIANCE_AND_DECONDITIONING_GATE/gw250114_v71_nuisance_covariance_gate.py \
  --v70-zip <case-parent-zip> \
  --input-dir <case-input-dir> \
  --outdir <case-output-dir> \
  --strict
```

The canonical files were never modified. Corrupt copies and missing-input views were constructed only under `/tmp`.

## Negative cases

### 1. Missing required posterior

- Construction: all verified official inputs were symlinked into `/tmp/v71_case_missing_posterior` except `posterior_samples_PhenomXPHM.h5`.
- Exact invocation arguments:

```text
--v70-zip upload/HRF_V70_OFFICIAL_ANCHOR_EVOLVING_DECAY_AND_INDEPENDENT_BENCHMARK.zip
--input-dir /tmp/v71_case_missing_posterior
--outdir /tmp/v71_final2_fc_missing
--strict
```

- Exit code: `2`.
- Standard error: `strict input validation failed`.
- Failing row: `posterior_samples_PhenomXPHM.h5`, `present=False`, `checksum_ok=False`, `schema_ok=False`, `status=FAIL_MISSING`.
- Output boundary: exactly one file, `GW250114_V71_input_validation.csv`; no downstream scientific table, plot, summary, or self-test was written.

### 2. Corrupt Nature companion ZIP

- Construction: copied the official ZIP, XOR-flipped one byte at offset `1,000,000`, and symlinked every other required input.
- Corrupt SHA-256: `cf13aa7b2d72d832b507d2573d705f678bed1a14bbc79633e95f7043252a095e`.
- Exact invocation arguments:

```text
--v70-zip upload/HRF_V70_OFFICIAL_ANCHOR_EVOLVING_DECAY_AND_INDEPENDENT_BENCHMARK.zip
--input-dir /tmp/v71_case_corrupt_nature
--outdir /tmp/v71_final2_fc_nature
--strict
```

- Exit code: `2`.
- Standard error: `strict input validation failed`.
- Failing row: `GW250114_horizon_signatures.zip`, `checksum_ok=False`, `zip_crc_ok=False`, `schema_ok=False`, `status=FAIL_INTEGRITY_OR_SCHEMA`.
- Output boundary: validation CSV only.

### 3. Corrupt H1 16-kHz strain

- Construction: copied the official H1 HDF5 file, XOR-flipped its final byte, and symlinked every other required input.
- Corrupt SHA-256: `20d84fe5a16369847869b75a4917e5799274e2fb5c691d12dfed894b55232a62`.
- Exact invocation arguments:

```text
--v70-zip upload/HRF_V70_OFFICIAL_ANCHOR_EVOLVING_DECAY_AND_INDEPENDENT_BENCHMARK.zip
--input-dir /tmp/v71_case_corrupt_strain
--outdir /tmp/v71_final2_fc_strain
--strict
```

- Exit code: `2`.
- Standard error: `strict input validation failed`.
- Failing row: `H-H1_GWOSC_O4b_16KHZ_R1-1420877824-4096.hdf5`, `checksum_ok=False`, `schema_ok=True`, `status=FAIL_INTEGRITY_OR_SCHEMA`.
- Interpretation: a parseable and schema-valid file is still rejected when its frozen byte identity fails.
- Output boundary: validation CSV only.

### 4. Corrupt canonical v70 parent

- Construction: copied the canonical v70 ZIP and XOR-flipped one byte at offset `100`.
- Corrupt SHA-256: `18b63a425637fdcd1dc6de28dcaa85ef13fe79de750abde1747309b326bdf4c0`.
- Exact invocation arguments:

```text
--v70-zip /tmp/v71_corrupt_parent.zip
--input-dir official_v70_verified
--outdir /tmp/v71_final2_fc_parent
--strict
```

- Exit code: `2`.
- Standard error: `strict input validation failed`.
- Failing row: canonical parent, `checksum_ok=False`, `zip_crc_ok=False`, `schema_ok=False`, `status=FAIL_INTEGRITY_OR_MANIFEST`.
- Parser detail: `BadZipFile` reported a local-header/central-directory filename mismatch.
- Output boundary: validation CSV only.

## Decision

All four adversarial cases stopped at the input boundary with nonzero status before downstream calculations. The tests cover a missing required posterior and corruption of the canonical parent, Nature companion, and GWOSC strain input classes. They do not exhaust every possible missing file, byte mutation, filesystem error, HDF5 semantic attack, or malformed-but-hash-matching object.

The four cases were rerun against the final generator after all semantic-label and admission-wording edits. Every final execution again returned status `2` and wrote only the validation CSV.
