# GW250114 HRF v71 — Generative waveform contract

This contract must be completed before any result is called a real PSD-weighted HRF likelihood.

## 1. Hypotheses

### Standard-GR / no-extra-HRF null

The null is an admitted standard-GR waveform or residual model with ordinary merger, ringdown, horizon behavior, calibration uncertainty, and model discrepancy. It is **not** “no direct wave.”

### Extra-HRF alternative

The alternative adds a declared HRF component. For the current single-delay transfer,

\[
H(f)=1+r(f)\exp[-i\pi f s],
\qquad s=\tau t_{\rm DW}.
\]

Because the standard Fourier delay factor is `exp(-2*pi*i*f*Delta_t)`, the copy delay represented here is `Delta_t=s/2`. Any different convention must be declared and propagated everywhere.

## 2. Carrier lanes

Every analysis must name exactly one carrier lane:

1. full detector-projected IMR waveform;
2. a QNM-filtered residual with a frozen subtraction operator;
3. the Nature analytic direct-wave trajectory as a conditional model;
4. another explicitly defined physical component.

The transfer may not silently migrate between these objects. Results from different lanes are systematics comparisons, not interchangeable evidence.

## 3. Required physical definitions

- time-domain onset and causal support;
- taper/window and spectral-leakage treatment;
- Fourier sign, normalization, and copy-delay convention;
- Hermitian symmetry (or an explicitly complex analytic-signal convention) so the time-domain detector strain is well defined;
- zero padding and a noncircular implementation of every delayed copy, with edge samples excluded or modeled;
- frequency dependence, complex phase, and absolute calibration of `r(f)`;
- whether `r=0` is nested and whether amplitude lies on a boundary;
- detector antenna projection, sky time delays, polarization, and geocentric time;
- QNM modes removed or retained and the filter-induced time shift;
- remnant mass/spin and trajectory `beta_traj` with priors or joint likelihood;
- calibration splines and their detector correlations;
- PSD/ACF window, stationarity checks, data-quality and injection masks;
- likelihood normalization and all profiled or marginalized amplitudes.
- normalized priors, search bounds, and coordinate Jacobians for every alternative-only continuous parameter;
- prior weights for discrete carrier, mode, branch, and waveform-family alternatives.

## 4. Joint observable-completion return

An admissible executor must return paired samples or a likelihood representation containing:

- `ln(s)` and the nonproduct timescale coordinate;
- their full covariance blocks `A`, `B`, and `C`;
- every trajectory, calibration, phase, amplitude, onset, remnant, and waveform nuisance;
- the branch tangent `q` and nuisance Jacobian `B_eta`;
- nuisance-profiled information `I_lambda_eff`;
- minimum global nuisance-image separation for every preregistered branch/cycle alias;
- detector-separated and network likelihood components;
- standard-GR null and injection/control results.

A plug-in timescale or covariance inferred from separately reused strain is not a joint return.

## 5. Required analysis ladder

1. Calibrate standard-GR/no-extra-HRF against a free-delay HRF alternative over the full scan.
2. Admit observable completion only if `q not in Col(B_eta)` and every tested global nuisance-image separation is nonzero.
3. Compare `ln(4)` with a preregistered composite lattice and continuous-`tau` alternative.
4. Require the worst-case covariance/systematic lane to pass the declared branch-separation threshold.
5. Require detector direction, waveform family, sample rate, PSD window, calibration, and null-model robustness.
6. Only then discuss physical interpretation.

## 6. Kill conditions

Stop the physical branch lane if:

- the carrier cannot be stated as a generative physical component;
- `r=0` null calibration is absent;
- a nuisance tangent absorbs the branch tangent;
- branch nuisance-image sets intersect;
- covariance rescue depends on an unmeasured or near-singular common mode;
- an adverse differential bias for the physical upper branch reaches half the branch gap, or a symmetric robustness guarantee for either branch fails that bound;
- detector-only inference is produced by unsupported deconditioning;
- the result changes materially with MAP/ML, QNM, PSD, calibration, start time, prior coordinate, or waveform family;
- trials and composite alternatives are not controlled.
