# GW250114 HRF v71 next task

## Highest-value continuation

Provision a locked Python 3.11 environment for the released direct-wave code, reproduce the official network grid from raw discovery-v1 strain, and then build detector-separated diagnostic grids without importing network-posterior information into a held-out detector.

## Required sequence

1. Supply a frozen container or `pixi.lock` covering `gwpy`, `qnm`, `lalsuite`, `bilby`, `astropy`, `gwsurrogate`, the NRSur7dq4 asset, and embedded `qnm_filter` commit `55f14436d4ea510b71754b95da9701009e8a1c12`.
2. Reproduce the released H1+L1 `-7M` frequency–damping surface and its likelihood normalization from the validated 16-kHz strain.
3. Keep the released-draw maxima labeled as proxies, then optimize and compare genuine likelihood-only and posterior-density objectives; vary sky/time, QNM modes, filter shift, calibration, and multiple pre/post/segmented PSD/ACF windows.
4. Record DQ and injection masks. The event and `+1…+65 s` noise window have DQ mask `511`, while the continuous-wave hardware-injection exclusion bit is unset; identify any relevant injection frequencies before admission.
5. Generate H1-only and L1-only direct-wave surfaces. Require pointwise

   `ell_H1+L1(f,tau) = ell_H1(f,tau) + ell_L1(f,tau) + constant`.

6. Do not interpret those grids as an HRF cross-fit until detector-specific remnant/QNM inference is also available. The audited direct-importance reuse of the released network CBC posterior fails support and likelihood-semantics checks; run dedicated detector inference instead.
7. Implement the v71 generative waveform contract and calibrate the nonregular standard-GR/no-extra-HRF null over the complete delay/start/QNM/carrier scan.
8. Produce paired joint samples for log product, log timescale, trajectory, calibration, remnant, and waveform nuisances. Return full covariance `Omega`, nuisance tangent matrix, efficient information, and global nuisance-image distances.
9. Require the worst-case admitted lane to reach `D>=3.781060438` (`q_eff<=0.115190902%`) for the strict Gaussian feasibility gate, with adverse differential bias for the physical upper branch below half the branch gap (or the same symmetric bound if either branch must be protected).
10. Compare `ln(4)` against a preregistered composite lattice and continuous-`tau` alternative with trials control.

## Null calibration contract

The GR null bank must include ordinary direct-wave/ringdown behavior and realistic waveform/QNM-filter mismatch. Under an iid or exchangeable Bernoulli control model, with the preprocessing, full search, maximization rule, statistic, and threshold frozen before held-out controls, zero observed false positives gives the exact one-sided 95% Clopper–Pearson upper FPR `1-0.05^(1/N)`. Under those assumptions, at least `299` controls are required for an upper bound below `1%` and `2995` below `0.1%`; discovery-level trials require much larger ensembles or validated tail methods.

## Kill condition

Stop the single-event physical branch lane if the raw network grid cannot be reproduced, detector likelihood additivity fails, detector-specific nuisance inference is unavailable, the nonregular null is not calibrated, nuisance-image sets overlap, covariance rescue is not directly measured, or the worst-case systematic/bias lane fails.

A documented negative execution remains valid progress.
