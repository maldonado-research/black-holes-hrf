# GW250114 HRF v71 — Nuisance-quotient completion, covariance feasibility, and detector deconditioning

**Date:** 2026-07-11  
**Claim class:** mathematical/statistical methods and official-cache admission control. **Not a detection or discovery claim.**

## Executive decision

v70 correctly left joint product–anchor precision unevaluated. Within the declared first-order and log-Gaussian diagnostic models, v71 derives what covariance rescue would require and audits whether the released products supply an admissible estimate of that covariance.

They do not.

The mathematical route is not impossible in principle, but the current event-scale surrogate lies far outside the covariance-feasible region; the released direct-wave chain fails the v71 walker-as-chain convergence-admission screen; detector-only direct-importance reconstructions are dominated by one or a few walkers; and all eight formal H1/L1 targets across the four CBC network posteriors fail the declared direct-importance support gate. The audited `beta_traj` nuisance absorbs the evolving-rate completion direction; calibration and the other nuisance tangents remain unevaluated. The no-extra-HRF null is also nonregular and has not received a discovery-grade calibration.

## 1. First-order nuisance-quotient completion rule

Fix the measured products `s_j=tau*t_j` and use `lambda=ln(tau)` along their exact gauge orbit. Let a vector of proposed completion observables have mean

\[
\mathbf g(\lambda,\boldsymbol\eta),
\]

where `eta` contains every free trajectory, phase, amplitude-normalization, calibration, onset, remnant, or waveform nuisance. Define

\[
\mathbf q=\partial_\lambda\mathbf g\big|_{\mathbf s},
\qquad
B=\partial_{\boldsymbol\eta}\mathbf g.
\]

Within a regular fixed-covariance first-order mean model, positive nuisance-profiled Fisher information requires

\[
\boxed{\mathbf q\notin\operatorname{Col}(B).}
\]

The old `q != 0` rule is recovered only when there is no added nuisance direction. With completion covariance `K`, the efficient information is

\[
\boxed{
I_{\lambda,\mathrm{eff}}
=
\mathbf q^T
\left[K^{-1}-K^{-1}B(B^TK^{-1}B)^+B^TK^{-1}\right]
\mathbf q .
}
\]

This is zero exactly when nuisance motion absorbs the branch tangent. It is a local rank/information gate and does not rule out higher-order identification or covariance-derivative information.

Global identification is stronger. Define the nuisance-image set

\[
\mathcal M_\tau
=
\{\mathbf g(\tau,\mathbf s/\tau,\boldsymbol\eta):
\boldsymbol\eta\in\mathcal H\}.
\]

Whenever `M_tau_p` and `M_tau_g` intersect, at least one pair of nuisance configurations is exactly aliased (assuming the same noise law), so the branch-family map is noninjective. Comparing two fixed nuisance points is therefore insufficient. v71 additionally requires a positive minimum Mahalanobis separation as a conservative uniform-margin gate; this is stronger than pointwise injectivity unless the nuisance images are closed and compact.

This formalizes the v69 free-amplitude result and the v70 direct-wave warning. For

\[
\widehat\kappa=\frac{2\beta_{\rm traj}}{1+\beta_{\rm traj}}\kappa,
\]

a free `beta_traj` supplies a nuisance direction. The neighboring branch can be compensated by only about a `0.65–0.87%` change in `beta_traj` for `beta_traj=0.5–1`; an ordinary broad trajectory prior leaves the branch image sets overlapping. Any preference from such a lane is trajectory-prior supplied.

## 2. Likelihood-only branch separation

For positive product and anchor estimates, work in log coordinates

\[
x_j=\ln\widehat s_j,
\qquad y_j=\ln\widehat t_j,
\qquad z_j=x_j-y_j.
\]

If their joint log-error covariance is

\[
\Omega=\begin{pmatrix}A&C\\C^T&B\end{pmatrix},
\]

then

\[
Q=A+B-C-C^T,
\qquad
q_{\rm eff}^2=(\mathbf1^TQ^{-1}\mathbf1)^{-1}.
\]

For the old physical and grid branches,

\[
\Delta=\ln\frac{\tau_p}{\tau_g}=0.004355437628170275,
\qquad
D=\frac{\Delta}{q_{\rm eff}}.
\]

For two fully specified simple branches, the exact stipulated log-Gaussian model gives the log likelihood ratio—also the Bayes factor for those two simple hypotheses—

\[
\ln BF_{p/g}\sim N(D^2/2,D^2).
\]

The resulting **likelihood-only** precision screens are:

| Requirement | Maximum `q_eff` |
|---|---:|
| geometric-mean BF >= 3 | 0.293828944% |
| geometric-mean BF >= 10 | 0.202959300% |
| geometric-mean BF >= 100 | 0.143513897% |
| correct BF sign >= 90% | 0.169928302% |
| correct BF sign >= 95% | 0.132395903% |
| `P(BF>10)>=90%` | 0.115190902% |

The last row is the strict v71 feasibility gate, `D>=3.781060438`. Branch prior odds are not part of a Bayes factor. This likelihood-only gate also excludes the small flat-`t` nuisance-prior/Jacobian contribution used in v69–v70; such contributions are reported separately and cannot satisfy the data gate.

The `t_K` distributions used below are project-defined transforms of official remnant mass–spin posterior draws; LVK did not release `t_K` as an independent timescale measurement. Their log standard deviations are same-event posterior-width diagnostics, not automatically sampling-likelihood errors, and cannot be inserted as external anchors without prior removal and double-counting control.

## 3. Exact covariance-rescue envelope

For one event, let `alpha` be fractional product width, `b` fractional anchor width, and `varrho` their correlation. Then

\[
q^2=\alpha^2+b^2-2\varrho\alpha b.
\]

Positive-semidefinite covariance implies the exact bound

\[
\boxed{q_{\min}=|\alpha-b|.}
\]

A target `q_*` is reachable only if

\[
|\alpha-b|\le q_*,
\]

and then requires

\[
\varrho\ge
\frac{\alpha^2+b^2-q_*^2}{2\alpha b}.
\]

If `alpha` can be tuned, the minimum correlation is

\[
\varrho_{\min}=\sqrt{1-(q_*/b)^2}
\]

at `alpha=varrho*b`.

For the narrowest project-`t_K` log-width diagnostic derived from official remnant-posterior draws, NRSur7dq4 `b_log=1.192580322%` (the v70 linear `sigma_t/T_ref` comparison is `1.182237571%`):

- geometric-BF10 feasibility requires `alpha=0.989621–1.395540%` and optimally `varrho>=0.985412`;
- the strict `P(BF>10)>=90%` gate requires `alpha=1.077389–1.307771%` and optimally `varrho>=0.995324`.

The other waveform families require strict optimal correlations `0.99623–0.99738`. Marginal widths alone can neither prove nor exclude this rescue, because a nearly singular matched common mode can make a ratio unusually precise. The covariance must be measured in a valid joint model and survive nuisance/systematic stress tests.

## 4. Current carrier geometry is outside the rescue band

The exact 512-bin v65 base-carrier point-template geometry gives a profiled local product-width proxy

\[
\alpha\simeq\frac{2.43597}{\rho_{\rm template}}.
\]

This is an unwhitened synthetic full-template Fisher context, not a PSD-weighted GW250114 result. At the event-scale `~10%` width, inserting this local linearized proxy into a log-error envelope is only a scale-feasibility diagnostic, not an exact sampling distribution.

At the optimistic complete direct-wave network SNR `23.282`, `alpha=10.463%`. Even perfect positive covariance with the narrowest project-`t_K` log-width diagnostic leaves `q>=9.270%`. At the optimistic full-event SNR `80`, `alpha=3.045%` and `q>=1.453–1.852%` across waveform families. Both are far above `0.202959%`.

For NRSur7dq4, merely entering the BF10 variance-matching band would require full-template SNR approximately `175–246`; the strict band requires approximately `186–226`, while still demanding correlation above `0.995` for the strict gate. Therefore:

```text
CURRENT_SURROGATE_COVARIANCE_RESCUE_INFEASIBLE_AT_EVENT_SNR
```

This does not replace a real joint likelihood. It is an optimistic feasibility screen.

## 5. Catalog and systematic-floor theorem

For a catalog with covariance `Q`,

\[
q_{\rm eff}^2=(\mathbf1^TQ^{-1}\mathbf1)^{-1}.
\]

If the event-specific ratio residuals are mutually independent, and an independent scalar common mode has variance `c_sys^2` with equal unit loading in every event,

\[
\boxed{
q_{\rm eff}^2=c_{\rm sys}^2+\left(\sum_j u_j^{-2}\right)^{-1}.
}
\]

No catalog size can pass a target if `c_sys>=q_*`. Using the log-consistent NR posterior-width diagnostic with zero common floor, hypothetical independent anchored events would require `35` events for geometric BF10, `50` for 90% sign, `82` for 95% sign, and `108` for the strict gate. Using v70's linear `sigma_t/T_ref` proxy instead gives `34/49/80/106`; both are diagnostics, not forecasts. The four waveform families are alternative analyses of one event and must not be stacked.

Covariance does not control deterministic bias. The exact half log-branch gap is

\[
\frac\Delta2=0.217771881\%,
\]

equivalent to `6.933 microseconds` at the old reference time. With `Delta=theta_p-theta_g>0` and an additive log-ratio bias `u`, the true upper/physical branch reaches the wrong side of the midpoint when `u<=-Delta/2`. A sign-robust guarantee for either branch therefore requires `|u|<Delta/2`. SNR or catalog stacking cannot repair an admitted adverse bias beyond the relevant midpoint. The observed waveform-family spread remains a sensitivity diagnostic, not a calibrated bias bound.

## 6. Released direct-wave chain: cached-sample decomposition passes, inference gates fail

The Nature companion supplies `160000=5000x32` rows for `(A_real,A_imag,delta_t)`, their log posterior, and per-detector optimal/matched-filter SNRs. For detector `i`,

\[
\Delta\ln L_i
=
\rho_{{\rm mf},i}\rho_{{\rm opt},i}
-\frac12\rho_{{\rm opt},i}^2.
\]

The released cache satisfies

\[
\ln p-(\Delta\ln L_{H1}+\Delta\ln L_{L1})
=-1828.9620724151
\]

with centered standard deviation `8.05e-11`. Thus the released SNR columns reproduce the relative network log probability at the cached samples, up to a constant. This identity does not reconstruct a detector likelihood surface or its absolute normalization.

The released ensemble chain fails the v71 convergence-admission screen. Treating each interacting `emcee` walker as a chain is a diagnostic rather than a proof of nonconvergence. At 20% burn-in, the walker-as-chain rank-normalized folded split-Rhat is:

| Quantity | Rhat |
|---|---:|
| `A_real` | 1.3084 |
| `A_imag` | 1.2877 |
| `delta_t` | 1.4153 |
| log posterior | 1.2247 |

The gate is `Rhat<=1.01`, and every burn schedule from 0% through 50% fails. Full-chain walker acceptance ranges from `0.0206` to `0.3883`.

Removing the held-out detector likelihood by importance weighting also fails:

| Reconstruction | Sample concentration ESS | Walker ESS | Largest walker mass |
|---|---:|---:|---:|
| H1-only, remove L1 | 2291.47 / 128000 | 2.485 | 46.856% |
| L1-only, remove H1 | 881.66 / 128000 | ~1.000 | 99.99999% |

The sample ESS ignores MCMC autocorrelation and is optimistic. The walker concentration is sufficient to reject these clouds under the declared direct-importance admission screen. They are not admitted detector-only posteriors.

## 7. CBC direct-importance deconditioning is not admitted

All four LVK posterior files contain H1/L1 likelihood fields. Formally attempting both detector targets for every family—eight direct-importance targets in total—gives ESS values only `2.97–68.47` out of roughly `19990`, with individual samples carrying up to about `58%` of the weight. In addition, `logL_network-logL_H1-logL_L1` is not constant, so the stored fields do not define an admitted factorization into standalone detector likelihoods.

These are direct-importance semantics/support diagnostics, not detector-only posterior estimates and not a theorem that every possible bridge or new inference must fail. Raw detector-specific remnant inference is required for the proposed detector lane.

The companion also labels the released-draw proxy `argmax(log_likelihood+log_prior)` as “maximum likelihood”; it is a maximum-posterior-density draw proxy. Among the released NRSur7dq4 draws, this gives `t_K=3.146632 ms`, while the maximum-log-likelihood draw gives `3.135910 ms`, a `0.3419%` shift—about `78%` of the old neighboring-branch separation. These are sample maxima, not continuous optimizer solutions. Draw-proxy, sky/time, calibration, and PSD choices must enter the sensitivity gate.

## 8. Nonregular no-extra-HRF null

Write the extra HRF modulation as

\[
H(f;s,r)=1+r e^{-i\pi f s}.
\]

At the standard-GR/no-extra-HRF null `r=0`,

\[
\partial_sH=-i\pi f r e^{-i\pi f s}=0.
\]

The delay `s` is absent and its Fisher information is exactly zero. Standard Wilks chi-square calibration is not justified for a likelihood ratio maximized over `s`, start time, carrier, QNM choices, or waveform families.

The mandatory hypothesis ladder is now:

1. standard-GR/no-extra-HRF versus free-`s` HRF detection, calibrated by GR/off-source/time-slide/injection ensembles;
2. branch selection conditional on an admitted HRF detection and observable completion;
3. `ln(4)` against a preregistered composite lattice and continuous-`tau` alternatives with global multiplicity control;
4. physical interpretation only after all earlier gates pass.

The old two-point `D>0` statistic is only a conditional step-2 method gate. It cannot establish steps 1 or 3.

Under an iid Bernoulli control model with the statistic and threshold frozen before the held-out controls, the v67 `0/128` result has an exact 95% Clopper–Pearson upper false-positive rate of `2.313%`. Under those same assumptions, zero failures require at least `299` controls merely to bound FPR below `1%` and `2995` below `0.1%`, before accounting for scan trials. Discovery calibration requires much more.

## 9. Generative waveform contract remains missing

Before a real PSD-weighted HRF likelihood, the program must specify exactly which physical component the transfer multiplies: full IMR, QNM-filtered residual, or analytic direct wave. It must also fix onset, taper, Fourier convention, the fact that `exp(-i*pi*f*s)` corresponds to copy delay `s/2`, Hermitian symmetry for a real time-domain waveform, zero padding/noncircular delay handling, complex amplitude/phase, detector projection, QNM subtraction, calibration, and noise likelihood. Every alternative-only continuous parameter needs a normalized prior measure, search bounds, parameterization, and Jacobian; every discrete carrier/QNM/waveform choice needs a declared prior weight or a frequentist multiplicity rule.

Without that contract, a numerically reproducible likelihood can still be physically undefined. The Nature analytic trajectory is one conditional carrier lane, not a universal carrier.

## 10. Updated decision

| Gate | v71 status |
|---|---|
| v70 parent and official cache identity | Pass |
| Nuisance-quotient local completion | Not established |
| Global nuisance-image separation | Not established |
| Current carrier covariance rescue at event SNR | Infeasible in audited proxy |
| Direct-wave cached-sample relative-log-probability decomposition | Pass |
| Released direct-wave walker-as-chain Rhat admission screen | Fail; not by itself proof of nonconvergence |
| Direct-wave network-to-detector direct-importance support | Fail |
| CBC network-posterior direct-importance targets | Not admitted: nonadditive stored fields and support fail |
| Detector-separated `f-tau` cache | Absent |
| Nonregular HRF-vs-GR calibration | Not executed |
| Generative waveform contract | Incomplete |
| Joint product–anchor covariance | Not evaluated |
| Physical interpretation | Locked |

No discovery claim is made. No new Zenodo publication is recommended.
