# GW250114 HRF v71 — One-page certificate

**Claim class:** methods/admission control only. No HRF detection, branch discovery, area quantization, or quantum-horizon claim.

## Exact advances

- Positive first-order completion information with free nuisances requires `q not in Col(B)`, not only `q != 0`, in the declared regular fixed-covariance mean model.
- A robust global gate requires nonintersecting nuisance-image sets and positive separation; this is stronger than pointwise comparison.
- In log coordinates, `Q=A+B-C-C^T` and `q_eff^2=(1^T Q^-1 1)^-1`.
- Simple point-branch likelihood separation depends on `D=|ln(tau_p/tau_g)|/q_eff`; for two fully specified simple hypotheses, that likelihood ratio is also their Bayes factor. Branch prior odds are separate.
- Strict feasibility gate: `D>=3.781060438`, or `q_eff<=0.115190902%`, for `P(BF>10)>=90%` in the stipulated Gaussian model.
- One-event covariance rescue obeys `q>=|alpha-b|` and requires near-perfect correlation inside a narrow variance-matching band.
- A common catalog floor cannot be averaged down; an adverse signed bias, or a two-sided admitted bias set reaching half the log branch gap (`0.217772%`), defeats a uniform branch-classification guarantee at every SNR.

## Current GW250114 feasibility

- Narrowest log-width diagnostic from the project-defined `t_K` transform of official remnant-posterior draws: `1.19258%` (v70 linear `sigma_t/T_ref`: `1.18224%`). This is not an official LVK timescale measurement or an independent anchor likelihood.
- Strict optimal covariance rescue requires correlation `>=0.99532` and matched product width `1.07739–1.30777%`.
- Audited 512-bin base-carrier product proxy at full direct-wave SNR `23.282`: `10.463%`.
- Even perfect correlation then leaves at least `9.270%`: covariance rescue is infeasible in the current event-SNR proxy.

## Official detector audit

- Released H1/L1 cached-sample relative log-probability decomposition: **PASS** to `~1e-10` centered residual. This does not reconstruct a detector likelihood surface or its absolute normalization.
- Released `32x5000` chain: **FAILS v71 walker-as-chain convergence screen**; 20%-burn Rhat values `1.225–1.415`. This diagnostic is not by itself a proof of nonconvergence.
- H1-only direct-wave reweight: walker ESS `2.49`, largest walker `46.86%`.
- L1-only direct-wave reweight: walker ESS `~1`, largest walker `99.99999%`.
- All eight formal H1/L1 direct-importance targets across four CBC waveform families: **FAIL SUPPORT**, ESS only `2.97–68.47` of about `19990`.
- These directly weighted clouds are not admitted detector-only posteriors. The stored detector fields also do not add to the released network log likelihood by a constant, so raw detector-specific inference is required for a semantically defined target.
- NRSur released-draw maximum-posterior-density versus maximum-log-likelihood project-`t_K` shift: `0.3419%`, about `78%` of the neighboring-branch separation. These are sample maxima, not continuous optimizer solutions.

## Detection firewall

At no-extra-HRF amplitude `r=0`, the delay disappears and its Fisher information is zero. HRF detection is nonregular; standard Wilks chi-square calibration is not justified. The old `D>0` branch sign is conditional branch selection, not detection.

Required order:

```text
calibrated GR/no-extra-HRF vs free-delay HRF detection
-> nuisance-quotient and global-alias completion
-> ln(4) vs composite lattice + continuous alternatives
-> physical interpretation
```

## Verdict

```text
NUISANCE_QUOTIENT_COMPLETION_NOT_ESTABLISHED
CURRENT_SURROGATE_COVARIANCE_RESCUE_INFEASIBLE_AT_EVENT_SNR
NETWORK_POSTERIOR_DIRECT_IMPORTANCE_TARGET_NOT_ADMITTED
NONREGULAR_NULL_NOT_CALIBRATED
GENERATIVE_WAVEFORM_CONTRACT_INCOMPLETE
JOINT_PRODUCT_ANCHOR_COVARIANCE_NOT_EVALUATED
PHYSICAL_INTERPRETATION_LOCKED
```

No Zenodo update is recommended.
