# GW250114 HRF v71 — Raw replay environment audit

**Scope:** execution-readiness audit only. No raw direct-wave surface or LVK parameter-estimation replay was performed in v71.

## Released environment contract

The Nature companion provides `pixi.toml` requesting Python `3.11.*`, `gwpy`, `gwsurrogate`, Astropy below 6, SciPy below 1.15, and the bundled editable `qnm_filter` source. It does not provide `pixi.lock` or a frozen container.

The embedded `qnm_filter` source is pinned to commit:

```text
55f14436d4ea510b71754b95da9701009e8a1c12
```

## Current execution environment

- runtime Python is 3.12 rather than the requested 3.11 lane;
- `pixi`, Conda, and Micromamba are unavailable;
- `gwpy`, `gwsurrogate`, `bilby`, `astropy`, `qnm`, and LALSuite are not installed in the base runtime;
- the NRSur7dq4 surrogate asset is not bundled with the companion;
- local NumPy/Matplotlib/h5py support is sufficient for the v71 cache and HDF5 audits, but not for the released raw pipeline.

Therefore:

```text
RAW_DETECTOR_SURFACE_ENVIRONMENT_BLOCKED_NO_LOCKED_PY311_ENVIRONMENT
```

## Scientific limitations beyond packaging

Even a successful reproduction of H1-only/L1-only direct-wave surfaces would remain conditional on a network remnant point unless detector-specific remnant/QNM inference is also performed. The audited direct-importance reuse of the public discovery posterior has inadequate support and mismatched network-likelihood semantics, so it does not yield admitted detector-only posteriors; the discovery PE configuration also refers to cleaned frame/channel products not byte-identical to the public GWOSC AR01 strain.

The raw lane must also add:

- MAP-versus-ML sensitivity;
- alternate PSD/ACF windows and stationarity tests;
- DQ and hardware-injection frequency checks;
- detector likelihood additivity;
- calibration and QNM-mode stress tests;
- the v71 generative waveform contract;
- nonregular null calibration.

Absence of the locked environment is an execution blocker, not evidence for or against the physical hypothesis.
