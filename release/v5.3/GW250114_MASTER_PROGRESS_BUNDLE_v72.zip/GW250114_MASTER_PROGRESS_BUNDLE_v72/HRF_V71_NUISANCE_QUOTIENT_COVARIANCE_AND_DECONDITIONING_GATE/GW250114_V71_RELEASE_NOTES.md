# HRF v71 release notes

## Added

- Exact first-order nuisance-quotient information theorem and global nuisance-image alias test under their stated regularity conditions.
- Exact log-ratio covariance reduction and likelihood-only branch-power thresholds.
- Exact covariance-rescue feasibility, variance-matching, common-floor, and bias theorems.
- 512-bin/8192-bin base-carrier product-Fisher feasibility audit.
- Cached-sample per-detector relative log-probability decomposition from released SNR columns; no detector likelihood surface or absolute normalization is reconstructed.
- Walker-as-chain rank-normalized folded split-Rhat, walker acceptance, and direct-importance concentration audits; the Rhat screen is an admission diagnostic, not by itself proof of nonconvergence.
- Eight formal H1/L1 direct-importance targets across four CBC network-posterior families, retained only as semantics/support diagnostics.
- Released-draw maximum-posterior-density versus maximum-log-likelihood project-`t_K` sensitivity audit.
- Direct-wave cache prior-coordinate sensitivity and 16-kHz DQ/injection-mask audit.
- Nonregular no-extra-HRF theorem and control-count calibration contract.
- Generative waveform contract for a future PSD-weighted HRF likelihood.

## Corrected or narrowed

- v70’s completion rule is generalized from `q!=0` to `q not in Col(B)` when added nuisances are free.
- v70’s flat-timescale Gaussian evidence formula is exact for the declared improper Lebesgue-flat measure on `R^N`. A broad finite or positive-time uniform prior is only an approximation when boundary mass is negligible; general priors retain the explicit integral.
- Likelihood-only thresholds are separated from flat-`t` ridge Jacobian preferences.
- The companion’s released-draw `argmax(log_likelihood+log_prior)` choice is labeled a maximum-posterior-density draw proxy, not a continuous maximum-likelihood solution.
- v67’s 0/128 control result is labeled a conditional methods gate rather than discovery-grade calibration.

## Decision

The official cache yields a useful cached-sample relative log-probability identity but no admitted detector-only inference or joint HRF covariance. Physical interpretation remains locked. No Zenodo update is recommended.
