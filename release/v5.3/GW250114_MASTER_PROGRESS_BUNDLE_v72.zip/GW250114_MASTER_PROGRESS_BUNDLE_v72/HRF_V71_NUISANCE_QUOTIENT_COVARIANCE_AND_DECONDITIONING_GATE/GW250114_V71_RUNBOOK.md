# GW250114 HRF v71 runbook

## Inputs

Required for the strict v71 replay:

- canonical v70 standalone ZIP;
- Nature companion ZIP;
- all four official LVK posterior HDF5 files;
- H1/L1 discovery-v1 16-kHz GWOSC strain files for quality-mask validation.

The expected identities are frozen in the generator and copied to the validation table. Do not substitute GWTC-5.0 v2 products into this lane.

## Environment

```bash
python -m pip install -r requirements.txt
```

The released-chain and covariance calculations require NumPy; plots require Matplotlib; posterior and strain validation require h5py.

## Execute

```bash
python gw250114_v71_nuisance_covariance_gate.py \
  --v70-zip /path/to/HRF_V70_OFFICIAL_ANCHOR_EVOLVING_DECAY_AND_INDEPENDENT_BENCHMARK.zip \
  --input-dir /path/to/official_inputs \
  --outdir /path/to/v71_outputs \
  --strict
```

Strict mode must stop before downstream claims if any parent/input hash, manifest entry, cache shape, schema, or required field fails.

## Interpret in order

1. Confirm `GW250114_V71_input_validation.csv` passes.
2. Confirm the released cached-sample relative log-probability decomposition identity. This is not a reconstruction of the detector likelihood surfaces or their absolute normalizations.
3. Inspect every burn in `GW250114_V71_directwave_rank_folded_rhat.csv`; do not select a favorable burn after looking.
4. Inspect sample and walker concentration in the detector-reweight table.
5. Treat CBC deconditioning ESS only as a support diagnostic; never plot weighted rows as detector posteriors.
6. Inspect the covariance-rescue band and SNR-context table.
7. Apply nuisance-quotient and global-image tests before any precision claim.
8. Apply the nonregular-null and composite-alternative firewall before branch selection.

## Reproduction requirements

- fixed source date epoch for figures;
- identical 512-bin and 8192-bin carrier-proxy results;
- rank-normalized folded split-Rhat reproduced at all declared burns;
- chain likelihood decomposition centered residual below `1e-8`;
- all analytic target and projector self-tests pass;
- two fresh strict runs produce identical generated files.

## Prohibited interpretations

- Do not call the released chain converged or nonconverged from the walker-as-chain screen alone; it fails the declared admission screen.
- Do not call importance-weight concentration ESS an autocorrelation-corrected MCMC ESS.
- Do not call network-to-detector weighted rows valid single-detector posteriors.
- Do not count flat-`t` Jacobians as data information.
- Do not call the synthetic carrier proxy an official GW250114 likelihood.
- Do not treat two cross-fit directions as independent replications.
- Do not infer `ln(4)`, `g=4`, area quantization, or a quantum horizon.
