# Package provenance

**Canonical parent standalone:** `HRF_V70_OFFICIAL_ANCHOR_EVOLVING_DECAY_AND_INDEPENDENT_BENCHMARK.zip`  
SHA-256: `d340a44c476761c4a8d553cb703f6fe06c587199163e8136a9b369c01c160554`

**Canonical parent master:** `GW250114_MASTER_PROGRESS_BUNDLE_v70.zip`  
SHA-256: `2be632bb325febc93119180fa95aca23df73848383a366ae89abe9d672ba0ec9`

v70 is treated as the immutable parent. v71 changes no v70 file. It reads the v70 CSV/JSON products from the checksum-validated parent ZIP, reads released direct-wave arrays from the checksum-validated Nature ZIP, and reads official posterior/quality-mask products in place.

Official binaries are excluded from the distributed v71 archive. Their frozen byte identities, member identities, shapes, and schema checks are recorded in generated validation tables.
