# HRF v71 — Nuisance-quotient, covariance, and detector-deconditioning gate

**Project:** GW250114 Quantized Horizon Response / branch-control program  
**Version:** v71  
**Date:** 2026-07-11  
**Status:** methods and admission control only; **no detection or discovery claim**.

## Result

v71 closes four ambiguities left by v70.

1. In the declared regular fixed-covariance mean model, a nominal second observable has no positive first-order completion information when its branch derivative can be absorbed by free nuisance parameters. The branch tangent must survive the nuisance quotient for the first-order Fisher gate to pass.
2. Product–anchor covariance is not a free rescue. It can reach the old neighboring-branch precision only inside a narrow variance-matching band and with near-singular positive correlation.
3. Direct importance deconditioning of the released direct-wave chain and LVK network posteriors does not produce admitted H1-only/L1-only posteriors. The cached relative log-probability bookkeeping is informative, but the walker-as-chain convergence screen or direct-importance support gates fail.
4. Detecting an extra HRF component is a nonregular problem because the delay disappears when the HRF amplitude is zero. A conditional two-point branch sign is not an HRF detection statistic.

The physical branch remains locked.

```text
NUISANCE_QUOTIENT_COMPLETION_NOT_ESTABLISHED
CURRENT_SURROGATE_COVARIANCE_RESCUE_INFEASIBLE_AT_EVENT_SNR
DIRECTWAVE_CACHED_SAMPLE_RELATIVE_LOGPROB_DECOMPOSITION_PASS
RELEASED_WALKER_AS_CHAIN_RHAT_ADMISSION_FAIL
NETWORK_TO_SINGLE_DETECTOR_DIRECT_IMPORTANCE_SUPPORT_FAIL
CBC_NETWORK_POSTERIOR_DIRECT_IMPORTANCE_TARGET_NOT_ADMITTED
NONREGULAR_NULL_NOT_CALIBRATED
GENERATIVE_WAVEFORM_CONTRACT_INCOMPLETE
PHYSICAL_INTERPRETATION_LOCKED
```

## Read first

1. `GW250114_V71_ONE_PAGE_CERTIFICATE.md`
2. `GW250114_V71_NUISANCE_QUOTIENT_COVARIANCE_AND_DECONDITIONING_GATE.md`
3. `GW250114_V71_THEOREM_AND_PROOF.md`
4. `GW250114_V71_GENERATIVE_WAVEFORM_CONTRACT.md`
5. `GW250114_V71_RAW_REPLAY_ENVIRONMENT_AUDIT.md`
6. `GW250114_V71_gate_status.csv`
7. `GW250114_V71_FAIL_CLOSED_AUDIT.md`
8. `audits/GW250114_V71_REPRODUCIBILITY_AUDIT.md`
9. `GW250114_V71_NEXT_TASK.md`

## Reproduce

```bash
python gw250114_v71_nuisance_covariance_gate.py \
  --v70-zip HRF_V70_OFFICIAL_ANCHOR_EVOLVING_DECAY_AND_INDEPENDENT_BENCHMARK.zip \
  --input-dir official_inputs \
  --outdir reproduced_outputs \
  --strict
```

The generator reads the released chain arrays directly from the checksum-validated Nature ZIP and reads the four official posterior files and 16-kHz quality masks in place. Official binaries are not included in this package.

## Decision

No real `ln(4)`, `g=4`, area-quantization, black-hole microstate, or quantum-horizon inference is admitted. No Zenodo update is recommended from v71 alone.
