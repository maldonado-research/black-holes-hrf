# Reference-only triage

The attached ToE, HDBLAST, antimatter, dark-sector, and historical chat archives were not used as physical inputs to v71.

v71 imports no cosmological, flavor, dark-sector, FTL, PTA, higher-dimensional-blast, or cross-project parameter relation. The canonical scientific parent is the supplied v70 HRF/GW250114 bundle. Other materials remain reference-only unless a future black-hole task states a distinct observable, nuisance map, and falsifiable gate.
