# Sources frozen for HRF v71

## Primary public releases

- Lu, Ma, Piccinni, Chen, and Sun, “GW250114 reveals signatures of post-merger black-hole horizon,” *Nature* (2026): https://www.nature.com/articles/s41586-026-10696-0
- Nature data/code companion, Zenodo record 20017347: https://zenodo.org/records/20017347
- Author preprint and supplement, arXiv:2510.01001v3: https://arxiv.org/abs/2510.01001v3
- LVK GW250114 discovery figure/data release, Zenodo record 16877102: https://zenodo.org/records/16877102
- GWOSC discovery-v1 event page: https://gwosc.org/eventapi/html/O4_Discovery_Papers/GW250114_082203/v1/
- GWOSC discovery-v1 event JSON: https://gwosc.org/eventapi/json/O4_Discovery_Papers/GW250114_082203/v1/

## Model-firewall reference

- Kankani and McWilliams, “The Direct Wave is Not a Meaningful Test of Horizon Properties,” arXiv:2607.02380v1: https://arxiv.org/abs/2607.02380v1

## Statistical-method references

- Vehtari, Gelman, Simpson, Carpenter, and Bürkner, “Rank-normalization, folding, and localization: An improved R-hat for assessing convergence of MCMC,” *Bayesian Analysis* 16 (2021): https://doi.org/10.1214/20-BA1221
- Davies, “Hypothesis testing when a nuisance parameter is present only under the alternative,” *Biometrika* 64 (1977): https://doi.org/10.1093/biomet/64.2.247
- Self and Liang, “Asymptotic properties of maximum likelihood estimators and likelihood ratio tests under nonstandard conditions,” *JASA* 82 (1987): https://doi.org/10.1080/01621459.1987.10478472

## Frozen code/data identities

- Nature ZIP SHA-256: `752eb33b21ee1a332ad7282eb5ddee695d6cc1ec2859120c779e17fbfcd7c862`
- released `samples.npy`: `37db1caf151bb4e7e676f6ffde9c6a471752b4c606048d5f7e7cd80469e57937`
- released `samples_log_prob.npy`: `ed9156ad32285f24ade9a9f5f255417320ef8e7fcc743cf95d247e198dd2a2b8`
- released `sample_SNRs.npy`: `8651dc0db18bb0f08d4d4b19aa313f853443380fc1fccc13285ec7fe67174438`
- embedded `qnm_filter` commit: `55f14436d4ea510b71754b95da9701009e8a1c12`
- GWOSC lane: `O4_Discovery_Papers/GW250114_082203/v1`

The package contains derived summaries, code, and local reproducibility hashes—not the official binaries.
