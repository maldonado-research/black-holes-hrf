# GW250114 HRF v71 reproducibility audit

**Date:** 2026-07-11

- Independent fresh strict runs: `2`
- Generated files per run: `24`
- Strict computational self-tests per run: `21/21`
- Same filename set: `True`
- Run-to-run bit-for-bit identity: `True`
- Included generated outputs equal fresh replay: `True`
- Differences: `[]`

Both runs used the checksum/manifest-validated v70 parent, checksum-validated Nature ZIP, all four frozen posterior HDF5 files, both frozen 16-kHz strain files, and `SOURCE_DATE_EPOCH=1783785600`.

Final generator SHA-256: `2ed63a04a26b8cc79975a45dad30e2cda72d5c271d595d0586c2d12e24d6edb1`.

The official binaries are not part of the package. Their identities and structural checks are recorded in `GW250114_V71_input_validation.csv`.
