#!/usr/bin/env python3
"""GW250114 HRF v71 nuisance-quotient covariance/deconditioning gate.

Methods and admission control only.  This program does not claim an HRF
detection, area quantization, a quantum horizon, or a failure of GR.

The calculation deliberately separates four questions which are often mixed:

* integrity of the frozen v70 and official products;
* likelihood-only separation of the two historical point branches;
* whether product/anchor covariance could *in principle* rescue the quotient;
* whether the released network posterior products can support a detector split.

The carrier Fisher calculations are synthetic, unwhitened geometry proxies.
The released direct-wave chain diagnostics audit a cached network posterior;
they are not a replacement for a raw-strain, detector-separated likelihood.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import math
import statistics
import sys
import zipfile
from pathlib import Path
from typing import Any, Iterable

import h5py
import matplotlib.pyplot as plt
import numpy as np


VERSION = "GW250114_HRF_v71"
DATE = "2026-07-11"
STATUS = "METHODS_ONLY_NO_DETECTION"

V70_ZIP_NAME = "HRF_V70_OFFICIAL_ANCHOR_EVOLVING_DECAY_AND_INDEPENDENT_BENCHMARK.zip"
V70_ZIP_SHA256 = "d340a44c476761c4a8d553cb703f6fe06c587199163e8136a9b369c01c160554"
V70_MANIFEST = "GW250114_V70_manifest.json"

NATURE_ZIP = "GW250114_horizon_signatures.zip"
NATURE_SIZE = 53_049_832
NATURE_SHA256 = "752eb33b21ee1a332ad7282eb5ddee695d6cc1ec2859120c779e17fbfcd7c862"

POSTERIOR_SPEC = {
    "posterior_samples_NRSur7dq4.h5": (26_958_665, "55b4a47c2c71580e9ef0cd1ff9fa9d32e64813657e9ea31f32e24cda53922d62", "NRSur7dq4"),
    "posterior_samples_PhenomXO4a.h5": (26_797_216, "dc35655ff0cecc932b9c95e7e675bc9a43a31e2ac5dbb57f07b6a59f0efa92e7", "PhenomXO4a"),
    "posterior_samples_PhenomXPHM.h5": (26_799_792, "cb1b40416360587b12e52cd2a0e99bf9b9c38917db8f0fece08a0d47c8f04585", "PhenomXPHM"),
    "posterior_samples_SEOBNRv5PHM.h5": (26_798_088, "c7da6eb05f255bf7af3c4c03b3bce1af9d755e6b7e955f6c9d438f086b3ec125", "SEOBNRv5PHM"),
}

STRAIN_SPEC = {
    "H-H1_GWOSC_O4b_16KHZ_R1-1420877824-4096.hdf5": {
        "detector": "H1", "size": 162_063_585,
        "sha256": "23e20dda953d2ede852f4991c018b0f1128f35f2cec7153d835a312be363d19d",
    },
    "L-L1_GWOSC_O4b_16KHZ_R1-1420877824-4096.hdf5": {
        "detector": "L1", "size": 160_795_119,
        "sha256": "355dbcaece2b63b5ded9aa353e34b59a672edfd7845b0aa1b9bf73c5439bb825",
    },
}

CHAIN_MEMBERS = {
    "samples": "GW250114_horizon_signatures/fig_2_6/data/samples.npy",
    "log_prob": "GW250114_horizon_signatures/fig_2_6/data/samples_log_prob.npy",
    "snrs": "GW250114_horizon_signatures/fig_2_6/data/sample_SNRs.npy",
}
CHAIN_EXPECTED_SHA256 = {
    "samples": "37db1caf151bb4e7e676f6ffde9c6a471752b4c606048d5f7e7cd80469e57937",
    "log_prob": "ed9156ad32285f24ade9a9f5f255417320ef8e7fcc743cf95d247e198dd2a2b8",
    "snrs": "8651dc0db18bb0f08d4d4b19aa313f853443380fc1fccc13285ec7fe67174438",
}

LN4 = math.log(4.0)
T_REF_S = 0.003183821
TAU_GRID = 2.0 * 9.0 / (4096.0 * T_REF_S)
T_GRID_S = T_REF_S * LN4 / TAU_GRID
BRANCH_RELATIVE_T_GAP = T_GRID_S / T_REF_S - 1.0
BRANCH_LOG_T_GAP = abs(math.log(T_GRID_S / T_REF_S))
RHO_FIXED = 0.25
MTSUN_S = 4.9254909476412675e-6
DIRECT_WAVE_NETWORK_SNR = math.hypot(15.8, 17.1)
NORMAL = statistics.NormalDist()
BURN_SCHEDULE = (0, 50, 100, 200, 500, 1000, 1500, 2500)
FROZEN_PRIMARY_BURN_STEPS = 1000


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def file_hash(path: Path, algorithm: str = "sha256") -> str:
    h = hashlib.new(algorithm)
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        path.write_text("")
        return
    fields: list[str] = []
    for row in rows:
        for key in row:
            if key not in fields:
                fields.append(key)
    with path.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def csv_from_zip(archive: zipfile.ZipFile, suffix: str) -> list[dict[str, str]]:
    names = [n for n in archive.namelist() if n.endswith("/" + suffix) or n == suffix]
    if len(names) != 1:
        raise ValueError(f"expected exactly one {suffix}; found {len(names)}")
    text = archive.read(names[0]).decode("utf-8")
    return list(csv.DictReader(io.StringIO(text)))


def member_from_zip(archive: zipfile.ZipFile, suffix: str) -> tuple[str, bytes]:
    names = [n for n in archive.namelist() if n.endswith("/" + suffix) or n == suffix]
    if len(names) != 1:
        raise ValueError(f"expected exactly one {suffix}; found {len(names)}")
    return names[0], archive.read(names[0])


def validate_v70(path: Path) -> dict[str, Any]:
    row: dict[str, Any] = {
        "input_class": "canonical_parent",
        "filename": path.name,
        "expected_sha256": V70_ZIP_SHA256,
        "present": path.is_file(),
    }
    if not path.is_file():
        row.update(status="FAIL_MISSING", checksum_ok=False, schema_ok=False)
        return row
    row["actual_sha256"] = file_hash(path)
    row["checksum_ok"] = row["actual_sha256"] == V70_ZIP_SHA256
    try:
        with zipfile.ZipFile(path) as archive:
            row["zip_crc_ok"] = archive.testzip() is None
            manifest_name, payload = member_from_zip(archive, V70_MANIFEST)
            manifest = json.loads(payload)
            prefix = manifest_name[: -len(V70_MANIFEST)]
            expected: dict[str, tuple[int, str]] = {
                item["path"]: (int(item["bytes"]), str(item["sha256"]))
                for item in manifest["files"]
            }
            actual_names = {
                n[len(prefix):] for n in archive.namelist()
                if n.startswith(prefix) and not n.endswith("/") and n != manifest_name
            }
            mismatches: list[str] = []
            for rel, (size, digest) in expected.items():
                full = prefix + rel
                try:
                    data = archive.read(full)
                except KeyError:
                    mismatches.append(rel + ":missing")
                    continue
                if len(data) != size or sha256_bytes(data) != digest:
                    mismatches.append(rel + ":size_or_hash")
            set_ok = actual_names == set(expected)
            count_ok = int(manifest.get("file_count", -1)) == len(expected)
            row.update(
                manifest_member=manifest_name,
                manifest_entries=len(expected),
                manifest_hash_mismatches=len(mismatches),
                manifest_exact_member_set=set_ok,
                manifest_count_ok=count_ok,
                schema_ok=bool(row["zip_crc_ok"] and not mismatches and set_ok and count_ok),
            )
    except Exception as exc:
        row.update(schema_ok=False, error=f"{type(exc).__name__}: {exc}")
    passed = bool(row.get("checksum_ok") and row.get("schema_ok"))
    row["status"] = "PASS" if passed else "FAIL_INTEGRITY_OR_MANIFEST"
    return row


def find_posterior_dataset(handle: h5py.File) -> tuple[str, h5py.Dataset]:
    found: list[tuple[str, h5py.Dataset]] = []
    for root_name in handle.keys():
        root = handle[root_name]
        if isinstance(root, h5py.Group) and "posterior_samples" in root:
            obj = root["posterior_samples"]
            if isinstance(obj, h5py.Dataset):
                found.append((f"{root_name}/posterior_samples", obj))
    if len(found) != 1:
        raise ValueError(f"expected one posterior_samples dataset, found {len(found)}")
    return found[0]


def validate_posterior(path: Path) -> dict[str, Any]:
    size, digest, family = POSTERIOR_SPEC[path.name]
    row: dict[str, Any] = {
        "input_class": "waveform_posterior", "filename": path.name,
        "waveform_family": family, "present": path.is_file(),
        "expected_size": size, "expected_sha256": digest,
    }
    if not path.is_file():
        row.update(status="FAIL_MISSING", checksum_ok=False, schema_ok=False)
        return row
    row["actual_size"] = path.stat().st_size
    row["actual_sha256"] = file_hash(path)
    row["checksum_ok"] = row["actual_sha256"] == digest and row["actual_size"] == size
    try:
        with h5py.File(path, "r") as handle:
            dataset_path, ds = find_posterior_dataset(handle)
            names = set(ds.dtype.names or ())
            required = {"log_likelihood", "log_prior"}
            mass_ok = "final_mass" in names or "final_mass_non_evolved" in names
            spin_ok = "final_spin" in names or "final_spin_non_evolved" in names
            row.update(dataset_path=dataset_path, n_draws=len(ds), n_fields=len(names))
            row["schema_ok"] = bool(len(ds) > 1000 and required <= names and mass_ok and spin_ok)
    except Exception as exc:
        row.update(schema_ok=False, error=f"{type(exc).__name__}: {exc}")
    row["status"] = "PASS" if row.get("checksum_ok") and row.get("schema_ok") else "FAIL_INTEGRITY_OR_SCHEMA"
    return row


def _decode_array(values: np.ndarray) -> list[str]:
    return [v.decode("utf-8") if isinstance(v, (bytes, np.bytes_)) else str(v) for v in values]


def validate_strain(path: Path) -> dict[str, Any]:
    spec = STRAIN_SPEC[path.name]
    row: dict[str, Any] = {
        "input_class": "gwosc_16khz_strain", "filename": path.name,
        "detector": spec["detector"], "present": path.is_file(),
        "expected_size": spec["size"], "expected_sha256": spec["sha256"],
    }
    if not path.is_file():
        row.update(status="FAIL_MISSING", checksum_ok=False, schema_ok=False)
        return row
    row["actual_size"] = path.stat().st_size
    row["actual_sha256"] = file_hash(path)
    row["checksum_ok"] = row["actual_size"] == spec["size"] and row["actual_sha256"] == spec["sha256"]
    try:
        with h5py.File(path, "r") as handle:
            strain = handle["strain/Strain"]
            dq = handle["quality/simple/DQmask"]
            inj = handle["quality/injections/Injmask"]
            dq_names = _decode_array(handle["quality/simple/DQShortnames"][:])
            inj_names = _decode_array(handle["quality/injections/InjShortnames"][:])
            detector_meta_raw = handle["meta/Detector"][()]
            detector_meta = detector_meta_raw.decode("utf-8") if isinstance(detector_meta_raw, bytes) else str(detector_meta_raw)
            spacing = float(strain.attrs["Xspacing"])
            schema_ok = (
                strain.shape == (67_108_864,) and strain.dtype == np.dtype("float64")
                and abs(spacing - 1.0 / 16384.0) < 1e-15
                and dq.shape == (4096,) and inj.shape == (4096,)
                and int(dq.attrs["Bits"]) == 9 and int(inj.attrs["Bits"]) == 5
                and detector_meta == spec["detector"]
                and dq_names == ["DATA", "CBC_CAT1", "CBC_CAT2", "CBC_CAT3", "BURST_CAT1", "BURST_CAT2", "BURST_CAT3", "STOCH_CAT1", "CW_CAT1"]
                and inj_names == ["NO_CBC_HW_INJ", "NO_BURST_HW_INJ", "NO_DETCHAR_HW_INJ", "NO_CW_HW_INJ", "NO_STOCH_HW_INJ"]
            )
            row.update(
                strain_points=int(strain.shape[0]), sample_rate_hz=1.0 / spacing,
                gps_start=int(strain.attrs["Xstart"]), dq_points=int(dq.shape[0]),
                injection_points=int(inj.shape[0]), detector_metadata=detector_meta,
                dq_shortnames="|".join(dq_names), injection_shortnames="|".join(inj_names),
                schema_ok=bool(schema_ok),
            )
    except Exception as exc:
        row.update(schema_ok=False, error=f"{type(exc).__name__}: {exc}")
    row["status"] = "PASS" if row.get("checksum_ok") and row.get("schema_ok") else "FAIL_INTEGRITY_OR_SCHEMA"
    return row


def validate_nature(path: Path) -> dict[str, Any]:
    row: dict[str, Any] = {
        "input_class": "nature_companion", "filename": path.name,
        "present": path.is_file(), "expected_size": NATURE_SIZE,
        "expected_sha256": NATURE_SHA256,
    }
    if not path.is_file():
        row.update(status="FAIL_MISSING", checksum_ok=False, schema_ok=False)
        return row
    row["actual_size"] = path.stat().st_size
    row["actual_sha256"] = file_hash(path)
    row["checksum_ok"] = row["actual_size"] == NATURE_SIZE and row["actual_sha256"] == NATURE_SHA256
    mandatory = set(CHAIN_MEMBERS.values()) | {
        "GW250114_horizon_signatures/fig_2_6/DW_fitting_and_SNR.py",
        "GW250114_horizon_signatures/fig_5/checking_analysis.py",
    }
    try:
        with zipfile.ZipFile(path) as archive:
            names = set(archive.namelist())
            member_hash_ok = all(
                sha256_bytes(archive.read(CHAIN_MEMBERS[key])) == CHAIN_EXPECTED_SHA256[key]
                for key in CHAIN_MEMBERS
            )
            row.update(
                zip_crc_ok=archive.testzip() is None,
                mandatory_members_present=mandatory <= names,
                frozen_chain_member_hashes_ok=member_hash_ok,
                member_count=len(names),
            )
            row["schema_ok"] = bool(row["zip_crc_ok"] and row["mandatory_members_present"] and member_hash_ok)
    except Exception as exc:
        row.update(schema_ok=False, error=f"{type(exc).__name__}: {exc}")
    row["status"] = "PASS" if row.get("checksum_ok") and row.get("schema_ok") else "FAIL_INTEGRITY_OR_SCHEMA"
    return row


def likelihood_only_thresholds() -> list[dict[str, Any]]:
    # The quotient theorem is exact in x=log(tau)=log(s)-log(t).  Use the
    # point-hypothesis distance in that coordinate, not a linearized percent.
    delta = BRANCH_LOG_T_GAP
    rows: list[dict[str, Any]] = []
    for target in (3.0, 10.0, 100.0):
        sigma = delta / math.sqrt(2.0 * math.log(target))
        rows.append({
            "criterion": f"E_log_likelihood_ratio>=ln({target:g})",
            "threshold_log_likelihood_ratio": math.log(target),
            "max_sigma_quotient_relative": sigma,
            "max_sigma_quotient_percent": 100.0 * sigma,
            "prior_or_jacobian_term": 0.0,
            "coordinate": "log_quotient", "interpretation": "likelihood-only point-branch Gaussian benchmark; not evidence",
        })
    for probability, z in ((0.90, NORMAL.inv_cdf(0.90)), (0.95, NORMAL.inv_cdf(0.95))):
        sigma = delta / (2.0 * z)
        rows.append({
            "criterion": f"P(log_likelihood_ratio>0)>={probability:.2f}",
            "threshold_log_likelihood_ratio": 0.0,
            "max_sigma_quotient_relative": sigma,
            "max_sigma_quotient_percent": 100.0 * sigma,
            "prior_or_jacobian_term": 0.0,
            "coordinate": "log_quotient", "interpretation": "likelihood-only correct-sign benchmark; not evidence",
        })
    for target, probability in ((10.0, 0.90),):
        z = NORMAL.inv_cdf(probability)
        x = z + math.sqrt(z * z + 2.0 * math.log(target))
        sigma = delta / x
        rows.append({
            "criterion": f"P(log_likelihood_ratio>ln({target:g}))>={probability:.2f}",
            "threshold_log_likelihood_ratio": math.log(target),
            "max_sigma_quotient_relative": sigma,
            "max_sigma_quotient_percent": 100.0 * sigma,
            "prior_or_jacobian_term": 0.0,
            "coordinate": "log_quotient", "interpretation": "likelihood-only exceedance benchmark; not evidence",
        })
    return rows


def inherited_target_semantic_comparison(inherited: list[dict[str, str]],
                                         current: list[dict[str, Any]]) -> list[dict[str, Any]]:
    old_order = [
        "exp(E log BF)>=3", "exp(E log BF)>=10", "exp(E log BF)>=100",
        "P(BF>1)>=90%", "P(BF>1)>=95%", "P(BF>10)>=90%",
    ]
    new_order = [
        "E_log_likelihood_ratio>=ln(3)", "E_log_likelihood_ratio>=ln(10)",
        "E_log_likelihood_ratio>=ln(100)", "P(log_likelihood_ratio>0)>=0.90",
        "P(log_likelihood_ratio>0)>=0.95", "P(log_likelihood_ratio>ln(10))>=0.90",
    ]
    old_by_name = {r["requirement"]: r for r in inherited}
    new_by_name = {r["criterion"]: r for r in current}
    rows: list[dict[str, Any]] = []
    for old_name, new_name in zip(old_order, new_order):
        old = float(old_by_name[old_name]["max_sigma_t_over_t"])
        new = float(new_by_name[new_name]["max_sigma_quotient_relative"])
        rows.append({
            "v70_prior_inclusive_requirement": old_name,
            "v70_linear_sigma_t_over_t_target": old,
            "v71_likelihood_only_requirement": new_name,
            "v71_sigma_log_quotient_target": new,
            "v71_over_v70": new/old,
            "semantic_change": "v71 removes the branch Jacobian/prior term and uses the exact log-quotient coordinate",
            "interpretation": "comparison of benchmarks, not a data result",
        })
    return rows


def project_tk_log_widths_from_official_remnant_draws(input_dir: Path, v70_width_rows: list[dict[str, str]]) -> list[dict[str, Any]]:
    comparison = {row["waveform_family"]: row for row in v70_width_rows}
    rows: list[dict[str, Any]] = []
    for filename, (_, _, family) in POSTERIOR_SPEC.items():
        with h5py.File(input_dir/filename, "r") as handle:
            _, ds = find_posterior_dataset(handle)
            names = set(ds.dtype.names or ())
            mass_name = "final_mass" if "final_mass" in names else "final_mass_non_evolved"
            spin_name = "final_spin" if "final_spin" in names else "final_spin_non_evolved"
            mass = np.asarray(ds[mass_name], dtype=float)
            spin = np.asarray(ds[spin_name], dtype=float)
        tk = kerr_time(mass, spin)
        log_width = float(np.std(np.log(tk), ddof=1))
        relative_std = float(np.std(tk, ddof=1)/np.mean(tk))
        v70 = comparison[family]
        v70_sigma_t_ref = float(v70["t_k_sigma_over_old_physical_t_ref"])
        rows.append({
            "waveform_family": family, "n_draws": len(tk),
            "primary_sigma_log_tk": log_width,
            "linear_sigma_over_mean_direct_recompute": relative_std,
            "v70_linear_sigma_over_T_REF_comparison": v70_sigma_t_ref,
            "sigma_log_minus_linear_sigma_over_mean": log_width-relative_std,
            "relative_difference_log_vs_linear_mean": (log_width-relative_std)/log_width,
            "primary_coordinate": "log_tK",
            "qualification": "same-event posterior-width diagnostic; not an independent anchor likelihood",
        })
    return rows


def covariance_envelopes(width_rows: list[dict[str, Any]], targets: list[dict[str, Any]]) -> list[dict[str, Any]]:
    selected = {
        "E_log_likelihood_ratio>=ln(10)": next(r for r in targets if r["criterion"] == "E_log_likelihood_ratio>=ln(10)"),
        "P(log_likelihood_ratio>0)>=0.90": next(r for r in targets if r["criterion"] == "P(log_likelihood_ratio>0)>=0.90"),
    }
    rows: list[dict[str, Any]] = []
    for family in width_rows:
        b = float(family["primary_sigma_log_tk"])
        for criterion, target_row in selected.items():
            q = float(target_row["max_sigma_quotient_relative"])
            rho_min_optimal = math.sqrt(max(0.0, 1.0 - (q / b) ** 2)) if q < b else 0.0
            for rho in (0.0, 0.5, 0.9, 0.95, 0.98, 0.99, 0.995, 0.999, 1.0):
                a_opt = max(0.0, rho * b)
                min_q = b * math.sqrt(max(0.0, 1.0 - rho * rho))
                rows.append({
                    "waveform_family": family["waveform_family"],
                    "criterion": criterion,
                    "anchor_sigma_log_t": b,
                    "v70_linear_sigma_over_T_REF_comparison": family["v70_linear_sigma_over_T_REF_comparison"],
                    "correlation_rho": rho,
                    "optimally_tuned_product_sigma_relative": a_opt,
                    "minimum_quotient_sigma_relative": min_q,
                    "target_quotient_sigma_relative": q,
                    "passes_target_under_delta_method": min_q <= q + 1e-15,
                    "minimum_rho_with_optimally_tuned_product": rho_min_optimal,
                    "qualification": "log-quotient covariance envelope; rho and product precision are not measured",
                })
            for a in (0.001, 0.002, 0.005, 0.01, 0.02, 0.05, 0.10):
                rho_req = (a * a + b * b - q * q) / (2.0 * a * b)
                rows.append({
                    "waveform_family": family["waveform_family"],
                    "criterion": criterion,
                    "anchor_sigma_log_t": b,
                    "v70_linear_sigma_over_T_REF_comparison": family["v70_linear_sigma_over_T_REF_comparison"],
                    "product_sigma_relative": a,
                    "required_correlation_rho": rho_req,
                    "physically_feasible_rho_le_1": rho_req <= 1.0,
                    "automatically_passes_for_all_rho_ge_minus1": rho_req <= -1.0,
                    "target_quotient_sigma_relative": q,
                    "qualification": "log-quotient covariance requirement; no same-event covariance is available",
                })
    return rows


def transfer(freq: np.ndarray, tau: float, time_s: float) -> np.ndarray:
    return 1.0 + RHO_FIXED * np.exp(-1j * np.pi * freq * tau * time_s)


def carrier_amplitude(freq: np.ndarray) -> np.ndarray:
    return (freq / 100.0) ** (-7.0 / 6.0) * np.exp(-(freq / 900.0) ** 2)


def base_carrier(freq: np.ndarray, detector: str) -> np.ndarray:
    phase = 0.019 * freq + 1.1e-5 * freq**2
    if detector == "L1":
        phase = phase + 0.63 + 2.0 * np.pi * freq * 0.0069
    return carrier_amplitude(freq) * np.exp(1j * phase)


def profile_mismatch(a: np.ndarray, b: np.ndarray) -> float:
    scale = np.vdot(b, a) / np.vdot(b, b)
    residual = a - scale * b
    return float(np.vdot(residual, residual).real / np.vdot(a, a).real)


def required_snr_accuracy(probability: float, mismatch: float) -> float:
    z = NORMAL.inv_cdf(probability)
    y = (z*z + math.sqrt(z**4 + 2.0*mismatch*z*z)) / mismatch
    return math.sqrt(y)


def carrier_fisher_rows(targets: list[dict[str, Any]]) -> list[dict[str, Any]]:
    q90 = next(r["max_sigma_quotient_relative"] for r in targets if r["criterion"] == "P(log_likelihood_ratio>0)>=0.90")
    rows: list[dict[str, Any]] = []
    for n in (512, 8192):
        freq = np.linspace(50.0, 1024.0, n)
        hp = transfer(freq, LN4, T_REF_S)
        h = np.r_[base_carrier(freq, "H1") * hp, base_carrier(freq, "L1") * hp]
        derivative_transfer = (
            -1j * np.pi * freq * (LN4 * T_REF_S) * RHO_FIXED
            * np.exp(-1j * np.pi * freq * LN4 * T_REF_S)
        )
        dh = np.r_[base_carrier(freq, "H1") * derivative_transfer,
                   base_carrier(freq, "L1") * derivative_transfer]
        projected = dh - h * (np.vdot(h, dh) / np.vdot(h, h))
        fisher_per_snr2 = float(np.vdot(projected, projected).real / np.vdot(h, h).real)
        product_sigma = 1.0 / (DIRECT_WAVE_NETWORK_SNR * math.sqrt(fisher_per_snr2))
        h_grid = np.r_[base_carrier(freq, "H1") * transfer(freq, TAU_GRID, T_REF_S),
                       base_carrier(freq, "L1") * transfer(freq, TAU_GRID, T_REF_S)]
        mismatch = profile_mismatch(h, h_grid)
        rows.append({
            "n_frequency_samples": n,
            "frequency_min_hz": 50.0, "frequency_max_hz": 1024.0,
            "carrier_kind": "synthetic_unwhitened_v65_base_carrier_network",
            "proxy_role": "PRIMARY_EXACT_V65_BASE_CARRIER_GEOMETRY" if n == 512 else "SECONDARY_DENSE_GRID_CONVERGENCE_SURROGATE",
            "profiled_complex_amplitude": True,
            "fisher_information_log_product_per_snr_squared": fisher_per_snr2,
            "product_sigma_relative_at_full_directwave_snr": product_sigma,
            "full_directwave_network_snr_optimistic_ceiling": DIRECT_WAVE_NETWORK_SNR,
            "snr_for_product_sigma_at_90pct_likelihood_sign_target": 1.0 / (q90 * math.sqrt(fisher_per_snr2)),
            "fixed_t_one_minus_match_squared": mismatch,
            "fixed_t_snr90_moment_gaussian_proxy": required_snr_accuracy(0.90, mismatch),
            "qualification": "synthetic unwhitened local Fisher/moment proxy; not a real PSD-weighted HRF likelihood",
        })
    return rows


def snr_feasibility_rows(carriers: list[dict[str, Any]], widths: list[dict[str, Any]], targets: list[dict[str, Any]]) -> list[dict[str, Any]]:
    fisher = next(r["fisher_information_log_product_per_snr_squared"] for r in carriers if r["n_frequency_samples"] == 512)
    q = next(r["max_sigma_quotient_relative"] for r in targets if r["criterion"] == "P(log_likelihood_ratio>0)>=0.90")
    rows: list[dict[str, Any]] = []
    for family in widths:
        b = float(family["primary_sigma_log_tk"])
        low_a, high_a = max(1e-15, b - q), b + q
        snr_low = 1.0 / (high_a * math.sqrt(fisher))
        snr_high = 1.0 / (low_a * math.sqrt(fisher))
        for snr in (DIRECT_WAVE_NETWORK_SNR, 80.0, 150.0, 200.0, 250.0, 500.0, 1000.0):
            a = 1.0 / (snr * math.sqrt(fisher))
            rho_req = (a*a + b*b - q*q) / (2.0*a*b)
            sigma_at_rho1 = abs(a - b)
            rows.append({
                "waveform_family": family["waveform_family"], "snr": snr,
                "product_sigma_log_proxy": a, "anchor_sigma_log_t": b,
                "v70_linear_sigma_over_T_REF_comparison": family["v70_linear_sigma_over_T_REF_comparison"],
                "target_quotient_sigma_relative": q, "required_correlation_rho": rho_req,
                "minimum_sigma_at_rho1": sigma_at_rho1,
                "feasible_even_with_rho_le_1": rho_req <= 1.0,
                "snr_window_for_any_rho_le_1_low": snr_low,
                "snr_window_for_any_rho_le_1_high": snr_high,
                "carrier_proxy_role": "PRIMARY_EXACT_V65_512_BIN_BASE_GEOMETRY",
                "qualification": "512-bin exact v65 synthetic carrier; full direct-wave SNR is an optimistic branch-component ceiling",
            })
    return rows


def catalog_systematics_rows(carriers: list[dict[str, Any]], widths: list[dict[str, Any]], targets: list[dict[str, Any]]) -> list[dict[str, Any]]:
    fisher = next(r["fisher_information_log_product_per_snr_squared"] for r in carriers if r["n_frequency_samples"] == 512)
    product = 1.0 / (DIRECT_WAVE_NETWORK_SNR * math.sqrt(fisher))
    best = min(widths, key=lambda r: float(r["primary_sigma_log_tk"]))
    anchor = float(best["primary_sigma_log_tk"])
    per_event = math.hypot(product, anchor)
    rows: list[dict[str, Any]] = []
    target_subset = [r for r in targets if r["criterion"] in {
        "E_log_likelihood_ratio>=ln(10)", "P(log_likelihood_ratio>0)>=0.90",
        "P(log_likelihood_ratio>0)>=0.95", "P(log_likelihood_ratio>ln(10))>=0.90",
    }]
    for target_row in target_subset:
        target = float(target_row["max_sigma_quotient_relative"])
        scenarios = (
            ("independent_anchor_only_ideal_product_exact", 0.0, anchor),
            ("current_512_carrier_full_directwave_snr_independent", product, per_event),
        )
        for scenario, scenario_product, scenario_total in scenarios:
            for systematic in (0.0, 0.0005, 0.001, 0.0015, 0.002, 0.003, 0.005):
                if systematic >= target:
                    required: int | str = "IMPOSSIBLE_COMMON_FLOOR"
                else:
                    required = int(math.ceil(scenario_total**2 / (target**2 - systematic**2)))
                rows.append({
                    "scenario": scenario,
                    "criterion": target_row["criterion"],
                    "best_anchor_family": best["waveform_family"],
                    "product_sigma_per_event_proxy": scenario_product,
                    "anchor_sigma_log_t_per_event": anchor,
                    "v70_linear_sigma_over_T_REF_comparison": best["v70_linear_sigma_over_T_REF_comparison"],
                    "independent_quotient_sigma_per_event": scenario_total,
                    "common_fractional_systematic_floor": systematic,
                    "target_quotient_sigma_relative": target,
                    "minimum_independent_events": required,
                    "qualification": "optimistic identical-event 1/sqrt(N) proxy; common systematics do not average down",
                })
    return rows


def inverse_normal_cdf_array(p: np.ndarray) -> np.ndarray:
    """Acklam inverse-normal approximation, vectorized and dependency-free."""
    p = np.asarray(p, dtype=float)
    a = np.array([-3.969683028665376e1, 2.209460984245205e2, -2.759285104469687e2,
                  1.383577518672690e2, -3.066479806614716e1, 2.506628277459239])
    b = np.array([-5.447609879822406e1, 1.615858368580409e2, -1.556989798598866e2,
                  6.680131188771972e1, -1.328068155288572e1])
    c = np.array([-7.784894002430293e-3, -3.223964580411365e-1, -2.400758277161838,
                  -2.549732539343734, 4.374664141464968, 2.938163982698783])
    d = np.array([7.784695709041462e-3, 3.224671290700398e-1, 2.445134137142996, 3.754408661907416])
    out = np.empty_like(p)
    low = p < 0.02425
    high = p > 1.0 - 0.02425
    mid = ~(low | high)
    q = np.sqrt(-2.0 * np.log(p[low]))
    out[low] = (((((c[0]*q+c[1])*q+c[2])*q+c[3])*q+c[4])*q+c[5]) / ((((d[0]*q+d[1])*q+d[2])*q+d[3])*q+1)
    q = np.sqrt(-2.0 * np.log(1.0-p[high]))
    out[high] = -(((((c[0]*q+c[1])*q+c[2])*q+c[3])*q+c[4])*q+c[5]) / ((((d[0]*q+d[1])*q+d[2])*q+d[3])*q+1)
    q = p[mid] - 0.5
    r = q*q
    out[mid] = (((((a[0]*r+a[1])*r+a[2])*r+a[3])*r+a[4])*r+a[5])*q / (((((b[0]*r+b[1])*r+b[2])*r+b[3])*r+b[4])*r+1)
    return out


def average_ranks(values: np.ndarray) -> np.ndarray:
    values = np.asarray(values)
    order = np.argsort(values, kind="mergesort")
    sorted_values = values[order]
    ranks = np.empty(len(values), dtype=float)
    starts = np.r_[0, np.nonzero(sorted_values[1:] != sorted_values[:-1])[0] + 1]
    ends = np.r_[starts[1:], len(values)]
    for start, end in zip(starts, ends):
        ranks[order[start:end]] = 0.5 * (start + 1 + end)
    return ranks


def rank_normalize(values: np.ndarray) -> np.ndarray:
    flat = values.ravel()
    ranks = average_ranks(flat)
    probs = (ranks - 0.375) / (len(ranks) + 0.25)
    return inverse_normal_cdf_array(probs).reshape(values.shape)


def basic_rhat(draws_by_chain: np.ndarray) -> float:
    n, m = draws_by_chain.shape
    chain_var = np.var(draws_by_chain, axis=0, ddof=1)
    w = float(np.mean(chain_var))
    b = float(n * np.var(np.mean(draws_by_chain, axis=0), ddof=1))
    return math.sqrt(((n - 1.0) / n * w + b / n) / w) if w > 0 else float("inf")


def rank_folded_split_rhat(draws_by_chain: np.ndarray) -> tuple[float, float, float, int, int]:
    n0, chains = draws_by_chain.shape
    half = n0 // 2
    split = np.concatenate([draws_by_chain[:half], draws_by_chain[-half:]], axis=1)
    rank_rhat = basic_rhat(rank_normalize(split))
    folded = np.abs(split - np.median(split))
    folded_rhat = basic_rhat(rank_normalize(folded))
    return rank_rhat, folded_rhat, max(rank_rhat, folded_rhat), half, 2*chains


def stable_weights(log_weights: np.ndarray) -> np.ndarray:
    x = np.asarray(log_weights, dtype=float)
    x = x - np.nanmax(x)
    w = np.exp(x)
    return w / np.sum(w)


def effective_sample_size(weights: np.ndarray) -> float:
    w = np.asarray(weights, dtype=float)
    w = w / np.sum(w)
    return float(1.0 / np.sum(w*w))


def weighted_quantile(values: np.ndarray, weights: np.ndarray, probs: Iterable[float]) -> np.ndarray:
    x = np.asarray(values, dtype=float)
    w = np.asarray(weights, dtype=float)
    order = np.argsort(x)
    x, w = x[order], w[order]
    cdf = np.cumsum(w) - 0.5*w
    cdf /= np.sum(w)
    return np.interp(np.asarray(list(probs), dtype=float), cdf, x, left=x[0], right=x[-1])


def load_directwave_chain(nature_path: Path) -> tuple[dict[str, np.ndarray], list[dict[str, Any]]]:
    arrays: dict[str, np.ndarray] = {}
    rows: list[dict[str, Any]] = []
    with zipfile.ZipFile(nature_path) as archive:
        for key, member in CHAIN_MEMBERS.items():
            payload = archive.read(member)
            arr = np.load(io.BytesIO(payload), allow_pickle=False)
            arrays[key] = arr
            rows.append({
                "member_role": key, "zip_member": member, "bytes": len(payload),
                "sha256": sha256_bytes(payload), "expected_sha256": CHAIN_EXPECTED_SHA256[key],
                "hash_ok": sha256_bytes(payload) == CHAIN_EXPECTED_SHA256[key],
                "shape": "x".join(map(str, arr.shape)), "dtype": str(arr.dtype),
                "finite_fraction": float(np.mean(np.isfinite(arr))),
            })
    expected = {
        "samples": (160_000, 3), "log_prob": (160_000,), "snrs": (160_000, 4)
    }
    for row in rows:
        row["shape_ok"] = arrays[row["member_role"]].shape == expected[row["member_role"]]
    return arrays, rows


def directwave_chain_diagnostics(arrays: dict[str, np.ndarray]) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]]]:
    samples = arrays["samples"]
    log_prob = arrays["log_prob"]
    snrs = arrays["snrs"]
    chain = samples.reshape(5000, 32, 3)
    log_chain = log_prob.reshape(5000, 32)
    snr_chain = snrs.reshape(5000, 32, 4)

    accept_rows: list[dict[str, Any]] = []
    for burn in BURN_SCHEDULE:
        changed = np.any(np.diff(chain[burn:], axis=0) != 0.0, axis=2)
        acceptance = np.mean(changed, axis=0)
        accept_rows.extend({
            "burn_steps": burn, "walker": i,
            "acceptance_fraction_inferred_from_exact_repeats": float(value),
            "passes_nominal_0p1_to_0p6": bool(0.1 <= value <= 0.6),
            "qualification": "inferred because emcee acceptance counters were not released",
        } for i, value in enumerate(acceptance))
        accept_rows.append({
            "burn_steps": burn, "walker": "SUMMARY",
            "acceptance_fraction_min": float(np.min(acceptance)),
            "acceptance_fraction_median": float(np.median(acceptance)),
            "acceptance_fraction_mean": float(np.mean(acceptance)),
            "acceptance_fraction_max": float(np.max(acceptance)),
            "walkers_below_0p1": int(np.sum(acceptance < 0.1)),
            "qualification": "low-acceptance walkers and the walker-as-chain Rhat diagnostic must be resolved before posterior admission",
        })

    labels = ("amp_real", "amp_imag", "time_offset_s", "released_cached_log_probability")
    rhat_rows: list[dict[str, Any]] = []
    for burn in BURN_SCHEDULE:
        for j, label in enumerate(labels):
            series = log_chain[burn:] if label == "released_cached_log_probability" else chain[burn:, :, j]
            rank_rhat, folded_rhat, maximum, half, split_chains = rank_folded_split_rhat(series)
            rhat_rows.append({
                "burn_steps": burn, "parameter": label,
                "burn_role": "FROZEN_PRIMARY_ADMISSION_BURN" if burn == FROZEN_PRIMARY_BURN_STEPS else "SENSITIVITY_ONLY",
                "rank_normalized_split_rhat": rank_rhat,
                "folded_rank_normalized_split_rhat": folded_rhat,
                "max_rank_folded_split_rhat": maximum,
                "draws_per_split_chain": half, "split_chain_count": split_chains,
                "passes_rhat_le_1p01": maximum <= 1.01,
                "chain_construction": "each interacting emcee walker treated as one diagnostic chain before splitting",
                "diagnostic_scope": "admission screen only; walker-as-chain Rhat is not by itself a proof of convergence or nonconvergence",
            })

    h_delta = snrs[:, 0]*snrs[:, 1] - 0.5*snrs[:, 0]**2
    l_delta = snrs[:, 2]*snrs[:, 3] - 0.5*snrs[:, 2]**2
    offset = log_prob - h_delta - l_delta
    decomposition_rows: list[dict[str, Any]] = [{
        "audit": "released_cache_relative_logprob_identity",
        "formula": "logp_cached=C+rhoopt_H*rhomf_H-rhoopt_H^2/2+rhoopt_L*rhomf_L-rhoopt_L^2/2",
        "constant_offset_median": float(np.median(offset)),
        "centered_residual_std": float(np.std(offset)),
        "centered_residual_peak_to_peak": float(np.ptp(offset)),
        "correlation_logp_vs_detector_sum": float(np.corrcoef(log_prob, h_delta+l_delta)[0, 1]),
        "cached_relative_logprob_identity_pass": bool(np.ptp(offset) < 1e-8),
        "identity_scope": "identity internal to the released cached arrays and stipulated SNR-column formula; not a raw-strain detector-likelihood validation",
    }]
    detector_components = {
        "H1_only_remove_L1": l_delta.reshape(5000, 32),
        "L1_only_remove_H1": h_delta.reshape(5000, 32),
    }
    for burn in BURN_SCHEDULE:
        for target, removed_chain in detector_components.items():
            removed_matrix = removed_chain[burn:]
            removed = removed_matrix.ravel()
            weights = stable_weights(-removed)
            ess = effective_sample_size(weights)
            weight_matrix = weights.reshape(removed_matrix.shape)
            walker_mass = np.sum(weight_matrix, axis=0)
            walker_ess = effective_sample_size(walker_mass)
            maximum_walker_mass = float(np.max(walker_mass))
            sample_screen = bool(ess >= 400 and ess/len(weights) >= 0.01)
            walker_screen = bool(walker_ess >= 8.0 and maximum_walker_mass <= 0.10)
            decomposition_rows.append({
                "audit": "network_to_single_detector_importance_deconditioning",
                "target": target, "burn_steps": burn, "n_network_draws": len(weights),
                "burn_role": "FROZEN_PRIMARY_ADMISSION_BURN" if burn == FROZEN_PRIMARY_BURN_STEPS else "SENSITIVITY_ONLY",
                "importance_ess": ess,
                "importance_ess_fraction": ess/len(weights),
                "maximum_normalized_weight": float(np.max(weights)),
                "walker_effective_count": walker_ess,
                "maximum_walker_mass": maximum_walker_mass,
                "walker_mass_by_index_json": json.dumps([float(x) for x in walker_mass], separators=(",", ":")),
                "passes_sample_ess_ge_400_and_fraction_ge_0p01": sample_screen,
                "passes_walker_ess_ge_8_and_max_mass_le_0p10": walker_screen,
                "passes_all_deconditioning_screens": bool(sample_screen and walker_screen),
                "qualification": "burn-sensitive importance diagnostic; sample ESS cannot substitute for independent-walker support or Rhat",
            })
    decomposition_rows.append({
        "audit": "released_chain_layout_and_convergence_admission_screen",
        "inferred_steps": 5000, "inferred_walkers": 32, "dimensions": 3,
        "log_prob_shape": str(log_chain.shape), "snr_shape": str(snr_chain.shape),
        "chain_admitted": False,
        "screen_status": "FAIL_WALKER_AS_CHAIN_RHAT_ADMISSION_SCREEN",
        "reason": "walker-as-chain rank-normalized/folded split-Rhat exceeds 1.01 at every audited burn; this is an admission-screen failure, not a standalone proof of nonconvergence",
    })
    return accept_rows, rhat_rows, decomposition_rows


def cbc_deconditioning_rows(input_dir: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for filename, (_, _, family) in POSTERIOR_SPEC.items():
        with h5py.File(input_dir/filename, "r") as handle:
            _, ds = find_posterior_dataset(handle)
            names = set(ds.dtype.names or ())
            required = {"log_likelihood", "H1_log_likelihood", "L1_log_likelihood"}
            if not required <= names:
                raise ValueError(f"{family} posterior lacks detector log-likelihood fields")
            data = ds[:]
        residual = data["log_likelihood"] - data["H1_log_likelihood"] - data["L1_log_likelihood"]
        rows.append({
            "waveform_family": family, "filename": filename,
            "target": "network_decomposition_audit",
            "network_minus_H1_minus_L1_min": float(np.min(residual)),
            "network_minus_H1_minus_L1_median": float(np.median(residual)),
            "network_minus_H1_minus_L1_max": float(np.max(residual)),
            "is_constant": bool(np.ptp(residual) < 1e-8),
            "qualification": "use target-detector minus released network logL directly; do not assume exact additive constant",
        })
        for detector in ("H1", "L1"):
            logw = data[f"{detector}_log_likelihood"] - data["log_likelihood"]
            weights = stable_weights(logw)
            ess = effective_sample_size(weights)
            rows.append({
                "waveform_family": family, "filename": filename,
                "target": detector + "_only_from_network_posterior",
                "n_network_draws": len(weights), "importance_ess": ess,
                "importance_ess_fraction": ess/len(weights),
                "maximum_normalized_weight": float(np.max(weights)),
                "log_weight_range": float(np.ptp(logw)),
                "passes_ess_ge_400_and_fraction_ge_0p01": bool(ess >= 400 and ess/len(weights) >= 0.01),
                "qualification": "importance diagnostic only; network posterior does not cover detector-only target adequately when ESS fails",
            })
    return rows


def kerr_time(mass: np.ndarray, spin: np.ndarray) -> np.ndarray:
    root = np.sqrt(np.maximum(1.0 - np.asarray(spin, float)**2, 1e-15))
    return 4.0*np.asarray(mass, float)*MTSUN_S*(1.0+root)/root


def released_draw_logposterior_vs_loglikelihood_rows(nr_path: Path) -> tuple[list[dict[str, Any]], float]:
    with h5py.File(nr_path, "r") as handle:
        _, ds = find_posterior_dataset(handle)
        data = ds[:]
    tk = kerr_time(data["final_mass"], data["final_spin"])
    indices = {
        "maximum_released_draw_log_likelihood": int(np.argmax(data["log_likelihood"])),
        "maximum_released_draw_log_posterior_density_proxy": int(np.argmax(data["log_likelihood"] + data["log_prior"])),
    }
    rows: list[dict[str, Any]] = []
    for label, index in indices.items():
        rows.append({
            "point_definition": label, "draw_index": index,
            "log_likelihood": float(data["log_likelihood"][index]),
            "log_prior": float(data["log_prior"][index]),
            "final_mass": float(data["final_mass"][index]),
            "final_spin": float(data["final_spin"][index]),
            "t_k_ms": float(1e3*tk[index]),
            "optimization_scope": "argmax over released posterior rows; not a continuous parameter-space optimization",
        })
    ml = rows[0]["t_k_ms"]
    mp = rows[1]["t_k_ms"]
    rows.append({
        "point_definition": "difference_released_draw_logposterior_minus_loglikelihood",
        "t_k_ms": mp-ml,
        "relative_to_maximum_released_draw_log_likelihood": (mp-ml)/ml,
        "posterior_median_t_k_ms": float(1e3*np.median(tk)),
        "qualification": "argmax values over released posterior rows only; not continuous parameter-space optimizations; the release script labels argmax(logL+logPrior) as maximum likelihood",
    })
    return rows, float(np.median(data["geocent_time"]))


def prior_coordinate_rows(arrays: dict[str, np.ndarray], burn: int = 1000) -> list[dict[str, Any]]:
    samples = arrays["samples"].reshape(5000, 32, 3)[burn:].reshape(-1, 3)
    radius = np.hypot(samples[:, 0], samples[:, 1])
    schemes: list[tuple[str, np.ndarray, str]] = [
        ("uniform_cartesian_Ax_Ay_native", np.zeros(len(radius)), "released native prior"),
        ("uniform_polar_radius_phase", -np.log(np.maximum(radius, 1e-300)), "Jacobian reweight 1/r relative to Cartesian"),
        ("log_uniform_radius_0p1_to_sqrt800", -2.0*np.log(np.maximum(radius, 0.1)), "defined only for r>=0.1; 1/r^2 relative weight"),
    ]
    rows: list[dict[str, Any]] = []
    for name, logw, note in schemes:
        support = np.ones(len(radius), dtype=bool)
        if name.startswith("log_uniform"):
            support = radius >= 0.1
        weights = np.zeros(len(radius), dtype=float)
        weights[support] = stable_weights(logw[support])
        rq = weighted_quantile(radius[support], weights[support], (0.05, 0.5, 0.95))
        tq = weighted_quantile(1e3*samples[support, 2], weights[support], (0.05, 0.5, 0.95))
        rows.append({
            "prior_coordinate": name, "burn_steps": burn,
            "support_draws": int(np.sum(support)), "importance_ess": effective_sample_size(weights[support]),
            "amplitude_q05": float(rq[0]), "amplitude_median": float(rq[1]), "amplitude_q95": float(rq[2]),
            "time_offset_q05_ms": float(tq[0]), "time_offset_median_ms": float(tq[1]), "time_offset_q95_ms": float(tq[2]),
            "weight_note": note,
            "admitted": False,
            "qualification": "prior sensitivity diagnostic from a chain that fails Rhat; not a posterior result",
        })
    return rows


def dq_injection_rows(input_dir: Path, event_gps: float) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for filename, spec in STRAIN_SPEC.items():
        path = input_dir / filename
        with h5py.File(path, "r") as handle:
            dq = handle["quality/simple/DQmask"][:]
            inj = handle["quality/injections/Injmask"][:]
            dq_names = _decode_array(handle["quality/simple/DQShortnames"][:])
            inj_names = _decode_array(handle["quality/injections/InjShortnames"][:])
            start = int(handle["quality/simple/DQmask"].attrs["Xstart"])
        event_index = int(math.floor(event_gps-start))
        lo, hi = max(0, event_index-65), min(len(dq), event_index+66)
        for kind, mask, names in (("DQ", dq, dq_names), ("INJECTION", inj, inj_names)):
            for bit, name in enumerate(names):
                bit_values = ((mask >> bit) & 1).astype(bool)
                rows.append({
                    "detector": spec["detector"], "mask_class": kind, "bit": bit,
                    "shortname": name, "event_gps": event_gps, "event_second_index": event_index,
                    "event_bit_pass": bool(bit_values[event_index]),
                    "fraction_pass_full_4096s": float(np.mean(bit_values)),
                    "all_pass_event_plusminus65s": bool(np.all(bit_values[lo:hi])),
                    "fraction_pass_event_plusminus65s": float(np.mean(bit_values[lo:hi])),
                    "interpretation": "mask bit 1 means category good/no named injection",
                })
    return rows


def binomial_cdf(k: int, n: int, p: float) -> float:
    if k < 0:
        return 0.0
    if k >= n:
        return 1.0
    if p <= 0:
        return 1.0
    if p >= 1:
        return 0.0
    term = (1.0-p)**n
    total = term
    for i in range(k):
        term *= (n-i)/(i+1) * p/(1.0-p)
        total += term
    return min(1.0, max(0.0, total))


def cp_upper(k: int, n: int, alpha: float = 0.05) -> float:
    if k >= n:
        return 1.0
    lo, hi = 0.0, 1.0
    for _ in range(80):
        mid = 0.5*(lo+hi)
        if binomial_cdf(k, n, mid) > alpha:
            lo = mid
        else:
            hi = mid
    return 0.5*(lo+hi)


def min_zero_exceedance_controls(target_p: float, alpha: float = 0.05) -> int:
    return int(math.ceil(math.log(alpha)/math.log1p(-target_p)))


def nonregular_control_rows() -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = [{
        "item": "null_geometry", "null_hypothesis": "branch amplitude=0",
        "unidentified_under_null": "tau,t_DW/phase/delay",
        "wilks_chi_square_admissible": False,
        "required_calibration": "end-to-end source-only/off-source empirical maximum-statistic controls",
        "reason": "nuisance coordinates disappear at zero amplitude; look-elsewhere maximization is nonregular",
        "calibration_scope": "fully frozen preprocessing, search grid, maximization rule, threshold, and decision rule",
        "control_sampling_requirement": "independent or exchangeable held-out controls sufficient for the declared binomial model",
    }]
    grid_points = 40*85*7
    rows.append({
        "item": "released_directwave_grid_nominal_count", "frequency_bins": 40,
        "damping_rate_bins": 85, "start_times": 7, "nominal_grid_points": grid_points,
        "independent_trial_count_claimed": False,
        "reason": "neighboring grid cells/start windows are correlated; nominal count is not an effective trials factor",
    })
    for target in (0.10, 0.05, 0.01, 0.001, 2.866515718791933e-7):
        n = min_zero_exceedance_controls(target)
        rows.append({
            "item": "zero_exceedance_empirical_control_requirement",
            "target_one_sided_tail_probability": target, "confidence": 0.95,
            "minimum_controls_if_zero_exceedances": n,
            "cp_upper_at_minimum": cp_upper(0, n),
            "iid_or_exchangeable_bernoulli_control_assumption": "REQUIRED_NOT_ESTABLISHED",
            "frozen_threshold_and_full_search_pipeline": "REQUIRED_NOT_EXECUTED",
            "qualification": "exact zero-exceedance one-sided Clopper-Pearson count only for independent/exchangeable held-out controls after the threshold, preprocessing, scan, maximization, and decision rule are frozen; not a completed discovery calibration",
        })
    bonferroni_local = 0.05/grid_points
    n = min_zero_exceedance_controls(bonferroni_local)
    rows.append({
        "item": "illustrative_bonferroni_nominal_grid", "global_alpha": 0.05,
        "nominal_grid_points": grid_points, "local_tail_target": bonferroni_local,
        "minimum_zero_exceedance_controls": n,
        "admitted_effective_trials_model": False,
        "iid_or_exchangeable_bernoulli_control_assumption": "REQUIRED_NOT_ESTABLISHED",
        "frozen_threshold_and_full_search_pipeline": "REQUIRED_NOT_EXECUTED",
        "qualification": "illustrative upper-bound bookkeeping only; the zero-exceedance count additionally assumes independent/exchangeable held-out controls and a fully frozen search; empirical maximum-statistic calibration is required",
    })
    return rows


def gate_rows(input_pass: bool, rhat_rows: list[dict[str, Any]], dw_decond: list[dict[str, Any]],
              cbc_rows: list[dict[str, Any]], dq_rows: list[dict[str, Any]],
              snr_rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    burns = sorted({int(r["burn_steps"]) for r in rhat_rows})
    rhat_pass_by_burn: dict[int, bool] = {}
    for burn in burns:
        burn_rows = [r for r in rhat_rows if int(r["burn_steps"]) == burn]
        if len(burn_rows) != 4:
            raise ValueError(f"expected four Rhat parameters at burn {burn}; found {len(burn_rows)}")
        rhat_pass_by_burn[burn] = all(bool(r["passes_rhat_le_1p01"]) for r in burn_rows)
    if FROZEN_PRIMARY_BURN_STEPS not in rhat_pass_by_burn:
        raise ValueError(f"frozen primary burn {FROZEN_PRIMARY_BURN_STEPS} missing from Rhat audit")
    rhat_primary_pass = rhat_pass_by_burn[FROZEN_PRIMARY_BURN_STEPS]
    dw_ess_pass_by_burn: dict[int, bool] = {}
    for burn in burns:
        burn_rows = [r for r in dw_decond if r.get("target") and int(r["burn_steps"]) == burn]
        if len(burn_rows) != 2:
            raise ValueError(f"expected two detector-deconditioning targets at burn {burn}; found {len(burn_rows)}")
        dw_ess_pass_by_burn[burn] = all(bool(r["passes_all_deconditioning_screens"]) for r in burn_rows)
    if FROZEN_PRIMARY_BURN_STEPS not in dw_ess_pass_by_burn:
        raise ValueError(f"frozen primary burn {FROZEN_PRIMARY_BURN_STEPS} missing from deconditioning audit")
    dw_ess_primary_pass = dw_ess_pass_by_burn[FROZEN_PRIMARY_BURN_STEPS]
    dw_common_primary_pass = rhat_primary_pass and dw_ess_primary_pass
    cached_identity = next(r for r in dw_decond if r.get("audit") == "released_cache_relative_logprob_identity")
    cached_identity_pass = bool(cached_identity["cached_relative_logprob_identity_pass"])
    cbc_ess_pass = all(bool(r.get("passes_ess_ge_400_and_fraction_ge_0p01", True)) for r in cbc_rows)
    cw_clean = all(bool(r["event_bit_pass"]) for r in dq_rows if r["mask_class"] == "INJECTION" and r["shortname"] == "NO_CW_HW_INJ")
    current_snr_feasible = any(
        bool(r["feasible_even_with_rho_le_1"]) for r in snr_rows
        if abs(float(r["snr"])-DIRECT_WAVE_NETWORK_SNR) < 1e-6
    )
    return [
        {"gate": "frozen_parent_and_official_integrity", "status": "PASS" if input_pass else "FAIL", "admitted": input_pass},
        {"gate": "v69_single_delay_structural_identification", "status": "EXACT_FAIL_RETAINED", "admitted": False},
        {"gate": "same_event_quotient_covariance", "status": "RESCUE_ENVELOPE_ONLY_NOT_MEASURED", "admitted": False},
        {"gate": "nuisance_quotient_local_completion", "status": "NOT_ESTABLISHED", "admitted": False},
        {"gate": "global_nuisance_image_separation", "status": "NOT_EVALUATED", "admitted": False},
        {"gate": "generative_waveform_contract", "status": "INCOMPLETE", "admitted": False},
        {"gate": "composite_alternative_control", "status": "NOT_EXECUTED", "admitted": False},
        {"gate": "v67_control_calibration", "status": "CONDITIONAL_METHOD_GATE_ONLY", "admitted": False},
        {"gate": "synthetic_carrier_current_snr_feasibility", "status": "FAIL" if not current_snr_feasible else "CONDITIONAL_PROXY_PASS", "admitted": False},
        {"gate": "released_directwave_cached_relative_logprob_identity", "status": "PASS_CACHED_RELATIVE_IDENTITY_ONLY" if cached_identity_pass else "FAIL_CACHED_RELATIVE_IDENTITY", "admitted": cached_identity_pass},
        {"gate": "released_directwave_chain_convergence", "status": "CONDITIONAL_WALKER_AS_CHAIN_RHAT_SCREEN_PASS" if rhat_primary_pass else "FAIL_WALKER_AS_CHAIN_RHAT_ADMISSION_SCREEN", "admitted": rhat_primary_pass},
        {"gate": "released_directwave_network_to_detector_direct_importance", "status": "PASS_AT_FROZEN_20PCT_BURN" if dw_common_primary_pass else "FAIL_FROZEN_20PCT_BURN_RHAT_AND_ESS", "admitted": dw_common_primary_pass},
        {"gate": "released_cbc_network_to_detector_direct_importance", "status": "PASS" if cbc_ess_pass else "FAIL_SUPPORT_AND_LIKELIHOOD_SEMANTICS", "admitted": cbc_ess_pass},
        {"gate": "event_hardware_injection_cleanliness", "status": "PASS" if cw_clean else "CW_HW_INJECTION_BIT_FALSE_FREQUENCY_VETO_NOT_EVALUATED", "admitted": cw_clean},
        {"gate": "nonregular_null_calibration", "status": "NOT_EXECUTED", "admitted": False},
        {"gate": "raw_detector_separated_joint_likelihood", "status": "NOT_EXECUTED", "admitted": False},
        {"gate": "raw_detector_surface_environment", "status": "BLOCKED_NO_LOCKED_PY311_ENVIRONMENT", "admitted": False},
        {"gate": "real_physical_branch_interpretation", "status": "LOCKED", "admitted": False},
    ]


def make_figures(outdir: Path, covariance: list[dict[str, Any]], carriers: list[dict[str, Any]],
                 widths: list[dict[str, Any]], targets: list[dict[str, Any]],
                 rhat_rows: list[dict[str, Any]], accept_rows: list[dict[str, Any]],
                 dw_decond: list[dict[str, Any]], cbc: list[dict[str, Any]]) -> None:
    plt.rcParams.update({"figure.dpi": 120, "savefig.dpi": 160, "font.size": 9})
    q90 = next(r["max_sigma_quotient_relative"] for r in targets if r["criterion"] == "P(log_likelihood_ratio>0)>=0.90")

    fig, ax = plt.subplots(figsize=(7.5, 5.2))
    rho = np.linspace(0, 1, 500)
    for family in widths:
        b = float(family["primary_sigma_log_tk"])
        ax.plot(rho, 100*b*np.sqrt(1-rho*rho), label=family["waveform_family"])
    ax.axhline(100*q90, color="black", linestyle="--", label="90% likelihood-sign target")
    ax.set_xlabel("product–anchor correlation (optimally tuned product width)")
    ax.set_ylabel("minimum local quotient width [%]")
    ax.set_yscale("log")
    ax.set_title("v71 covariance rescue envelope (not a measured covariance)")
    ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(outdir/"GW250114_V71_covariance_rescue_envelope.png")
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(7.5, 5.2))
    snr = np.geomspace(10, 3000, 500)
    for carrier in carriers:
        f = carrier["fisher_information_log_product_per_snr_squared"]
        ax.plot(snr, 100/(snr*np.sqrt(f)), label=f"{carrier['n_frequency_samples']} bins")
    best = min(float(r["primary_sigma_log_tk"]) for r in widths)
    ax.axhspan(100*max(0, best-q90), 100*(best+q90), alpha=0.15, color="tab:green", label="rho=1 90%-sign band, best anchor")
    ax.axvline(DIRECT_WAVE_NETWORK_SNR, color="black", linestyle=":", label="full direct-wave SNR 23.28")
    ax.set_xscale("log"); ax.set_yscale("log")
    ax.set_xlabel("effective branch-component network SNR")
    ax.set_ylabel("local product-width proxy [%]")
    ax.set_title("v71 synthetic carrier Fisher feasibility")
    ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(outdir/"GW250114_V71_carrier_snr_feasibility.png")
    plt.close(fig)

    fig, axes = plt.subplots(1, 2, figsize=(10, 4.5))
    for parameter in ("amp_real", "amp_imag", "time_offset_s", "released_cached_log_probability"):
        q = [r for r in rhat_rows if r["parameter"] == parameter]
        axes[0].plot([r["burn_steps"] for r in q], [r["max_rank_folded_split_rhat"] for r in q], marker="o", label=parameter)
    axes[0].axhline(1.01, color="black", linestyle="--")
    axes[0].set_xlabel("burn steps"); axes[0].set_ylabel("max rank/folded split-Rhat")
    axes[0].set_title("Released direct-wave chain")
    axes[0].legend(fontsize=8)
    walker_rows = [r for r in accept_rows if isinstance(r["walker"], int) and int(r["burn_steps"]) == 0]
    axes[1].bar([r["walker"] for r in walker_rows], [r["acceptance_fraction_inferred_from_exact_repeats"] for r in walker_rows])
    axes[1].axhspan(0.1, 0.6, color="tab:green", alpha=0.12)
    axes[1].set_xlabel("walker"); axes[1].set_ylabel("inferred acceptance fraction")
    axes[1].set_title("Exact-repeat acceptance audit")
    fig.tight_layout()
    fig.savefig(outdir/"GW250114_V71_directwave_chain_diagnostics.png")
    plt.close(fig)

    fig, axes = plt.subplots(1, 3, figsize=(13, 4.8))
    for target in ("H1_only_remove_L1", "L1_only_remove_H1"):
        q = [r for r in dw_decond if r.get("target") == target]
        axes[0].plot([r["burn_steps"] for r in q], [r["importance_ess"] for r in q], marker="o", label=target)
    axes[0].axhline(400, color="black", linestyle="--", label="ESS 400")
    axes[0].set_yscale("log"); axes[0].set_xlabel("burn steps")
    axes[0].set_ylabel("importance ESS"); axes[0].set_title("Direct-wave chain")
    axes[0].legend(fontsize=7)
    for target in ("H1_only_remove_L1", "L1_only_remove_H1"):
        q = [r for r in dw_decond if r.get("target") == target]
        axes[1].plot([r["burn_steps"] for r in q], [r["walker_effective_count"] for r in q], marker="o", label=target)
    axes[1].axhline(8, color="black", linestyle="--", label="walker ESS 8")
    axes[1].set_yscale("log"); axes[1].set_xlabel("burn steps")
    axes[1].set_ylabel("effective walkers"); axes[1].set_title("Walker concentration")
    axes[1].legend(fontsize=7)
    cbc_q = [r for r in cbc if "importance_ess" in r]
    axes[2].bar([str(r["waveform_family"]) + "\n" + str(r["target"])[:2] for r in cbc_q], [r["importance_ess"] for r in cbc_q])
    axes[2].axhline(400, color="black", linestyle="--", label="ESS 400")
    axes[2].set_yscale("log"); axes[2].set_ylabel("importance ESS")
    axes[2].set_title("CBC network posteriors"); axes[2].legend(fontsize=7)
    axes[2].tick_params(axis="x", labelrotation=35, labelsize=7)
    fig.suptitle("v71 network-to-detector direct-importance audit")
    fig.tight_layout()
    fig.savefig(outdir/"GW250114_V71_deconditioning_ess.png")
    plt.close(fig)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--v70-zip", type=Path, required=True)
    parser.add_argument("--input-dir", type=Path, required=True)
    parser.add_argument("--outdir", type=Path, required=True)
    parser.add_argument("--strict", action="store_true")
    args = parser.parse_args(argv)
    args.outdir.mkdir(parents=True, exist_ok=True)

    validation = [validate_v70(args.v70_zip), validate_nature(args.input_dir/NATURE_ZIP)]
    validation.extend(validate_posterior(args.input_dir/name) for name in POSTERIOR_SPEC)
    validation.extend(validate_strain(args.input_dir/name) for name in STRAIN_SPEC)
    input_pass = all(row.get("status") == "PASS" for row in validation)
    write_csv(args.outdir/"GW250114_V71_input_validation.csv", validation)
    if args.strict and not input_pass:
        print("strict input validation failed", file=sys.stderr)
        return 2

    with zipfile.ZipFile(args.v70_zip) as v70:
        widths = csv_from_zip(v70, "GW250114_V70_kerr_anchor_by_waveform.csv")
        inherited_targets = csv_from_zip(v70, "GW250114_V70_exact_anchor_targets.csv")
        inherited_directwave = csv_from_zip(v70, "GW250114_V70_directwave_evolution.csv")
    if len(widths) != 4 or len(inherited_targets) != 6 or len(inherited_directwave) != 7:
        print("validated parent has unexpected scientific table shape", file=sys.stderr)
        return 2

    log_widths = project_tk_log_widths_from_official_remnant_draws(args.input_dir, widths)
    targets = likelihood_only_thresholds()
    target_comparison = inherited_target_semantic_comparison(inherited_targets, targets)
    covariance = covariance_envelopes(log_widths, targets)
    carriers = carrier_fisher_rows(targets)
    snr_rows = snr_feasibility_rows(carriers, log_widths, targets)
    catalog_rows = catalog_systematics_rows(carriers, log_widths, targets)

    arrays, chain_members = load_directwave_chain(args.input_dir/NATURE_ZIP)
    accept_rows, rhat_rows, dw_decond = directwave_chain_diagnostics(arrays)
    cbc_rows = cbc_deconditioning_rows(args.input_dir)
    mapml_rows, event_gps = released_draw_logposterior_vs_loglikelihood_rows(args.input_dir/"posterior_samples_NRSur7dq4.h5")
    prior_rows = prior_coordinate_rows(arrays)
    dq_rows = dq_injection_rows(args.input_dir, event_gps)
    nonregular_rows = nonregular_control_rows()
    gates = gate_rows(input_pass, rhat_rows, dw_decond, cbc_rows, dq_rows, snr_rows)

    tables = {
        "GW250114_V71_likelihood_only_thresholds.csv": targets,
        "GW250114_V71_v70_target_semantic_comparison.csv": target_comparison,
        "GW250114_V71_project_tk_log_widths_from_official_remnant_draws.csv": log_widths,
        "GW250114_V71_covariance_rescue_envelopes.csv": covariance,
        "GW250114_V71_carrier_fisher_proxies.csv": carriers,
        "GW250114_V71_snr_feasibility.csv": snr_rows,
        "GW250114_V71_catalog_systematics_counts.csv": catalog_rows,
        "GW250114_V71_directwave_chain_members.csv": chain_members,
        "GW250114_V71_directwave_acceptance.csv": accept_rows,
        "GW250114_V71_directwave_rank_folded_rhat.csv": rhat_rows,
        "GW250114_V71_directwave_decomposition_and_deconditioning.csv": dw_decond,
        "GW250114_V71_cbc_network_deconditioning.csv": cbc_rows,
        "GW250114_V71_released_draw_logposterior_vs_loglikelihood_tk.csv": mapml_rows,
        "GW250114_V71_directwave_prior_coordinate_sensitivity.csv": prior_rows,
        "GW250114_V71_dq_injection_masks.csv": dq_rows,
        "GW250114_V71_nonregular_null_and_control_counts.csv": nonregular_rows,
        "GW250114_V71_gate_status.csv": gates,
    }
    for filename, rows in tables.items():
        write_csv(args.outdir/filename, rows)

    make_figures(args.outdir, covariance, carriers, log_widths, targets, rhat_rows,
                 accept_rows, dw_decond, cbc_rows)

    summary_accept = next(r for r in accept_rows if r["walker"] == "SUMMARY" and int(r["burn_steps"]) == 0)
    summary_accept_primary = next(r for r in accept_rows if r["walker"] == "SUMMARY" and int(r["burn_steps"]) == FROZEN_PRIMARY_BURN_STEPS)
    rhat_max = max(float(r["max_rank_folded_split_rhat"]) for r in rhat_rows)
    rhat_burn0_max = max(float(r["max_rank_folded_split_rhat"]) for r in rhat_rows if r["burn_steps"] == 0)
    rhat_primary_max = max(float(r["max_rank_folded_split_rhat"]) for r in rhat_rows if int(r["burn_steps"]) == FROZEN_PRIMARY_BURN_STEPS)
    cached_identity = next(r for r in dw_decond if r.get("audit") == "released_cache_relative_logprob_identity")
    dw_ess: dict[str, dict[str, float]] = {}
    for r in dw_decond:
        if r.get("target"):
            dw_ess.setdefault(str(r["burn_steps"]), {})[str(r["target"])] = float(r["importance_ess"])
    cbc_ess: dict[str, dict[str, float]] = {}
    for r in cbc_rows:
        if "importance_ess" in r:
            cbc_ess.setdefault(str(r["waveform_family"]), {})[str(r["target"])] = float(r["importance_ess"])
    dw_primary_burn = {
        str(r["target"]): {
            "sample_ess": float(r["importance_ess"]),
            "sample_ess_fraction": float(r["importance_ess_fraction"]),
            "walker_effective_count": float(r["walker_effective_count"]),
            "maximum_walker_mass": float(r["maximum_walker_mass"]),
        }
        for r in dw_decond if r.get("target") and int(r["burn_steps"]) == FROZEN_PRIMARY_BURN_STEPS
    }
    cw_rows = [r for r in dq_rows if r["mask_class"] == "INJECTION" and r["shortname"] == "NO_CW_HW_INJ"]
    summary = {
        "version": VERSION, "date": DATE, "status": STATUS,
        "verdict": "NO_ADMITTED_COVARIANCE_RESCUE_OR_DIRECT_IMPORTANCE_DECONDITIONING_IN_AUDITED_RELEASED_PRODUCTS",
        "input_integrity_pass": input_pass,
        "v70_parent": {"sha256": V70_ZIP_SHA256, "manifest_validated": True,
                       "inherited_waveform_rows": len(widths), "inherited_target_rows": len(inherited_targets)},
        "likelihood_only": {
            "branch_relative_timescale_gap": BRANCH_RELATIVE_T_GAP,
            "branch_log_timescale_gap_primary": BRANCH_LOG_T_GAP,
            "thresholds": {r["criterion"]: r["max_sigma_quotient_relative"] for r in targets},
            "prior_jacobian_removed": True,
        },
        "covariance_rescue": {
            "status": "ENVELOPE_ONLY_COVARIANCE_NOT_MEASURED",
            "formula": "sigma_ln_tau^2=sigma_ln_s^2+sigma_ln_t^2-2*rho*sigma_ln_s*sigma_ln_t",
            "project_tk_log_widths_from_official_remnant_draws": {r["waveform_family"]: r["primary_sigma_log_tk"] for r in log_widths},
            "current_full_directwave_snr_feasible_even_at_rho1": any(
                r["feasible_even_with_rho_le_1"] for r in snr_rows
                if abs(float(r["snr"])-DIRECT_WAVE_NETWORK_SNR) < 1e-6),
        },
        "carrier_proxy": {str(r["n_frequency_samples"]): r for r in carriers},
        "primary_carrier_proxy": {
            "n_frequency_samples": 512,
            "alpha_product_sigma_equals_alpha_over_snr": 1.0/math.sqrt(next(r["fisher_information_log_product_per_snr_squared"] for r in carriers if r["n_frequency_samples"] == 512)),
            "role": "EXACT_V65_BASE_CARRIER_GEOMETRY",
        },
        "directwave_chain": {
            "shape": list(arrays["samples"].shape), "inferred_walkers": 32, "inferred_steps": 5000,
            "convergence_diagnostic_scope": "each interacting emcee walker is treated as one diagnostic chain; this admission screen is not by itself proof of convergence or nonconvergence",
            "frozen_primary_burn_steps": FROZEN_PRIMARY_BURN_STEPS,
            "max_rank_folded_split_rhat_all_burns": rhat_max,
            "max_rank_folded_split_rhat_burn0": rhat_burn0_max,
            "max_rank_folded_split_rhat_primary_burn": rhat_primary_max,
            "minimum_over_burns_of_max_parameter_rhat": min(
                max(float(r["max_rank_folded_split_rhat"]) for r in rhat_rows if int(r["burn_steps"]) == burn)
                for burn in sorted({int(r["burn_steps"]) for r in rhat_rows})
            ),
            "walker_as_chain_rhat_admission_screen": next(r for r in gates if r["gate"] == "released_directwave_chain_convergence")["status"],
            "acceptance_min": summary_accept["acceptance_fraction_min"],
            "acceptance_median": summary_accept["acceptance_fraction_median"],
            "acceptance_frozen_primary_burn": {
                "burn_steps": FROZEN_PRIMARY_BURN_STEPS,
                "minimum": summary_accept_primary["acceptance_fraction_min"],
                "median": summary_accept_primary["acceptance_fraction_median"],
                "mean": summary_accept_primary["acceptance_fraction_mean"],
                "maximum": summary_accept_primary["acceptance_fraction_max"],
            },
            "walkers_below_0p1": summary_accept["walkers_below_0p1"],
            "network_to_detector_direct_importance_ess": dw_ess,
            "network_to_detector_direct_importance_frozen_primary_burn": dw_primary_burn,
            "released_cache_relative_logprob_identity": {
                "status": next(r for r in gates if r["gate"] == "released_directwave_cached_relative_logprob_identity")["status"],
                "centered_residual_std": cached_identity["centered_residual_std"],
                "centered_residual_peak_to_peak": cached_identity["centered_residual_peak_to_peak"],
                "scope": cached_identity["identity_scope"],
            },
        },
        "cbc_network_to_detector_direct_importance_ess": cbc_ess,
        "released_draw_logposterior_vs_loglikelihood_tk": mapml_rows,
        "dq_injection": {
            "event_gps_posterior_median": event_gps,
            "no_cw_hardware_injection_bits_at_event": {r["detector"]: r["event_bit_pass"] for r in cw_rows},
            "status": "CW_HW_INJECTION_BIT_FALSE_FREQUENCY_VETO_NOT_EVALUATED",
        },
        "nonregular_null": {
            "wilks_admitted": False,
            "empirical_maximum_statistic_controls_executed": False,
            "zero_exceedance_count_scope": "requires independent/exchangeable held-out controls and a fully frozen threshold and search pipeline",
        },
        "gate_decision": {r["gate"]: r["status"] for r in gates},
        "claim_boundary": "No detection, no ln4/g=4 identification, no area quantization, no quantum-horizon claim.",
    }
    (args.outdir/"GW250114_V71_summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True)+"\n")

    tests = [
        {"test": "all_required_inputs_fail_closed_pass", "pass": input_pass},
        {"test": "v70_parent_manifest_and_hash_pass", "pass": validation[0]["status"] == "PASS"},
        {"test": "v70_tables_read_from_validated_zip", "pass": len(widths) == 4 and len(inherited_targets) == 6},
        {"test": "chain_member_hashes_and_shapes_pass", "pass": all(r["hash_ok"] and r["shape_ok"] for r in chain_members)},
        {"test": "released_cache_relative_logprob_identity_pass", "pass": bool(cached_identity["cached_relative_logprob_identity_pass"])},
        {"test": "walker_as_chain_rhat_frozen_primary_burn_admission_failure_detected", "pass": not all(r["passes_rhat_le_1p01"] for r in rhat_rows if int(r["burn_steps"]) == FROZEN_PRIMARY_BURN_STEPS)},
        {"test": "directwave_primary_burn_rhat_and_direct_importance_failure_detected", "pass": next(r for r in gates if r["gate"] == "released_directwave_network_to_detector_direct_importance")["admitted"] is False},
        {"test": "directwave_walker_masses_normalized_for_each_burn", "pass": all(len(json.loads(r["walker_mass_by_index_json"])) == 32 and abs(sum(json.loads(r["walker_mass_by_index_json"]))-1.0) < 1e-12 for r in dw_decond if r.get("target"))},
        {"test": "cbc_deconditioning_failure_detected", "pass": not all(r.get("passes_ess_ge_400_and_fraction_ge_0p01", True) for r in cbc_rows)},
        {"test": "all_four_cbc_families_two_detector_targets_audited", "pass": len([r for r in cbc_rows if "importance_ess" in r]) == 8 and len({r["waveform_family"] for r in cbc_rows if "importance_ess" in r}) == 4},
        {"test": "cw_hardware_injection_bit_failure_detected", "pass": len(cw_rows) == 2 and not any(r["event_bit_pass"] for r in cw_rows)},
        {"test": "current_snr_covariance_rescue_infeasible_detected", "pass": not summary["covariance_rescue"]["current_full_directwave_snr_feasible_even_at_rho1"]},
        {"test": "likelihood_thresholds_have_no_prior_term", "pass": all(r["prior_or_jacobian_term"] == 0.0 for r in targets)},
        {"test": "all_v70_targets_semantically_paired", "pass": len(target_comparison) == 6},
        {"test": "primary_512_carrier_alpha_reproduced", "pass": abs(1.0/math.sqrt(next(r["fisher_information_log_product_per_snr_squared"] for r in carriers if r["n_frequency_samples"] == 512))-2.4359676232494074) < 1e-12},
        {"test": "independent_anchor_only_catalog_counts_35_50_82_108", "pass": [int(r["minimum_independent_events"]) for r in catalog_rows if r["scenario"] == "independent_anchor_only_ideal_product_exact" and float(r["common_fractional_systematic_floor"]) == 0.0] == [35, 50, 82, 108]},
        {"test": "log_vs_linear_anchor_width_difference_is_small_but_retained", "pass": all(abs(r["relative_difference_log_vs_linear_mean"]) < 0.01 for r in log_widths)},
        {"test": "nonregular_wilks_rejected", "pass": nonregular_rows[0]["wilks_chi_square_admissible"] is False},
        {"test": "nonregular_zero_exceedance_counts_explicitly_require_iid_and_frozen_search", "pass": all(r.get("iid_or_exchangeable_bernoulli_control_assumption") == "REQUIRED_NOT_ESTABLISHED" and r.get("frozen_threshold_and_full_search_pipeline") == "REQUIRED_NOT_EXECUTED" for r in nonregular_rows if r["item"] in ("zero_exceedance_empirical_control_requirement", "illustrative_bonferroni_nominal_grid"))},
        {"test": "released_draw_map_ml_labels_are_not_continuous_optimization_claims", "pass": all("released_draw" in str(r["point_definition"]) for r in mapml_rows)},
        {"test": "completion_contract_control_and_environment_gates_nonadmitted", "pass": all(next(r for r in gates if r["gate"] == name)["admitted"] is False for name in ("nuisance_quotient_local_completion", "global_nuisance_image_separation", "generative_waveform_contract", "composite_alternative_control", "v67_control_calibration", "raw_detector_surface_environment"))},
    ]
    selftest = {"version": VERSION, "tests": tests,
                "passed": sum(bool(t["pass"]) for t in tests), "total": len(tests)}
    selftest["all_pass"] = selftest["passed"] == selftest["total"]
    (args.outdir/"GW250114_V71_SELF_TEST.json").write_text(json.dumps(selftest, indent=2, sort_keys=True)+"\n")
    if args.strict and not selftest["all_pass"]:
        print("strict computational self-test failed", file=sys.stderr)
        return 3
    print(json.dumps({"version": VERSION, "input_pass": input_pass,
                      "selftests": f"{selftest['passed']}/{selftest['total']}",
                      "verdict": summary["verdict"]}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
