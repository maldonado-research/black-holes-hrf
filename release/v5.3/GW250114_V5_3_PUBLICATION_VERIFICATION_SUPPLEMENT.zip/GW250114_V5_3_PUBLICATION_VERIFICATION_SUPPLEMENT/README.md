# Portable verification supplement for GW250114 HRF v72

This supplement reproduces the **standalone-package and numerical portion** of the publication audit dated 2026-09-05. It contains no original scientific archive or large input data. The scientific contents remain the sealed v72 release.

Requirements: Python 3.9 or later and an already available NumPy installation. The verifier makes no network requests and installs nothing. Matplotlib, Pixi, HDF5 libraries, and gravitational-wave packages are not required because it does not regenerate figures or rerun raw strain.

## Run

Place this folder beside the original v72 standalone ZIP, or provide its path explicitly:

```text
python3 verify_v72_publication.py --input ../HRF_V72_COMPOSITE_CLOSURE_LEAST_FAVORABLE_SEPARATION_AND_RAW_REPLAY.zip
```

The input can instead be the extracted package directory, or a directory containing that package. Use quotes around paths containing spaces. JSON results are printed to standard output; exit code 0 means the implemented checks passed and exit code 1 means verification failed. To save a result, redirect standard output to a new filename of your choice.

The verifier creates its own temporary workspace, copies or safely extracts the input there, performs all writes there, and removes that workspace at exit. It does not write to the input or to this supplement. ZIP traversal paths, absolute paths, duplicate entries, symlinks, special files, oversized packages, and overwrite collisions are rejected. The archive hash and canonical full-manifest hash bind execution to the original sealed v72 source.

## What is checked

- Canonical standalone ZIP SHA-256 and CRC, when a ZIP is supplied; directory inputs instead undergo exact manifest verification.
- Exact standalone manifest membership, byte sizes, and file hashes: 56/56.
- The original 28-check package consistency audit, run on the temporary copy, followed by another full-manifest check.
- Two executions of the unchanged numerical definitions and 17 original numerical self-tests. Plotting imports, backend setup, plotting function, and command-line entry point are omitted through syntax-tree extraction from the hash-verified original source. Eight CSV tables and two JSON outputs are generated and compared between the two temporary runs.
- Saved NPZ grid axes, dimensions, finite values, detector/network maxima, additivity, cache residuals, and row-selection differences.

`PASS` denotes those checks only. It is not scientific peer review or validation of a physical theory. Different NumPy/Python environments can produce last-digit or passing numerical-diagnostic differences; the receipt reports equality with archived bytes separately.

## What is not rerun

The original official-input preflight (9/9), raw finalizer (16/16), and fresh-versus-recovered comparator (26/26) remain inherited receipts. The raw strain files, posterior HDF5, companion archive, original cached HDF5, and imported `qnm_filter` source are not supplied here. There is **no fresh raw-strain analysis**, no full Nature-inference reproduction, and no new HRF, `ln(4)`, `g=4`, area-quantization, quantum-horizon, or unified-theory claim.

The earlier master/enclosing-archive comparisons, canonical v71 provenance, figure regeneration, and deterministic ZIP reconstruction are outside this portable verifier. Consult the publication audit report for their scope.

## Supplied result and clarification

`GW250114_V72_PORTABLE_VERIFICATION_RESULTS_2026-09-05.json` is a sanitized result from a successful run against the sealed standalone ZIP using Python 3.9.6 and NumPy 2.0.2. It contains no personal filesystem paths. The verifier records a current UTC execution timestamp separately from the September audit reference date. Original v72 generators retain the historical hard-coded `2026-07-12` date in their outputs; that field is not a new execution timestamp.

The recovery report reverses one subtraction label: the negative mean `-0.00023655252309568448` belongs to **cached network minus raw released-row network**. The reverse subtraction has positive mean. Centered RMS, maximum absolute residual, maxima, and scientific gates are unaffected. Sealed originals are unchanged.
