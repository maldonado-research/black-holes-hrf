#!/usr/bin/env python3
"""Offline, read-only audit of the sealed v72 standalone package.

All package copies and generated numerical outputs live in a fresh temporary
workspace which is removed at exit. The only persistent output is JSON written
to stdout, which the caller can save. Requires Python >=3.9 and NumPy.
"""
from __future__ import annotations

import argparse
import ast
import csv
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath
import shutil
import stat
import subprocess
import sys
import tempfile
import zipfile

import numpy as np

PACKAGE = 'HRF_V72_COMPOSITE_CLOSURE_LEAST_FAVORABLE_SEPARATION_AND_RAW_REPLAY'
ARCHIVE_SHA256 = '1dc2f45c53a4341a2ea1da7e72f20dfb616eec27ded50407c9844ba8a859d629'
MANIFEST_SHA256 = 'ee886abf3202042a9e4e7f381f2fa284472983e607c08f292111a8158144f4bc'
GENERATOR_SHA256 = '31eeaa721eee9caba464a6fe421a5b8c4cff7b3e5cecf6e99e1d53262ddb5b79'
MANIFEST = 'GW250114_V72_manifest.json'
GENERATOR = 'gw250114_v72_composite_closure_design.py'
MAX_TOTAL_BYTES = 64 * 1024 * 1024
MAX_MEMBERS = 1024
MODES = ('released_logL_plus_logprior', 'maximum_log_likelihood_released_row')


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def safe_parts(name: str) -> tuple[str, ...]:
    if not name or '\\' in name or any(ord(c) < 32 for c in name):
        raise ValueError('Unsafe member path')
    normalized = name[:-1] if name.endswith('/') else name
    path = PurePosixPath(normalized)
    if path.is_absolute() or not path.parts or ':' in path.parts[0]:
        raise ValueError('Absolute or drive-qualified member path')
    if any(part in ('', '.', '..') for part in normalized.split('/')):
        raise ValueError('Traversal or non-normalized member path')
    if path.as_posix() != normalized:
        raise ValueError('Non-normalized member path')
    return path.parts


def extract_zip_safely(archive: Path, destination: Path) -> None:
    """Extract into a new empty directory; reject unsafe paths and collisions."""
    destination.mkdir(exist_ok=False)
    with zipfile.ZipFile(archive) as bundle:
        members = bundle.infolist()
        if len(members) > MAX_MEMBERS or sum(m.file_size for m in members) > MAX_TOTAL_BYTES:
            raise ValueError('Archive exceeds the declared audit size limits')
        seen = set()
        for member in members:
            parts = safe_parts(member.filename)
            key = '/'.join(parts)
            if key in seen:
                raise ValueError('Duplicate archive member')
            seen.add(key)
            unix_mode = member.external_attr >> 16
            kind = stat.S_IFMT(unix_mode)
            if kind not in (0, stat.S_IFREG, stat.S_IFDIR):
                raise ValueError('Symlinks and special archive members are forbidden')
            target = destination.joinpath(*parts)
            if member.is_dir():
                target.mkdir(parents=True, exist_ok=True)
            else:
                target.parent.mkdir(parents=True, exist_ok=True)
                # Exclusive creation prevents overwrites, including collisions.
                with bundle.open(member) as source, target.open('xb') as output:
                    shutil.copyfileobj(source, output)
                if target.stat().st_size != member.file_size:
                    raise ValueError('Extracted member size mismatch')
        # Reading every member to EOF above verifies ZIP CRCs.


def copy_directory_safely(source: Path, destination: Path) -> None:
    """Copy a package only, rejecting symlinks and non-regular entries."""
    if source.is_symlink():
        raise ValueError('Input directory must not be a symlink')
    destination.mkdir(exist_ok=False)
    members = sorted(source.rglob('*'))
    if len(members) > MAX_MEMBERS:
        raise ValueError('Directory exceeds the declared audit member limit')
    total = 0
    for member in members:
        if member.is_symlink():
            raise ValueError('Symlinks are forbidden in input directories')
        relative = member.relative_to(source)
        safe_parts(relative.as_posix())
        target = destination / relative
        if member.is_dir():
            target.mkdir(parents=True, exist_ok=True)
        elif member.is_file():
            total += member.stat().st_size
            if total > MAX_TOTAL_BYTES:
                raise ValueError('Directory exceeds the declared audit size limit')
            target.parent.mkdir(parents=True, exist_ok=True)
            with member.open('rb') as original, target.open('xb') as copied:
                shutil.copyfileobj(original, copied)
        else:
            raise ValueError('Non-regular directory member')


def verify_manifest(package: Path) -> dict:
    manifest_path = package / MANIFEST
    if sha256(manifest_path) != MANIFEST_SHA256:
        raise ValueError('Manifest is not the canonical sealed v72 manifest')
    manifest = json.loads(manifest_path.read_text())
    expected = {}
    for item in manifest['files']:
        safe_parts(item['path'])
        if item['path'] in expected:
            raise ValueError('Duplicate manifest path')
        expected[item['path']] = item
    actual = {p.relative_to(package).as_posix(): p for p in package.rglob('*') if p.is_file() and p != manifest_path}
    if set(actual) != set(expected):
        raise ValueError('Package membership differs from the sealed manifest')
    for name, item in expected.items():
        path = actual[name]
        if path.stat().st_size != item['bytes'] or sha256(path) != item['sha256']:
            raise ValueError('Package member bytes differ from the sealed manifest')
    return {'status': 'PASS', 'listed_files': len(expected), 'actual_files_excluding_manifest': len(actual), 'manifest_sha256': MANIFEST_SHA256}


def numeric_kernel(package: Path, workspace: Path) -> dict:
    generator = package / GENERATOR
    if sha256(generator) != GENERATOR_SHA256:
        raise ValueError('Numerical generator hash mismatch')
    parsed = ast.parse(generator.read_text())
    retained = []
    omitted = []
    for node in parsed.body:
        plotting_import = isinstance(node, ast.Import) and any(x.name.startswith('matplotlib') for x in node.names)
        backend_call = isinstance(node, ast.Expr) and isinstance(node.value, ast.Call) and isinstance(node.value.func, ast.Attribute) and isinstance(node.value.func.value, ast.Name) and node.value.func.value.id == 'matplotlib'
        omitted_function = isinstance(node, ast.FunctionDef) and node.name in ('make_figures', 'main')
        main_guard = isinstance(node, ast.If)
        if plotting_import or backend_call or omitted_function or main_guard:
            omitted.append({'line': node.lineno, 'kind': type(node).__name__})
        else:
            retained.append(node)
    # Execute only the hash-bound canonical generator's unchanged numerical code.
    namespace = {'__name__': 'v72_numeric_audit', '__file__': str(generator)}
    exec(compile(ast.Module(body=retained, type_ignores=[]), GENERATOR, 'exec'), namespace)
    outputs = []
    tests = None
    for index in (1, 2):
        destination = workspace / f'numerical_run_{index}'
        destination.mkdir(exist_ok=False)
        tables = namespace['make_tables'](destination)
        tests = namespace['run_self_tests'](tables)
        namespace['write_json'](destination / 'GW250114_V72_math_self_test.json', tests)
        namespace['write_json'](destination / 'GW250114_V72_math_summary.json', namespace['make_summary'](tables, tests))
        if tests['status'] != 'PASS':
            raise ValueError('Original numerical self-tests did not all pass')
        outputs.append(destination)
    repeated = all(p.read_bytes() == (outputs[1] / p.name).read_bytes() for p in outputs[0].iterdir())
    if not repeated:
        raise ValueError('Repeated numerical outputs differ')
    identical = []
    different = []
    for path in sorted(outputs[0].iterdir()):
        (identical if path.read_bytes() == (package / path.name).read_bytes() else different).append(path.name)
    return {'status': 'PASS', 'scope': 'Numerical kernel only; no figures or fresh raw-strain analysis', 'generator_sha256': GENERATOR_SHA256, 'AST_omissions': omitted, 'self_tests': tests, 'two_runs_byte_identical': repeated, 'generated_artifact_count': len(identical) + len(different), 'byte_identical_to_archived': identical, 'not_byte_identical_to_archived': different, 'portability_note': 'The archived environment differs. Last-digit numeric and passing self-test diagnostic differences can occur; archive-byte equality is reported separately from self-test success.'}


def saved_surface_checks(package: Path) -> dict:
    arrays = {}
    report = {}
    expected = {
        MODES[0]: {'H1': (200., 390.), 'L1': (198., 510.), 'network': (200., 450.)},
        MODES[1]: {'H1': (202., 360.), 'L1': (202., 480.), 'network': (200., 420.)}}
    for mode in MODES:
        with np.load(package / f'GW250114_V72_RAW_MINUS7M_{mode}_surfaces.npz', allow_pickle=False) as data:
            values = {key: data[key].copy() for key in data.files}
        arrays[mode] = values
        if not np.array_equal(values['frequency_hz'], np.arange(160., 240., 2.)) or not np.array_equal(values['damping_rate_s_inv'], np.arange(50., 900., 10.)):
            raise ValueError('Saved surface axes differ')
        maxima = {}
        for label in ('H1', 'L1', 'network'):
            grid = values[label + '_log_likelihood']
            if grid.shape != (85, 40) or not np.isfinite(grid).all():
                raise ValueError('Saved surface shape or finiteness failure')
            row, column = np.unravel_index(np.argmax(grid), grid.shape)
            maximum = (float(values['frequency_hz'][column]), float(values['damping_rate_s_inv'][row]))
            if maximum != expected[mode][label]:
                raise ValueError('Saved surface maximum differs')
            maxima[label] = {'frequency_hz': maximum[0], 'damping_rate_s_inv': maximum[1]}
        additive_error = float(np.max(abs(values['network_log_likelihood'] - values['H1_log_likelihood'] - values['L1_log_likelihood'])))
        if additive_error >= 1e-10:
            raise ValueError('Saved detector/network additivity failure')
        difference = values['released_cached_network_log_likelihood'] - values['network_log_likelihood']
        centered = difference - difference.mean()
        report[mode] = {'maxima': maxima, 'cache_minus_raw': {'mean': float(difference.mean()), 'centered_rms': float(np.sqrt(np.mean(centered**2))), 'centered_max_abs': float(np.max(abs(centered))), 'peak_to_peak': float(np.ptp(difference))}, 'detector_additivity_max_abs': additive_error}
    if report[MODES[0]]['cache_minus_raw']['centered_max_abs'] >= 7.8e-5:
        raise ValueError('Saved released-row cache residual exceeds the declared bound')
    difference = arrays[MODES[1]]['network_log_likelihood'] - arrays[MODES[0]]['network_log_likelihood']
    centered = difference - difference.mean()
    return {'status': 'PASS', 'scope': 'Recalculation of archived NPZ arrays; not a new raw pipeline run', 'modes': report, 'row_selection_centered_difference': {'rms': float(np.sqrt(np.mean(centered**2))), 'max_abs': float(np.max(abs(centered))), 'peak_to_peak': float(np.ptp(difference))}}


def run(input_path: Path) -> dict:
    if input_path.is_symlink():
        raise ValueError('Input must not be a symlink')
    with tempfile.TemporaryDirectory(prefix='gw250114-v72-public-audit-') as temporary:
        workspace = Path(temporary)
        if input_path.is_file():
            archive_hash = sha256(input_path)
            if archive_hash != ARCHIVE_SHA256:
                raise ValueError('Input archive is not the canonical sealed v72 standalone ZIP')
            extract_zip_safely(input_path, workspace / 'extracted')
            package = workspace / 'extracted' / PACKAGE
            input_record = {'kind': 'sealed_standalone_zip', 'archive_sha256': archive_hash, 'zip_crc': 'PASS'}
        elif input_path.is_dir():
            source = input_path if (input_path / MANIFEST).is_file() else input_path / PACKAGE
            if not source.is_dir():
                raise ValueError('Directory does not contain the v72 standalone package')
            package = workspace / 'package_copy'
            copy_directory_safely(source, package)
            input_record = {'kind': 'extracted_standalone_directory', 'archive_sha256': None, 'zip_crc': 'NOT_APPLICABLE'}
        else:
            raise ValueError('Input archive or directory does not exist')
        manifest_result = verify_manifest(package)
        audit_files = [package / 'audits' / f'GW250114_V72_REPRODUCIBILITY_AUDIT.{extension}' for extension in ('json', 'md')]
        original_audits = [path.read_bytes() for path in audit_files]
        # This canonical audit writes only inside our temporary package copy.
        completed = subprocess.run([sys.executable, str(package / 'gw250114_v72_package_audit.py')], cwd=workspace, capture_output=True, text=True, timeout=120, check=False)
        if completed.returncode != 0:
            raise ValueError('Canonical package consistency audit failed')
        package_audit = json.loads(completed.stdout)
        if package_audit['status'] != 'PASS' or package_audit['passed'] != 28 or package_audit['total'] != 28:
            raise ValueError('Canonical package audit did not pass 28/28')
        unchanged_audits = all(path.read_bytes() == original for path, original in zip(audit_files, original_audits))
        post_manifest = verify_manifest(package)
        numeric = numeric_kernel(package, workspace)
        surfaces = saved_surface_checks(package)
        return {'schema': 'GW250114_V72_PORTABLE_PUBLICATION_AUDIT_1', 'status': 'PASS', 'reference_audit_date': '2026-09-05', 'verification_run_utc': datetime.now(timezone.utc).isoformat(timespec='seconds'), 'scope': 'Standalone archive/directory integrity, canonical package consistency audit, numerical kernel, and archived surfaces only. No fresh raw-strain analysis; no full Nature inference or physical discovery validation.', 'runtime': {'python': sys.version.split()[0], 'numpy': np.__version__}, 'input': input_record, 'manifest_before': manifest_result, 'package_audit': {'status': package_audit['status'], 'passed': package_audit['passed'], 'total': package_audit['total'], 'historical_embedded_date': package_audit['date'], 'audit_outputs_match_archived_bytes': unchanged_audits}, 'manifest_after_package_audit': post_manifest, 'numerical_kernel': numeric, 'saved_surfaces': surfaces, 'signed_residual_erratum': 'The recovery Markdown report labels a negative mean as fresh-minus-cache. The negative mean belongs to cached-minus-raw; the reverse subtraction has positive mean. Centered absolute metrics are unaffected.', 'not_reexecuted': ['official_input_acquisition_and_hash_preflight_9_of_9', 'raw_strain_replay_and_finalizer_16_of_16', 'fresh_versus_recovered_raw_comparator_26_of_26', 'plot_regeneration', 'master_archive_and_enclosing_archive_checks', 'canonical_v71_archive_provenance', 'deterministic_zip_rebuild'], 'date_note': 'Original v72 outputs retain the historical hard-coded 2026-07-12 date. reference_audit_date identifies the September audit this supplement reproduces; verification_run_utc is this execution.'}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', required=True, type=Path, help='Canonical v72 standalone ZIP, package directory, or directory containing that package')
    args = parser.parse_args()
    try:
        result = run(args.input)
    except Exception as error:
        # Avoid local-path disclosures and original program traceback in public JSON.
        result = {'schema': 'GW250114_V72_PORTABLE_PUBLICATION_AUDIT_1', 'status': 'FAIL', 'error_type': type(error).__name__, 'message': 'Input safety, canonical integrity, dependency, or numerical verification failed. No source files were changed.'}
        print(json.dumps(result, indent=2, allow_nan=False))
        return 1
    print(json.dumps(result, indent=2, allow_nan=False))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
